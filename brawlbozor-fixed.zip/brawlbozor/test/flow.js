// End-to-end test. Run: node test/flow.js  (starts its own server on a temp DB)
const os=require('os'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'bb-'));
Object.assign(process.env,{DATA_DIR:dir,PORT:'3999',BASE_URL:'http://localhost:3999',ADMIN_PASS:'adminpass1',GOOGLE_CLIENT_ID:'cid123',PAYME_MERCHANT_ID:'m1',PAYME_KEY:'secretkey',CLICK_SERVICE_ID:'7',CLICK_MERCHANT_ID:'9',CLICK_SECRET_KEY:'cs'});
const {server}=require('../server.js');
let fails=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ FAIL ')+m);if(!c)fails++};
const B='http://localhost:3999';
function client(){let ck='';return async(m,p,b,h={})=>{const r=await fetch(B+p,{method:m,headers:{'content-type':'application/json',cookie:ck,...h},body:b?JSON.stringify(b):undefined});const s=r.headers.get('set-cookie');if(s)ck=s.split(';')[0];return{s:r.status,...await r.json()}}}
(async()=>{await new Promise(r=>server.listen(3999,r));
const A=client(),S=client(),U=client(),X=client();
let r=await A('POST','/api/login',{name:'admin',pass:'adminpass1'});ok(r.role==='admin','admin login');
r=await S('POST','/api/register',{name:'seller1',pass:'secret12',adult:true});ok(r.id,'seller register');
r=await U('POST','/api/register',{name:'buyer1',pass:'secret12',adult:true});ok(r.id,'buyer register');
r=await X('POST','/api/register',{name:'kid',pass:'secret12'});ok(r.error==='adult','18+ required');
const px='data:image/png;base64,'+Buffer.concat([Buffer.from([0x89,0x50,0x4e,0x47]),Buffer.alloc(200,1)]).toString('base64');
const i1=(await S('POST','/api/upload',{data:px})).url,i2=(await S('POST','/api/upload',{data:px})).url;ok(i1&&i2,'uploads');
r=await S('POST','/api/listings',{cat:'accounts',title:'Test acc',price:100000,attrs:{nick:'x',year:2020,tr:50000,br:80,pr:10,bind:'b1'},imgs:[i1]});ok(r.error==='e_img','accounts need 2 images');
r=await S('POST','/api/listings',{cat:'pro',title:'Pro Pass',price:50000,attrs:{season:'30',dm:'dm_id',tr:99999}});ok(r.status==='pending','pro pass created (pending)');const proId=r.id;
r=await S('POST','/api/listings',{cat:'accounts',title:'Test acc',price:100000,attrs:{nick:'x',year:2020,tr:50000,br:80,pr:10,bind:'b1'},imgs:[i1,i2],auto:'login:pw'});ok(r.status==='pending','account pending');const accId=r.id;
r=await U('GET','/api/listings?cat=accounts');ok(r.items.length===0,'pending hidden from market');
r=await A('POST','/api/admin/listings/'+accId+'/approve');ok(r.ok,'admin approves');
await A('POST','/api/admin/listings/'+proId+'/approve');
r=await U('GET','/api/listings?cat=pro');ok(r.items.length===1&&!('tr' in r.items[0].attrs),'pro listing has only own attrs');
r=await U('GET','/api/listings?cat=accounts');ok(r.items.length===1&&!JSON.stringify(r).includes('login:pw'),'auto-delivery data not leaked');
r=await U('POST','/api/threads',{lid:accId});const tid=r.id;ok(tid,'thread created');
r=await U('POST','/api/threads/'+tid+'/msg',{text:'t.me/abc'});ok(r.error==='ext_chat','contact sharing blocked');
r=await U('POST','/api/threads/'+tid+'/msg',{text:'salom'});ok(r.ok,'message sent');
r=await U('POST','/api/threads/'+tid+'/offer',{amt:90000});ok(r.ok,'offer');
let th=await S('GET','/api/threads/'+tid);const om=th.msgs.find(m=>m.offer);r=await S('POST',`/api/threads/${tid}/offer/${om.id}`,{accept:true});ok(r.ok,'offer accepted');
th=await U('GET','/api/threads/'+tid);ok(th.thread.price===90000,'price updated to 90000');
r=await U('POST','/api/threads/'+tid+'/pay',{provider:'balance'});ok(r.error==='no_funds','balance pay w/o funds refused');
r=await U('POST','/api/threads/'+tid+'/pay',{provider:'payme'});ok(r.url&&r.url.includes('checkout.paycom.uz'),'payme checkout url');
r=await U('POST','/api/threads/'+tid+'/pay',{provider:'click'});ok(r.url&&r.url.includes('my.click.uz'),'click checkout url');
// payme flow
const pm=(m,p,auth='Paycom:secretkey')=>fetch(B+'/api/payme',{method:'POST',headers:{'content-type':'application/json',authorization:'Basic '+Buffer.from(auth).toString('base64')},body:JSON.stringify({jsonrpc:'2.0',id:1,method:m,params:p})}).then(r=>r.json());
let o=(await A('GET','/api/admin/payments')).items.find(x=>x.provider==='payme');
r=await pm('CheckPerformTransaction',{amount:o.amount*100,account:{order_id:o.id}},'Paycom:bad');ok(r.error&&r.error.code===-32504,'payme bad auth');
r=await pm('CheckPerformTransaction',{amount:123,account:{order_id:o.id}});ok(r.error.code===-31001,'payme wrong amount');
r=await pm('CheckPerformTransaction',{amount:o.amount*100,account:{order_id:o.id}});ok(r.result&&r.result.allow,'payme check ok');
r=await pm('CreateTransaction',{id:'tx1',time:Date.now(),amount:o.amount*100,account:{order_id:o.id}});ok(r.result&&r.result.state===1,'payme create');
r=await pm('PerformTransaction',{id:'tx1'});ok(r.result&&r.result.state===2,'payme perform');
th=await U('GET','/api/threads/'+tid);ok(th.thread.status==='paid','thread paid after payme');ok(th.msgs.some(m=>m.text&&m.text.includes('login:pw')),'auto delivery message appears after payment');
r=await U('GET','/api/listings/'+accId);ok(r.item.status==='sold','listing sold');
r=await pm('CheckTransaction',{id:'tx1'});ok(r.result.state===2,'payme check tx');
// dispute -> admin resolve to buyer
r=await U('POST','/api/threads/'+tid+'/dispute',{text:'bad'});ok(r.ok,'dispute opened');
r=await U('POST','/api/threads/'+tid+'/msg',{text:'chat still open in dispute'});ok(r.ok,'chat stays open during dispute');
r=await A('POST','/api/admin/threads/'+tid+'/resolve',{to:'buyer'});ok(r.ok,'admin refunds buyer');
r=await U('GET','/api/wallet');ok(r.bal===90000,'buyer wallet refunded 90000');
r=await U('POST','/api/threads/'+tid+'/msg',{text:'chat still open after refund'});ok(r.ok,'chat stays open after resolution');
r=await A('POST','/api/admin/settings',{hold_days:3,wd_lock_days:0});ok(r.ok,'admin sets hold 3 days, no withdraw lock');
// second purchase via wallet on pro pass, confirm → hold → release
r=await U('POST','/api/threads',{lid:proId});const t2=r.id;
r=await U('POST','/api/threads/'+t2+'/pay',{provider:'balance'});ok(r.paid,'wallet payment ok (90000-50000)');
r=await S('POST','/api/threads/'+t2+'/deliver');ok(r.ok,'seller marks delivered');
r=await U('POST','/api/threads/'+t2+'/confirm');ok(r.ok,'buyer confirms');
r=await S('GET','/api/wallet');ok(r.bal===0&&r.holds.length===1&&r.holds[0].amt===46500,'seller has 46 500 on hold (7% fee)');
r=await U('POST','/api/threads/'+t2+'/msg',{text:'thanks'});ok(r.ok,'chat NOT closed after sale completes');
r=await U('POST','/api/threads/'+t2+'/review',{stars:5,text:'zo\'r'});ok(r.ok,'review');
const h=(await A('GET','/api/admin/holds')).items[0];r=await A('POST','/api/admin/holds/'+h.id+'/release');ok(r.ok,'admin releases hold');
r=await S('GET','/api/wallet');ok(r.bal===46500,'seller balance 46 500');
r=await S('POST','/api/withdraw',{amt:20000,card:'8600000000000000'});ok(r.error==='bad_card','invalid card refused');
const luhn=n=>{let s=0,d=false;for(let i=n.length-1;i>=0;i--){let x=+n[i];if(d){x*=2;if(x>9)x-=9}s+=x;d=!d}return s%10===0};let cn;for(let c=0;c<10;c++)if(luhn('860012345678901'+c)){cn='860012345678901'+c;break}
r=await S('POST','/api/withdraw',{amt:20000,card:cn,holder:'ALI VALIYEV'});ok(r.ok&&r.fee===400&&r.net===19600,'withdraw requested (2% fee: 400, net 19 600)');
r=await S('POST','/api/withdraw',{amt:10000,card:cn,holder:''});ok(r.error==='f_holder','card holder name required');
const w=(await A('GET','/api/admin/withdrawals')).items[0];r=await A('POST','/api/admin/withdrawals/'+w.id+'/pay',{});ok(r.ok,'admin marks withdrawal paid');
r=await S('GET','/api/admin/overview');ok(r.error==='forbidden','non-admin blocked from admin API');
r=await A('GET','/api/admin/overview');ok(r.revenue===3900&&r.net===3900&&r.deals===1,'overview: revenue 3 900 (3 500 fee + 400 withdraw fee), net profit 3 900');
// click
r=await S('POST','/api/listings',{cat:'gems',title:'80 gems',price:30000,attrs:{gems:80,dm:'dm_gift'}});await A('POST','/api/admin/listings/'+r.id+'/approve');
r=await U('POST','/api/threads',{lid:r.id});const t3=r.id;await U('POST','/api/threads/'+t3+'/pay',{provider:'click'});
o=(await A('GET','/api/admin/payments')).items.find(x=>x.provider==='click'&&x.tid===t3);
const md5=s=>crypto.createHash('md5').update(s).digest('hex');
const ck=(kind,x)=>fetch(B+'/api/click/'+kind,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(x)}).then(r=>r.json());
let base={click_trans_id:'55',service_id:'7',merchant_trans_id:String(o.id),amount:'30000.00',sign_time:'2026-10-31 12:00:00'};
r=await ck('prepare',{...base,action:'0',sign_string:'bad'});ok(r.error===-1,'click bad sign');
r=await ck('prepare',{...base,action:'0',sign_string:md5(`55730000${'cs'.padStart(2)}`.replace('730000','7'+'cs'+o.id+'30000.00'+'0'+'2026-10-31 12:00:00').slice(0,0)||`557cs${o.id}30000.0002026-10-31 12:00:00`)});ok(r.error===0&&r.merchant_prepare_id===o.id,'click prepare');
r=await ck('complete',{...base,merchant_prepare_id:String(o.id),action:'1',error:'0',sign_string:md5(`557cs${o.id}${o.id}30000.0012026-10-31 12:00:00`)});ok(r.error===0,'click complete');
th=await U('GET','/api/threads/'+t3);ok(th.thread.status==='paid','thread paid after click');
// top-up via Payme (real wallet credit), cancel, seller stats, search-all, favs clear
r=await U('POST','/api/topup',{provider:'payme',amt:1000});ok(r.error==='bad_number','topup below minimum refused');
const bal0=(await U('GET','/api/wallet')).bal;
r=await U('POST','/api/topup',{provider:'payme',amt:20000});ok(r.url&&r.url.includes('paycom'),'topup payme url');
o=(await A('GET','/api/admin/payments')).items.find(x=>x.provider==='payme'&&x.tid===0);ok(o&&o.amount===20000,'topup order (tid 0)');
r=await pm('CheckPerformTransaction',{amount:2000000,account:{order_id:o.id}});ok(r.result&&r.result.allow,'payme topup check');
await pm('CreateTransaction',{id:'tup1',time:Date.now(),amount:2000000,account:{order_id:o.id}});
r=await pm('PerformTransaction',{id:'tup1'});ok(r.result&&r.result.state===2,'payme topup perform');
ok((await U('GET','/api/wallet')).bal===bal0+20000,'wallet credited +20000 automatically');
r=await pm('PerformTransaction',{id:'tup1'});ok(r.result.state===2&&(await U('GET','/api/wallet')).bal===bal0+20000,'perform is idempotent (no double credit)');
r=await pm('CancelTransaction',{id:'tup1',reason:5});ok(r.result&&r.result.state===-2,'payme topup cancel reverses');
ok((await U('GET','/api/wallet')).bal===bal0,'wallet back to original');
r=await U('POST','/api/topup',{provider:'demo',amt:15000});ok(r.error==='provider','demo/test payments are gone (no demo provider)');
r=await U('POST','/api/orders/1/demo-pay',{});ok(r.error==='not_found','demo-pay endpoint removed');
r=await U('GET','/api/config');ok(r.pay.demo===undefined,'config has no demo flag');
r=await S('GET','/api/seller/stats');ok(r.sales===1&&r.turnover===50000,'seller stats');
r=await U('GET','/api/listings?cat=all&q=gems');ok(r.items.length===0,'search across all (sold items hidden)');
r=await S('POST','/api/listings',{cat:'gems',title:'170 gems',price:89000,attrs:{gems:170,dm:'dm_id'}});await A('POST','/api/admin/listings/'+r.id+'/approve');
r=await U('GET','/api/listings?cat=all&q=170');ok(r.items.length===1,'search across all finds new listing');
await U('POST','/api/favs/'+r.items[0].id);r=await U('GET','/api/favs');ok(r.items.length===1,'favorite added');
await U('DELETE','/api/favs');r=await U('GET','/api/favs');ok(r.items.length===0,'favorites cleared');
// ---- cards / deposits / admin balance / verified badge / notifications / finance ----
const px2=n=>'data:image/png;base64,'+Buffer.concat([Buffer.from([0x89,0x50,0x4e,0x47]),Buffer.alloc(200,n)]).toString('base64');
let cn2;for(let c=0;c<10;c++)if(luhn('986012345678901'+c)){cn2='986012345678901'+c;break}
r=await U('GET','/api/cards');ok(r.items.length===0,'no cards yet');
r=await U('POST','/api/admin/cards',{num:cn2,holder:'X',bank:'Y'});ok(r.error==='forbidden','non-admin cannot add card');
r=await A('POST','/api/admin/cards',{num:'1234567812345678',holder:'ALI VALIYEV',bank:'Agro bank',kind:'humo'});ok(r.error==='bad_card','invalid card number refused');
r=await A('POST','/api/admin/cards',{num:cn2,holder:'ALI VALIYEV',bank:'Agro bank',kind:'humo'});ok(r.id,'admin adds card 1');const k1=r.id;
r=await A('POST','/api/admin/cards',{num:cn,holder:'VALI ALIYEV',bank:'Hamkor bank',kind:'uzcard'});ok(r.id,'admin adds card 2');const k2=r.id;
r=await U('GET','/api/cards');ok(r.items.length===2&&r.items[0].id===k1,'user sees 2 active cards in order');
r=await A('POST','/api/admin/cards/reorder',{ids:[k2,k1]});r=await U('GET','/api/cards');ok(r.items[0].id===k2,'admin reorders cards');
r=await A('POST','/api/admin/cards/'+k2,{active:false});r=await U('GET','/api/cards');ok(r.items.length===1&&r.items[0].id===k1,'inactive card hidden');
r=await A('POST','/api/admin/cards/'+k1,{bank:'Ipak yoli'});r=await U('GET','/api/cards');ok(r.items[0].bank==='Ipak yoli','card edit visible immediately');
r=await A('DELETE','/api/admin/cards/'+k2);r=await A('GET','/api/admin/cards');ok(r.items.length===1,'admin deletes card');
r=await U('GET','/api/config');ok(r.manual===true,'config: manual card payments available');
const bal1=(await U('GET','/api/wallet')).bal;
r=await U('POST','/api/deposits',{amt:100000,card:k1});ok(r.id,'user creates deposit request');const d1=r.id;
r=await A('POST','/api/admin/deposits/'+d1+'/approve',{});ok(r.error==='not_found','cannot approve without receipt');
const rc1=(await U('POST','/api/upload',{data:px2(7)})).url;
r=await U('POST','/api/deposits/'+d1+'/receipt',{img:rc1});ok(r.ok,'user sends receipt');
r=await U('POST','/api/deposits',{amt:5000,card:k1});const d2=r.id;const rc1b=(await U('POST','/api/upload',{data:px2(7)})).url;
r=await U('POST','/api/deposits/'+d2+'/receipt',{img:rc1b});ok(r.error==='dup_receipt','same receipt image refused twice');
r=await U('POST','/api/deposits/'+d2+'/cancel');ok(r.ok,'user cancels pending deposit');
r=await A('GET','/api/admin/deposits?status=review');ok(r.items.length===1&&r.items[0].receipt===rc1&&r.items[0].card.num===cn2,'admin sees deposit with receipt and card');
r=await A('POST','/api/admin/deposits/'+d1+'/reject',{reason:''});ok(r.error==='f_reason','rejection needs reason');
r=await A('POST','/api/admin/deposits/'+d1+'/approve',{});ok(r.ok,'admin approves deposit');
r=await A('POST','/api/admin/deposits/'+d1+'/approve',{});ok(r.error==='not_found','deposit cannot be approved twice');
ok((await U('GET','/api/wallet')).bal===bal1+100000,'balance credited once (+100 000)');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_dep_ok'&&n.a[0]===100000)&&r.items.some(n=>n.k==='n_dep_recv'),'user notified: received + approved');
r=await U('POST','/api/deposits',{amt:20000,card:k1});const d3=r.id;await U('POST','/api/deposits/'+d3+'/receipt',{img:(await U('POST','/api/upload',{data:px2(9)})).url});
r=await A('POST','/api/admin/deposits/'+d3+'/reject',{reason:'chek tasdiqlanmadi'});ok(r.ok,'admin rejects deposit');
ok((await U('GET','/api/wallet')).bal===bal1+100000,'rejected deposit adds nothing');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_dep_no'&&n.a[0]==='chek tasdiqlanmadi'),'rejection reason sent to user');
r=await U('POST','/api/notifs/read');r=await U('GET','/api/notifs');ok(r.unread===0,'notifications marked read');
r=await A('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_dep_new'),'admin notified about new deposit');
// admin manual balance
const uid=(await U('GET','/api/me')).me.id;const bal2=(await U('GET','/api/wallet')).bal;
r=await A('POST','/api/admin/users/'+uid+'/balance',{op:'add',amt:5000,reason:''});ok(r.error==='f_reason','manual balance needs reason');
r=await A('POST','/api/admin/users/'+uid+'/balance',{op:'add',amt:5000,reason:'bonus',note:'test'});ok(r.ok&&r.nbal===bal2+5000,'admin adds balance');
r=await A('POST','/api/admin/users/'+uid+'/balance',{op:'sub',amt:2000,reason:'xato'});ok(r.ok&&r.nbal===bal2+3000,'admin subtracts balance');
r=await A('POST','/api/admin/users/'+uid+'/balance',{op:'sub',amt:9e9,reason:'xato'});ok(r.error==='bad_number'||r.error==='no_funds','cannot overdraw');
r=await U('POST','/api/admin/users/'+uid+'/balance',{op:'add',amt:5000,reason:'hack'});ok(r.error==='forbidden','user cannot change own balance');
r=await A('GET','/api/admin/users/'+uid);ok(r.tx.some(x=>x.type==='adm')&&r.buys.length>=1,'admin sees user history');
r=await A('GET','/api/admin/logs');ok(r.items.some(x=>x.act==='bal_add'&&x.ref.startsWith(uid+':5000')),'admin balance action logged');
// verified badge
await A('POST','/api/admin/settings',{vf_mode:'approval'});
r=await U('GET','/api/verify');ok(r.st==='none'&&r.price===30000,'verify: default state none, price 30 000');
r=await U('POST','/api/verify/pay');ok(r.error==='forbidden','cannot pay before admin approval');
r=await U('POST','/api/verify/request',{note:'men haqiqiy sotuvchi'});ok(r.ok,'verify request sent');
r=await U('POST','/api/verify/request',{});ok(r.error==='vf_wait','duplicate request refused');
let vq=(await A('GET','/api/admin/verifs')).items;ok(vq.length===1,'admin sees pending request');
r=await A('POST','/api/admin/verifs/'+vq[0].id+'/reject',{reason:'hujjat yetarli emas'});ok(r.ok,'admin rejects request');
r=await U('GET','/api/verify');ok(r.st==='rejected'&&r.note==='hujjat yetarli emas','user sees rejection reason');
r=await U('POST','/api/verify/request',{});vq=(await A('GET','/api/admin/verifs')).items;r=await A('POST','/api/admin/verifs/'+vq[0].id+'/approve');ok(r.ok,'admin approves request');
r=await U('GET','/api/verify');ok(r.st==='approved','state: approved, awaiting payment');
r=await A('POST','/api/admin/settings',{vf_price:50000,vf_days:30,vf_renew:'auto'});ok(r.ok,'admin sets badge price 50 000');
const bal3=(await U('GET','/api/wallet')).bal;r=await U('POST','/api/verify/pay');ok(r.ok&&r.until>Date.now()+29*864e5,'user pays monthly fee from balance');
ok((await U('GET','/api/wallet')).bal===bal3-50000,'50 000 charged');
r=await U('GET','/api/verify');ok(r.st==='active','state: active');
r=await S('GET','/api/users/'+uid);ok(r.user.vf===true,'badge shown on public profile');
r=await U('GET','/api/threads');ok(r.vf===true,'badge flag in session poll');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_vf_paid'),'user notified: badge activated');
const finA=await A('GET','/api/admin/finance');ok(finA.byType.verify===50000,'badge income recorded (50 000)');
// expiry: auto-renew off → expires; admin revoke/grant
await U('POST','/api/verify/auto',{on:false});
r=await A('POST','/api/admin/users/'+uid+'/unverify',{reason:'test'});ok(r.ok,'admin revokes badge');
r=await U('GET','/api/verify');ok(r.st==='none'&&!r.ok,'badge removed');
r=await A('POST','/api/admin/users/'+uid+'/verify',{days:7});ok(r.ok,'admin grants badge for 7 days');
r=await U('GET','/api/verify');ok(r.st==='active'&&r.until<Date.now()+8*864e5,'granted badge active ~7 days');
// withdraw lock after sale + immediate credit when hold = 0
r=await A('POST','/api/admin/settings',{hold_days:0,wd_lock_days:2});ok(r.ok,'admin sets no hold, 2-day withdraw lock');
r=await S('POST','/api/listings',{cat:'gems',title:'500 gems',price:100000,attrs:{gems:500,dm:'dm_id'}});await A('POST','/api/admin/listings/'+r.id+'/approve');
await A('POST','/api/admin/users/'+uid+'/balance',{amt:15000,reason:'test',op:'add'});
r=await U('POST','/api/threads',{lid:r.id});const t5=r.id;await U('POST','/api/threads/'+t5+'/pay',{provider:'balance'});await U('POST','/api/threads/'+t5+'/confirm');
let sw=await S('GET','/api/wallet');ok(sw.holds.length===0&&sw.locked>=93000&&sw.avail===0,'seller credited at once (no hold) but money locked for 2 days');
r=await S('POST','/api/withdraw',{amt:sw.bal,card:cn,holder:'ALI VALIYEV'});ok(r.error==='locked','cannot withdraw locked sale money');
r=await S('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_sale'&&n.a[1]===93000),'seller notified about sale');
r=await A('POST','/api/admin/settings',{wd_fee_pct:2000});ok(r.error==='bad_number','settings validated');
// finance
const fin=await A('GET','/api/admin/finance');ok(fin.total.net===fin.total.inc-fin.total.exp&&fin.total.inc===fin.byType.fee+fin.byType.wd_fee+fin.byType.boost+fin.byType.verify+fin.byType.other,'net profit = income - expenses (from DB)');
ok(fin.byType.fee===3500+7000,'trade commissions 3 500 + 7 000');
ok(fin.today.net===fin.total.net,'today equals total on a fresh DB');
r=await A('POST','/api/admin/ledger',{kind:'other',amt:1000,note:'hosting'});ok(r.ok,'admin records expense');
const fin2=await A('GET','/api/admin/finance');ok(fin2.total.net===fin.total.net-1000,'expense reduces net profit');
r=await A('GET','/api/admin/overview');ok(r.depTotal>=100000&&r.net===fin2.total.net,'overview: deposits & net profit');
// Google sign-in (tokeninfo mocked)
const rf=globalThis.fetch;const gtok=p=>'T'.repeat(100)+Buffer.from(JSON.stringify(p)).toString('base64url');
globalThis.fetch=(u,o)=>String(u).includes('oauth2.googleapis.com/tokeninfo')?Promise.resolve(new Response(JSON.stringify(JSON.parse(Buffer.from(new URL(u).searchParams.get('id_token').slice(100),'base64url').toString())),{status:200})):rf(u,o);
const okp={aud:'cid123',iss:'https://accounts.google.com',email_verified:'true',exp:String(Math.floor(Date.now()/1000)+3600),sub:'g-1',email:'Ali.Valiyev@gmail.com'};
const G=client();
r=await G('POST','/api/google',{credential:gtok(okp)});ok(r.error==='adult','google: new account needs 18+ consent');
r=await G('POST','/api/google',{credential:gtok(okp),adult:true});ok(r.id&&r.name==='ali.valiyev','google: account created from email');const gid=r.id;
r=await G('GET','/api/threads');ok(r.uid===gid,'session uid returned');
const G2=client();r=await G2('POST','/api/google',{credential:gtok(okp)});ok(r.id===gid,'google: same user logs in again');
r=await G2('POST','/api/google',{credential:gtok({...okp,aud:'other'}),adult:true});ok(r.error==='bad_login','google: wrong audience rejected');
r=await G2('POST','/api/google',{credential:gtok({...okp,sub:'g-2',email_verified:'false'}),adult:true});ok(r.error==='bad_login','google: unverified email rejected');
r=await G2('POST','/api/google',{credential:'short'});ok(r.error==='bad_login','google: garbage token rejected');
r=await G('POST','/api/logout',{});r=await G('GET','/api/me');ok(r.me===null,'logout clears session');
globalThis.fetch=rf;

// ---------- galochka: instant purchase mode ----------
{
await A('POST','/api/admin/settings',{vf_mode:'instant'});
const V=client();r=await V('POST','/api/register',{name:'verif1',pass:'secret12',adult:true});const vid=r.id;
r=await V('GET','/api/verify');ok(r.st==='none'&&r.mode==='instant','instant mode: user can see the badge is purchasable');
r=await V('POST','/api/verify/pay');ok(r.error==='no_funds','instant mode: needs balance');
await A('POST','/api/admin/users/'+vid+'/balance',{amt:100000,reason:'test',op:'add'});
const vb=(await V('GET','/api/wallet')).bal;r=await V('POST','/api/verify/pay');ok(r.ok&&r.until>Date.now()+29*864e5,'instant mode: badge bought without admin approval');
r=await V('POST','/api/verify/pay');ok(r.error==='rate','instant mode: double click does not charge twice');
r=await V('GET','/api/verify');ok(r.st==='active','instant mode: state active');ok((await V('GET','/api/wallet')).bal===vb-r.price,'instant mode: exactly one fee charged');
r=await V('GET','/api/me');ok(r.me.vf===true,'badge shows on profile');
r=await V('POST','/api/verify/auto',{on:true});ok(r.ok,'auto-renew can be switched on');
}
// ---------- admin: system, backups, google settings ----------
{
r=await U('GET','/api/admin/system');ok(r.error==='forbidden','system info is admin-only');
r=await A('GET','/api/admin/system');ok(r.data&&r.dbSize>0&&Array.isArray(r.backups),'admin sees data dir, db size, backups');
r=await U('POST','/api/admin/backup',{});ok(r.error==='forbidden','backup is admin-only');
r=await A('POST','/api/admin/backup',{});ok(r.ok&&/^bb-\d{8}-\d{6}-manual\.sqlite$/.test(r.name),'admin creates a backup');const bkn=r.name;
r=await A('GET','/api/admin/system');ok(r.backups.some(b=>b.name===bkn&&b.size>1000),'backup is listed');
const lg=await fetch(B+'/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'admin',pass:'adminpass1'})});const ck=lg.headers.get('set-cookie').split(';')[0];
const dl=await fetch(B+'/api/admin/backup/download?name='+bkn,{headers:{cookie:ck}});const buf=Buffer.from(await dl.arrayBuffer());ok(dl.status===200&&buf.slice(0,15).toString()==='SQLite format 3','backup downloads as a real SQLite file');
const dl2=await fetch(B+'/api/admin/backup/download?name=../../etc/passwd',{headers:{cookie:ck}});ok(dl2.status===404,'backup download refuses path tricks');
const dl3=await fetch(B+'/api/admin/backup/download?name='+bkn);ok(dl3.status===401,'backup download needs admin session');
r=await A('POST','/api/admin/google',{id:'garbage'});ok(r.error==='f_gid','google client id format checked');
r=await A('POST','/api/admin/google',{id:'1234567890-abcdefg.apps.googleusercontent.com'});ok(r.ok,'admin saves google client id');
r=await U('GET','/api/config');ok(r.google==='1234567890-abcdefg.apps.googleusercontent.com','config serves the id saved in admin panel (no restart)');
const hh=await fetch(B+'/');ok((hh.headers.get('content-security-policy')||'').includes('accounts.google.com/gsi/client'),'CSP allows Google sign-in once configured');
r=await A('POST','/api/admin/google',{id:''});r=await U('GET','/api/config');ok(r.google==='cid123','clearing falls back to .env value');
}
// ---------- login hardening ----------
{
let last;for(let i=0;i<11;i++)last=await client()('POST','/api/login',{name:'nobody',pass:'wrongpass'});ok(last.error==='rate'||last.s===429,'brute force on one name is rate-limited');
r=await client()('POST','/api/login',{name:'admin',pass:'adminpass1'});ok(r.role==='admin','admin still logs in while another name is being hammered');
}
// ---------- AutoPayCard (api.autopaycard.uz mocked) ----------
{
const lu=n=>{let s=0,d=true;for(let i=n.length-1;i>=0;i--){let x=+n[i];if(d){x*=2;if(x>9)x-=9}s+=x;d=!d}return(10-s%10)%10};
const cnum='860012345678901'+lu('860012345678901'),L4=cnum.slice(-4);
const apiO={};let apiDown=false,apiNext=1000,conflictOnce=false,seenKey='';
globalThis.fetch=async(u,o={})=>{u=String(u);if(!u.startsWith('https://api.autopaycard.uz'))return rf(u,o);
 if(apiDown)throw new Error('down');seenKey=o.headers['x-api-key'];
 const p=u.slice('https://api.autopaycard.uz'.length),b=o.body?JSON.parse(o.body):{},R=(s,j)=>new Response(JSON.stringify(j),{status:s});
 if(p==='/api/create-payment'){if(conflictOnce){conflictOnce=false;return R(409,{detail:'busy'});}const id=String(apiNext++);apiO[id]={order_id:id,status:'waiting',amount:b.amount,card_last4:b.card_last4,gmail:b.gmail,client_user_id:b.client_user_id};return R(200,{success:true,order_id:id});}
 if(p==='/api/check-payment'){const x=apiO[b.order_id];return x?R(200,x):R(404,{detail:'x'});}
 if(p==='/api/subscription')return R(200,{active:true,tariff_name:'Standart',expires_at:'2026-12-01 10:00:00',payments_used:3,max_payments:500});
 if(p==='/api/my-cards')return R(200,{cards:[{id:1,card_last4:L4,gmail:'kassa@gmail.com'}]});
 return R(404,{});};
const hook=(obj,secret='whsec_test123')=>{const body=JSON.stringify(obj),t=Math.floor(Date.now()/1000),h={'content-type':'application/json'};if(secret)h['x-autopaycard-signature']=`t=${t},v1=${crypto.createHmac('sha256',secret).update(t+'.'+body).digest('hex')}`;return rf(B+'/api/apc/webhook',{method:'POST',headers:h,body}).then(async x=>({s:x.status,...await x.json()}))};
const W=async c=>(await c('GET','/api/wallet')).bal,extOf=p=>Object.values(apiO).find(x=>x.amount===p.amt).order_id;
const waitFor=async(f,ms)=>{const t=Date.now();while(Date.now()-t<ms){if(await f())return true;await new Promise(z=>setTimeout(z,300))}return false};
r=await U('POST','/api/apay',{amt:50000});ok(r.error==='provider','apc: unavailable until configured');
r=await A('POST','/api/admin/cards',{num:cnum,holder:'ALI VALIYEV',bank:'Uzcard',kind:'uzcard'});const apcCard=r.id;ok(apcCard,'apc: card added');
r=await A('POST','/api/admin/apc',{key:'testkey12345',whsec:'whsec_test123',gmail:'Kassa@Gmail.com',card:apcCard});ok(r.ok,'apc: settings saved');
r=await A('GET','/api/admin/apc');ok(r.ready&&r.key&&r.gmail==='kassa@gmail.com'&&!JSON.stringify(r).includes('testkey12345')&&!JSON.stringify(r).includes('whsec_test123'),'apc: secrets never returned to the browser');
r=await U('GET','/api/config');ok(r.pay.apc===true&&!JSON.stringify(r).includes('testkey12345'),'apc: offered as payment method');
r=await A('POST','/api/admin/apc/test',{});ok(r.match===true&&r.sub.active,'apc: admin connection test');
const b0=await W(U);
r=await U('POST','/api/apay',{amt:50000});const p1=r;ok(r.id&&r.amt>50000&&r.amt<=50099&&r.status==='waiting'&&r.card.num===cnum&&r.exp>r.now,'apc: payment with unique amount + card shown');
ok(seenKey==='testkey12345'&&Object.values(apiO).some(x=>x.amount===p1.amt&&x.card_last4===L4&&x.gmail==='kassa@gmail.com'),'apc: create-payment sent with key, last4, gmail');
r=await U('POST','/api/apay',{amt:60000});ok(r.error==='apc_open','apc: only one open payment per user');
r=await S('POST','/api/apay',{amt:50000});const p2=r;ok(p2.id&&p2.amt!==p1.amt&&p2.amt>50000&&p2.amt<=50099,'apc: second user on same card gets a different amount');
const e1=extOf(p1),e2=extOf(p2);
r=await hook({event:'payment.paid',order_id:e1,status:'paid',amount:p1.amt,card_last4:L4},'wrong');ok(r.s===401&&await W(U)===b0,'apc: bad webhook signature credits nothing');
r=await hook({event:'payment.paid',order_id:e2,status:'paid',amount:p2.amt+1,card_last4:L4});r=await S('GET','/api/apay/'+p2.id);ok(r.status==='manual','apc: different amount is NOT auto-confirmed (manual review)');
r=await hook({event:'payment.paid',order_id:e1,status:'paid',amount:p1.amt,card_last4:L4});ok(r.s===200&&await W(U)===b0+p1.amt,'apc: signed webhook credits the balance');
r=await hook({event:'payment.paid',order_id:e1,status:'paid',amount:p1.amt,card_last4:L4});ok(await W(U)===b0+p1.amt,'apc: duplicate webhook does not credit twice');
r=await U('GET','/api/apay/'+p1.id);ok(r.status==='paid','apc: status paid');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_apc_new')&&r.items.some(n=>n.k==='n_apc_ok'),'apc: created + confirmed notifications');
r=await A('GET','/api/admin/apay?status=manual');ok(r.items.some(x=>x.id===p2.id&&x.uname==='seller1'&&x.ext===e2),'apc: admin sees manual payment (user, amount, order_id)');
r=await A('GET','/api/admin/overview');ok(r.apcManual>=1,'apc: manual badge count');
const sb=await W(S);r=await A('POST',`/api/admin/apay/${p2.id}/confirm`,{amt:p2.amt});ok(r.ok&&await W(S)===sb+p2.amt,'apc: admin confirms manually');
r=await A('POST',`/api/admin/apay/${p2.id}/confirm`,{amt:p2.amt});ok(r.error==='not_found'&&await W(S)===sb+p2.amt,'apc: admin cannot confirm the same payment twice');
// polling without webhook
r=await U('POST','/api/apay',{amt:70000});const p3=r,e3=extOf(p3),b3=await W(U);apiO[e3].status='paid';
ok(await waitFor(async()=>(await U('GET','/api/apay/'+p3.id)).status==='paid',12000)&&await W(U)===b3+p3.amt,'apc: polling confirms payment even without a webhook');
// expiry
r=await U('POST','/api/apay',{amt:80000});const p4=r,e4=extOf(p4),b4=await W(U);apiO[e4].status='expired';
ok(await waitFor(async()=>(await U('GET','/api/apay/'+p4.id)).status==='expired',12000)&&await W(U)===b4,'apc: expired payment is not credited');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_apc_exp'),'apc: expiry notification');
await hook({event:'payment.paid',order_id:e4,status:'paid',amount:p4.amt,card_last4:L4});r=await U('GET','/api/apay/'+p4.id);ok(r.status==='manual'&&await W(U)===b4,'apc: late payment after expiry goes to manual review, not auto-credited');
r=await A('POST',`/api/admin/apay/${p4.id}/reject`,{reason:'Pul tushmadi'});ok(r.ok&&await W(U)===b4,'apc: admin rejects');
r=await U('GET','/api/notifs');ok(r.items.some(n=>n.k==='n_apc_no'),'apc: rejection notification');
// provider trouble
apiDown=true;r=await U('POST','/api/apay',{amt:90000});ok(r.error==='apc_down'&&await W(U)===b4,'apc: API down → clear error, balance untouched');apiDown=false;
r=await U('GET','/api/wallet');ok(!r.apc,'apc: no stuck open payment after API failure');
conflictOnce=true;r=await U('POST','/api/apay',{amt:90000});const p5=r;ok(p5.id&&p5.status==='waiting','apc: 409 (amount busy) retried with another amount');
r=await U('POST','/api/apay/'+p5.id+'/cancel');ok(r.ok,'apc: user cancels');r=await U('GET','/api/apay/'+p5.id);ok(r.status==='cancelled','apc: cancelled');
r=await S('GET','/api/apay/'+p5.id);ok(r.error==='not_found','apc: other users cannot read my payment');
// no signing secret configured: the body is never trusted, API is asked
await A('POST','/api/admin/apc',{clear_whsec:true});
r=await U('POST','/api/apay',{amt:95000});const p6=r,e6=extOf(p6),b6=await W(U);
await hook({event:'payment.paid',order_id:e6,status:'paid',amount:p6.amt},null);ok(await W(U)===b6,'apc: unsigned webhook claiming "paid" is ignored when API says waiting');
apiO[e6].status='paid';await hook({event:'payment.paid',order_id:e6,status:'paid',amount:p6.amt},null);
ok(await waitFor(async()=>(await U('GET','/api/apay/'+p6.id)).status==='paid',6000)&&await W(U)===b6+p6.amt,'apc: unsigned webhook verified via check-payment, credited once');

// pay for an item straight through AutoPayCard: wallet is credited, then escrow starts by itself
r=await S('POST','/api/listings',{cat:'gems',title:'300 gems auto',price:55000,attrs:{gems:300,dm:'dm_id'}});await A('POST','/api/admin/listings/'+r.id+'/approve');const lidA=r.id;
const BU=client();r=await BU('POST','/api/register',{name:'buyer9',pass:'secret12',adult:true});r=await BU('POST','/api/threads',{lid:lidA});const tidA=r.id;
await A('POST','/api/admin/apc',{key:'testkey12345',whsec:'whsec_test123'});
const bA=await W(BU);r=await BU('POST','/api/apay',{tid:tidA});const pA=r;ok(pA.id&&pA.tid===tidA&&pA.amt>55000&&pA.amt<=55099,'apc buy: payment for the item with unique amount');
r=await BU('POST','/api/apay',{tid:tidA});ok(r.id===pA.id,'apc buy: reopening returns the same open payment');
r=await S('POST','/api/apay',{tid:tidA});ok(r.error==='not_found','apc buy: only the buyer can pay the thread');
const eA=extOf(pA);await hook({event:'payment.paid',order_id:eA,status:'paid',amount:pA.amt,card_last4:L4});
r=await BU('GET','/api/threads/'+tidA);ok(r.thread.status==='paid','apc buy: deal moved to escrow automatically');
ok(await W(BU)===bA+pA.amt-55000,'apc buy: price taken, extra kopecks stay in wallet');
r=await U('GET','/api/listings/'+lidA);ok(r.item.status==='sold','apc buy: listing marked sold');
r=await BU('POST','/api/apay',{tid:tidA});ok(r.error==='unavailable','apc buy: cannot pay an already paid thread');
r=await A('GET','/api/admin/payments');ok(r.items!==undefined,'admin payments list still works');
globalThis.fetch=rf;
}
// admin password reset from the command line (works even if the password was lost)
{
const cp=require('child_process');const o=cp.spawnSync(process.execPath,['--disable-warning=ExperimentalWarning',path.join(__dirname,'..','server.js'),'--reset-admin','NewPass9900'],{env:{...process.env,PORT:'3998'},encoding:'utf8'});
ok(o.status===0&&o.stdout.includes('NewPass9900'),'CLI --reset-admin works');
r=await client()('POST','/api/login',{name:'admin',pass:'NewPass9900'});ok(r.role==='admin','admin logs in with the reset password');
r=await client()('POST','/api/login',{name:'admin',pass:'adminpass1'});ok(r.error==='bad_login','old password no longer works');
}
console.log(fails?`\n${fails} FAILED`:'\nALL PASSED');server.close();process.exit(fails?1:0)})().catch(e=>{console.error(e);process.exit(1)});
