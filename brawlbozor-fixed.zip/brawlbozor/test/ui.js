// Browser UI test (Playwright). node test/ui.js [outDir]
const os=require('os'),fs=require('fs'),path=require('path'),zlib=require('zlib');
const out=process.argv[2]||path.join(os.tmpdir(),'bb-shots');fs.mkdirSync(out,{recursive:true});
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'bb-ui-'));
Object.assign(process.env,{DATA_DIR:dir,PORT:'3100',BASE_URL:'http://localhost:3100',ADMIN_PASS:'adminpass1'});
const {server}=require('../server.js');const {chromium}=require('playwright');
const B='http://localhost:3100';let fails=0;const ok=(c,m)=>{console.log((c?'  ✓ ':'  ✗ FAIL ')+m);if(!c)fails++};
function png(w,h,rgb){const crc=(b)=>{let c,t=[];for(let n=0;n<256;n++){c=n;for(let k=0;k<8;k++)c=c&1?0xedb88320^(c>>>1):c>>>1;t[n]=c>>>0}let x=0xffffffff;for(const v of b)x=t[(x^v)&255]^(x>>>8);return(x^0xffffffff)>>>0};
const ch=(ty,d)=>{const l=Buffer.alloc(4);l.writeUInt32BE(d.length);const td=Buffer.concat([Buffer.from(ty),d]);const c=Buffer.alloc(4);c.writeUInt32BE(crc(td));return Buffer.concat([l,td,c])};
const raw=Buffer.alloc((w*3+1)*h);for(let y=0;y<h;y++){raw[y*(w*3+1)]=0;for(let x=0;x<w;x++){const o=y*(w*3+1)+1+x*3;raw[o]=Math.min(255,rgb[0]+x/2);raw[o+1]=Math.min(255,rgb[1]+y/2);raw[o+2]=rgb[2]}}
const ih=Buffer.alloc(13);ih.writeUInt32BE(w,0);ih.writeUInt32BE(h,4);ih[8]=8;ih[9]=2;return 'data:image/png;base64,'+Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),ch('IHDR',ih),ch('IDAT',zlib.deflateSync(raw)),ch('IEND',Buffer.alloc(0))]).toString('base64')}
function client(){let ck='';return async(m,p,b)=>{const r=await fetch(B+p,{method:m,headers:{'content-type':'application/json',cookie:ck},body:b?JSON.stringify(b):undefined});const s=r.headers.get('set-cookie');if(s)ck=s.split(';')[0];return{s:r.status,...await r.json()}}}
(async()=>{await new Promise(r=>server.listen(3100,r));
const A=client(),S=client();await A('POST','/api/login',{name:'admin',pass:'adminpass1'});await S('POST','/api/register',{name:'BrawlShop',pass:'secret12',adult:true});
const img=async(c)=>(await S('POST','/api/upload',{data:png(240,240,c)})).url;
const mk=async(b,approve=true)=>{const r=await S('POST','/api/listings',b);if(approve)await A('POST','/api/admin/listings/'+r.id+'/approve');return r.id};
await mk({cat:'gems',title:'170 Gem',price:89000,attrs:{gems:170,dm:'dm_gift'},imgs:[await img([20,160,60])],auto:'kod: ABCD-1234'});
await mk({cat:'gems',title:'80 Gem',price:59000,attrs:{gems:80,dm:'dm_id'},imgs:[]});
await mk({cat:'pass',title:'Brawl Pass Plus',price:149000,attrs:{season:'Season 38',tier:'pt_plus',dm:'dm_gift'},imgs:[]});
await mk({cat:'accounts',title:'Kuchli akkaunt 60k kubok',price:450000,attrs:{nick:'ProX',year:2019,tr:60000,br:80,pr:12,bind:'b1'},imgs:[await img([90,40,200]),await img([200,80,40])]});
const pend=await mk({cat:'trophy',title:'0 dan 20 000 gacha',price:120000,attrs:{from:0,to:20000,days:5},imgs:[]},false);
const br=await chromium.launch(),errs=[];
const newPage=async(ctx,name)=>{await ctx.route(/fonts\.(googleapis|gstatic)\.com/,r=>r.abort());const p=await ctx.newPage();p.on('pageerror',e=>errs.push(name+' pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'&&!/fonts\.|ERR_(INTERNET|NAME|CONNECTION|TUNNEL|PROXY|FAILED)|Failed to load resource/i.test(m.text()))errs.push(name+' console: '+m.text())});return p};
const ctx=await br.newContext({viewport:{width:390,height:844},deviceScaleFactor:2});const p=await newPage(ctx,'mobile');
const shot=async n=>{await p.waitForTimeout(350);await p.screenshot({path:path.join(out,n+'.png')})};
await p.goto(B+'/');await p.waitForSelector('#splash:not(.hide)');ok(true,'splash shown on first visit');await shot('01-splash');
await p.click('#sgo');await p.waitForSelector('#authf');await shot('02-welcome');
await p.click('[data-am=register]');await p.fill('#an','Player123');await p.fill('#ap','secret12');await p.check('#aa');await shot('03-register');await p.click('#ago');await p.waitForSelector('.pcard b:has-text("Player123")');ok(true,'registered via UI, home shows profile card');await p.waitForSelector('.pc');await shot('04-home');
ok((await p.$$('.pc')).length===4,'home lists 4 approved listings (pending hidden)');
{const us=(await A('GET','/api/admin/users?q=Player123')).items[0];await A('POST','/api/admin/users/'+us.id+'/balance',{amt:300000,reason:'ui test',op:'add'});}
await p.click('.bn [data-go=search]');await p.waitForSelector('.pc');await shot('05-search');
await p.goto(B+'/#categories');await p.waitForSelector('.cl button');await shot('06-categories');
await p.click('[data-cat=gems]');await p.waitForSelector('.pc');ok((await p.$$('.pc')).length===2,'gems category shows 2');await shot('07-shop-gems');
await p.click('.pc h3:has-text("170 Gem")');await p.waitForSelector('[data-buy]');await shot('08-item');
await p.click('[data-buy]');await p.waitForSelector('.pm');ok(true,'buy → chat → payment sheet opens automatically');await shot('09-pay-sheet');
ok((await p.$$('[data-m=demo]')).length===0,'pay sheet has no demo option');await p.click('[data-m=balance]');await p.click('#go');await p.waitForSelector('.m:has-text("ABCD-1234")',{timeout:8000});ok(true,'balance payment → auto-delivery message appears in chat');await shot('11-chat-paid');
await p.fill('#ci','Rahmat!');await p.press('#ci','Enter');await p.waitForSelector('.m.me:has-text("Rahmat")');ok(true,'chat message sent');
await p.click('[data-done]');await p.click('#cy');await p.waitForSelector('#rs');await p.click('#rsv');await p.waitForTimeout(1500);await p.waitForSelector('.tag:has-text("Baho berilgan")',{timeout:8000});ok(true,'confirm + review flow');
await p.fill('#ci','chat ochiq qoladi');await p.press('#ci','Enter');await p.waitForSelector('.m.me:has-text("chat ochiq qoladi")');ok(true,'chat stays open after sale completes');await shot('12-chat-done');
await p.goto(B+'/#wallet');await p.waitForSelector('.balcard');await p.click('[data-q="50000"]');await shot('13-wallet');
ok((await p.textContent('body')).toLowerCase().includes('demo')===false,'wallet shows no demo wording');await shot('14-wallet-after');
await p.goto(B+'/#history');await p.waitForSelector('.tx');await shot('15-history');
await p.goto(B+'/#orders');await p.waitForSelector('.dl');await shot('16-orders');
await p.goto(B+'/#profile');await p.waitForSelector('.menu');await shot('17-profile');
await p.goto(B+'/#settings');await p.waitForSelector('.kv');await shot('18-settings');
await p.goto(B+'/#support');await p.waitForSelector('.help');await shot('19-help');
await p.goto(B+'/#sell');await p.waitForSelector('#fg');await p.selectOption('#fc','pro');await p.fill('#ft','Pro Pass 39-mavsum');await p.fill('#sf_season','39');await p.fill('#fp','55000');await shot('20-sell');await p.click('#fg');await p.waitForSelector('.dl');ok(true,'new listing submitted (goes to review)');
await p.goto(B+'/#profile');await p.waitForSelector('.menu');await p.click('[data-go=history]');await p.waitForSelector('#app .chips');await p.click('[data-back]');await p.waitForSelector('.menu');ok(true,'back button works (history view -> profile)');await p.click('#lo');await p.waitForSelector('#hl');ok(true,'logout works');
// card deposit, verified badge, notifications
const luhnC=n=>{let s=0,d=false;for(let i=n.length-1;i>=0;i--){let x=+n[i];if(d){x*=2;if(x>9)x-=9}s+=x;d=!d}return s%10===0};let cnum;for(let c=0;c<10;c++)if(luhnC('986012345678901'+c)){cnum='986012345678901'+c;break}
await A('POST','/api/admin/cards',{num:cnum,holder:'ALI VALIYEV',bank:'Agro bank',kind:'humo'});
await p.evaluate(()=>fetch('/api/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Player123',pass:'secret12'})}));await p.goto(B+'/#wallet');await p.reload();await p.waitForSelector('[data-m=card]');await p.click('[data-m=card]');await p.fill('#ta','30000');await p.click('#tgo');await p.waitForSelector('[data-k]');await shot('25-pick-card');
await p.click('#kgo');await p.waitForSelector('.ccard');ok((await p.textContent('.ccard')).includes('9860 1234'),'card requisites shown to user');await shot('26-deposit-card');
await p.setInputFiles('#rf',{name:'r.png',mimeType:'image/png',buffer:Buffer.from(png(300,500,[240,240,240]).split(',')[1],'base64')});await p.waitForSelector('#rpv img');await p.click('#rgo');
await p.waitForSelector('.tag:has-text("Tekshirilmoqda")',{timeout:8000});ok(true,'receipt sent, deposit shows "Tekshirilmoqda"');await shot('27-deposit-review');
{const rf0=globalThis.fetch,apiO={};let nx=500;
globalThis.fetch=async(u,o={})=>{u=String(u);if(!u.startsWith('https://api.autopaycard.uz'))return rf0(u,o);const pth=u.slice(26),b=o.body?JSON.parse(o.body):{},R=(s,j)=>new Response(JSON.stringify(j),{status:s});
 if(pth==='/api/create-payment'){const id=String(nx++);apiO[id]={order_id:id,status:'waiting',amount:b.amount,card_last4:b.card_last4};return R(200,{success:true,order_id:id});}
 if(pth==='/api/check-payment'){const x=apiO[b.order_id];return x?R(200,x):R(404,{});}
 return R(404,{});};
const lu=n=>{let s=0,d=true;for(let k=n.length-1;k>=0;k--){let x=+n[k];if(d){x*=2;if(x>9)x-=9}s+=x;d=!d}return(10-s%10)%10},cn='860055556666777'+lu('860055556666777');
const cr=await A('POST','/api/admin/cards',{num:cn,holder:'KASSA EGASI',bank:'Uzcard',kind:'uzcard'});await A('POST','/api/admin/apc',{key:'uikey12345',gmail:'kassa@gmail.com',card:cr.id});
await p.goto(B+'/#wallet');await p.reload();await p.waitForSelector('[data-m=apc]');await p.click('[data-m=apc]');await p.fill('#ta','50000');await p.click('#tgo');await p.waitForSelector('#aps');
ok((await p.textContent('.ccard')).includes('8600 5555')&&/5 0\d{3}|50 0\d\d|50\s?0\d\d/.test((await p.textContent('dialog .kv')).replace(/\u00a0/g,' ')),'apc: dialog shows card + exact amount');
await p.waitForFunction(()=>/\d:\d\d/.test(document.querySelector('#aps').textContent));ok(true,'apc: 5-minute countdown running');await shot('28-autopay');
const e=Object.values(apiO)[0];e.status='paid';await p.waitForFunction(()=>document.querySelector('#aps')&&document.querySelector('#aps').textContent.includes('✅'),null,{timeout:15000});ok(true,'apc: paid status shown automatically');
// pay for an item directly through AutoPayCard from the checkout sheet
await p.goto(B+'/#market');await p.waitForSelector('.pc');await p.click('.pc h3:has-text("80 Gem")');await p.waitForSelector('[data-buy]');await p.click('[data-buy]');await p.waitForSelector('[data-m=apc]');await p.click('[data-m=apc]');await p.click('#go');await p.waitForSelector('#aps');
ok((await p.textContent('dialog .ccard')).includes('8600 5555'),'apc buy: item checkout shows the card to pay');await shot('28b-autopay-item');
Object.values(apiO).pop().status='paid';await p.waitForFunction(()=>document.querySelector('#aps')&&document.querySelector('#aps').textContent.includes('✅'),null,{timeout:15000});
await p.waitForFunction(()=>fetch('/api/threads').then(r=>r.json()).then(j=>j.items.some(x=>x.title==='80 Gem'&&x.status==='paid')),null,{timeout:10000,polling:700});ok(true,'apc buy: after payment the deal moved to escrow by itself');
globalThis.fetch=rf0;}
await A('POST','/api/admin/settings',{vf_mode:'approval'});
await p.goto(B+'/#verify');await p.waitForSelector('#vreq');await shot('28-verify-none');await p.click('#vreq');await p.waitForSelector('.tag:has-text("Admin tekshirmoqda")');ok(true,'badge request sent');
const vq=(await A('GET','/api/admin/verifs')).items;await A('POST','/api/admin/verifs/'+vq[0].id+'/approve');
await p.reload();await p.waitForSelector('#vpay');await shot('29-verify-pay');await p.click('#vpay');await p.waitForSelector('.pf svg.vb');ok(true,'badge activated, shown next to name');await shot('30-verify-active');
await p.goto(B+'/#profile');await p.waitForSelector('.menu');await shot('31-profile-badge');
await p.goto(B+'/#notifs');await p.waitForSelector('.nt');ok((await p.$$('.nt')).length>=3,'notifications listed');await shot('32-notifs');
// seller side
const sctx=await br.newContext({viewport:{width:390,height:844},deviceScaleFactor:2});const sp=await newPage(sctx,'seller');
await sp.goto(B+'/');await sp.evaluate(()=>localStorage.setItem('bb_seen','1'));await sp.reload();await sp.click('.pcard button');await sp.fill('#an','BrawlShop');await sp.fill('#ap','secret12');await sp.click('#ago');await sp.waitForSelector('.pcard b:has-text("BrawlShop")',{timeout:20000});
await sp.goto(B+'/#panel');await sp.waitForSelector('.stats');await sp.waitForTimeout(300);await sp.screenshot({path:path.join(out,'21-seller-panel.png')});
ok((await sp.textContent('.stats')).includes('1'),'seller panel shows 1 sale');
await A('POST','/api/admin/settings',{vf_mode:'instant'});await sp.goto(B+'/#verify');await sp.waitForSelector('#vpay');ok((await sp.$$('#vreq')).length===0,'badge (instant mode): no request form, pay button right away');await sp.click('#vpay');await sp.waitForSelector('.pf svg.vb',{timeout:8000});ok(true,'badge (instant mode): seller buys the badge himself');await sp.screenshot({path:path.join(out,'21b-seller-badge.png')});
// admin
const actx=await br.newContext({viewport:{width:1280,height:900}});const ap=await newPage(actx,'admin');
await ap.goto(B+'/admin');await ap.waitForSelector('#ago');await ap.fill('#ap','adminpass1');await ap.click('#ago');await ap.waitForSelector('.kp');await ap.screenshot({path:path.join(out,'22-admin-overview.png')});
await ap.click('[data-tab=listings]');await ap.waitForSelector('[data-approve]');await ap.screenshot({path:path.join(out,'23-admin-listings.png')});
const pc=(await ap.$$('[data-approve]')).length;ok(pc>=1,'admin sees pending listings with approve button ('+pc+')');
await ap.click('[data-approve]');await ap.waitForTimeout(600);ok((await ap.$$('[data-approve]')).length===pc-1,'approve removes it from pending');
await ap.click('[data-tab=apay]');await ap.waitForSelector('#ac_key');ok((await ap.textContent('#pg')).includes('AutoPayCard sozlamalari')&&!(await ap.content()).includes('uikey12345'),'admin: AutoPayCard tab renders, key not exposed');await ap.screenshot({path:path.join(out,'29-admin-apc.png'),fullPage:true});
await ap.click('[data-tab=payments]');await ap.waitForSelector('table.t');await ap.screenshot({path:path.join(out,'24-admin-payments.png')});
await ap.click('[data-tab=deposits]');await ap.waitForSelector('[data-dok]');await ap.screenshot({path:path.join(out,'25-admin-deposits.png')});ap.once('dialog',d=>d.accept());await ap.click('[data-dok]');await ap.waitForTimeout(1500);
const wl=await p.evaluate(()=>fetch('/api/wallet').then(r=>r.json()));ok(wl.deps.some(d=>d.status==='approved'),'admin approved deposit via UI → user sees "approved"');
await ap.click('[data-tab=cards]');await ap.waitForSelector('[data-cedit]');await ap.screenshot({path:path.join(out,'26-admin-cards.png')});
await ap.click('[data-tab=finance]');await ap.waitForSelector('.kp .hl');await ap.screenshot({path:path.join(out,'27-admin-finance.png')});
await ap.click('[data-tab=settings]');await ap.waitForSelector('#sgo');await ap.screenshot({path:path.join(out,'28-admin-settings.png')});
await ap.click('[data-tab=users]');await ap.waitForSelector('[data-ubal]');await ap.click('[data-uinfo]');await ap.waitForSelector('#dt');await ap.screenshot({path:path.join(out,'29-admin-user.png')});await ap.click('#close');
// desktop view of home
const dctx=await br.newContext({viewport:{width:1280,height:800}});const dp=await newPage(dctx,'desktop');await dp.goto(B+'/');await dp.evaluate(()=>localStorage.setItem('bb_seen','1'));await dp.goto(B+'/#market');await dp.waitForSelector('.pc');await dp.screenshot({path:path.join(out,'25-desktop-shop.png')});
ok(errs.length===0,'no JS/console errors'+(errs.length?': '+errs.join(' | '):''));
await br.close();console.log(fails?`\n${fails} FAILED`:'\nUI ALL PASSED');server.close();process.exit(fails?1:0)})().catch(e=>{console.error(e);process.exit(1)});
