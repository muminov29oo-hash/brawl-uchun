# BrawlBozor

Brawl Stars akkaunt/xizmatlari uchun marketplace: **escrow** (pul sotuvchiga faqat xaridor tasdiqlagach o'tadi), **Payme va Click** orqali avtomatik to'lov, balans, chat, nizo, sharhlar, **admin panel**. Tashqi kutubxonalarsiz (zero-dependency), faqat **Node.js 22.13+**.

## Tez ishga tushirish

```bash
node -v            # v22.13 yoki yuqori bo'lsin
cp .env.example .env   # ADMIN_PASS va BASE_URL ni to'ldiring
npm start          # http://localhost:3000
```
Sayt: `http://localhost:3000` · Admin: `http://localhost:3000/admin` (login: `admin`).

**Demo/test to'lov rejimi yo'q**: barcha to'lovlar haqiqiy. Pul kiritish usullari: balans, AutoPayCard (avtomatik karta), Payme, Click, qo'lda kartaga o'tkazish (chek bilan). Provayder sozlanmagan bo'lsa, o'sha usul ko'rinmaydi.

## Admin paroli
- `.env` da `ADMIN_PASS=...` bersangiz, server **har safar ishga tushganda** admin parolini shunga tenglashtiradi. Parol "yo'qolib" qolmaydi.
- `ADMIN_PASS` bo'sh bo'lsa, birinchi ishga tushishda tasodifiy parol yaratiladi va konsolga hamda `DATA_DIR/admin-password.txt` ga yoziladi.
- Parolni unutdingizmi: `node server.js --reset-admin YangiParol` (yoki `npm run admin:reset -- YangiParol`).
- Kirishga urinishlar (login+IP bo'yicha) 10 daqiqada 10 tagacha; muvaffaqiyatli kirishda hisoblagich tozalanadi.

## Baza doim saqlanishi (MUHIM)
Hamma narsa `DATA_DIR` papkasida: `bb.sqlite` (baza), `uploads/` (rasmlar), `backups/` (zaxira).
1. **Hostingda doimiy disk (volume) ulang** va `DATA_DIR` ni shu diskka yo'naltiring (Docker: `-v bbdata:/data`, Render/Railway/Fly: Persistent Disk/Volume `/data`). Disksiz (ephemeral) hostingda har deploy/restartda baza o'chadi: bu kodda hal bo'lmaydi.
2. Baza `synchronous=FULL` + WAL rejimida: har bir pul amali diskka yozilgach tasdiqlanadi. Server to'xtatilganda (SIGTERM/SIGINT) baza toza yopiladi.
3. **Avtomatik zaxira**: har 6 soatda `DATA_DIR/backups/` ga izchil nusxa olinadi (oxirgi 28 tasi qoladi, `BACKUP_KEEP`).
4. Admin panel → **Sozlamalar → Baza va zaxira nusxalar**: hajm, papka yo'li, "Hozir zaxira olish", nusxani **yuklab olish**. Papka ilova ichida bo'lsa, ogohlantirish chiqadi.
5. Nusxalarni boshqa joyga ham saqlang (disk buzilsa, shu papkadagi nusxalar ham yo'qoladi). Tiklash: serverni to'xtating, nusxani `bb.sqlite` nomi bilan `DATA_DIR` ga qo'ying (eski `bb.sqlite-wal`/`-shm` fayllarni o'chiring).

## Haqiqiy to'lovni ulash (production)
1. **Server + domen + HTTPS** kerak. Masalan Caddy: `brawlbozor.uz { reverse_proxy localhost:3000 }`; `.env` da `BASE_URL=https://brawlbozor.uz`, `TRUST_PROXY=1`.
2. **AutoPayCard** (avtomatik UzCard/Humo): quyida.
3. **Payme Business**: Endpoint URL `https://DOMEN/api/payme`, account maydoni `order_id`; `.env`: `PAYME_MERCHANT_ID`, `PAYME_KEY`.
4. **Click Merchant** (SHOP API): Prepare `https://DOMEN/api/click/prepare`, Complete `https://DOMEN/api/click/complete`; `.env`: `CLICK_SERVICE_ID`, `CLICK_MERCHANT_ID`, `CLICK_SECRET_KEY`, `CLICK_MERCHANT_USER_ID`.
5. `ADMIN_PASS` ni kuchli qiling, `DATA_DIR` ni doimiy diskka qo'ying.

## Google bilan kirish
Admin panel → **Sozlamalar → Google orqali kirish** ga Client ID ni yozing: **qayta ishga tushirish shart emas**, kirish oynasida "Google bilan davom etish" tugmasi paydo bo'ladi.
1. console.cloud.google.com → APIs & Services → Credentials → Create credentials → **OAuth client ID** → *Web application*.
2. **Authorized JavaScript origins** ga `BASE_URL` ni qo'shing (masalan `https://brawlbozor.uz`; sinash uchun `http://localhost:3000`).
3. Client ID (`...apps.googleusercontent.com`) ni admin panelga yoki `.env` dagi `GOOGLE_CLIENT_ID` ga yozing.
Birinchi kirishda akkaunt avtomatik ochiladi (nom emailning boshidan olinadi), 18+ tasdig'i so'raladi. Token serverda Google orqali tekshiriladi (aud, iss, email_verified, muddat).

## Qanday ishlaydi

| Oqim | Tavsif |
|---|---|
| Balansni to'ldirish | Foydalanuvchi summa kiritadi → Payme/Click sahifasi → to'lov o'tgach provayder serverga callback yuboradi → balans **avtomatik** to'ldiriladi (qayta chaqiruvlar ikki marta qo'shmaydi). |
| Xarid | Tovar sahifasi → "Sotib olish" → chat ochiladi → to'lov (balans / Payme / Click) → pul **escrow**da → sotuvchi topshiradi (avto-yetkazish bo'lsa darhol chatga tushadi) → xaridor tasdiqlaydi. |
| Sotuvchiga pul | Tasdiqlagach komissiya (`FEE_PERCENT`) ushlanadi, qolgani `HOLD_DAYS` kunga ushlab turiladi, keyin sotuvchi balansiga o'tadi (admin oldinroq ham ocha oladi). |
| Nizo | Xaridor nizo ochadi → pul muzlaydi → admin chatni ko'radi va pulni xaridorga yoki sotuvchiga o'tkazadi. Chat hech qachon yopilmaydi. |
| Pul yechish | Sotuvchi karta kiritadi → admin panelda so'rov chiqadi → admin kartaga o'zi o'tkazadi → "To'landi" bosadi (rad etilsa pul balansga qaytadi). |
| E'lon | Kategoriyaga xos maydonlar (Pro Pass uchun mavsum, Gem uchun soni va h.k., kubok/prestij faqat akkauntlarda). Admin tasdiqlaydi. Telefon/havola/messenjer yozish taqiqlangan (chatda ham). |

## Admin panel (`/admin`)
Umumiy statistika · e'lonlarni **tasdiqlash/rad etish/o'chirish** · nizolar (chatni ko'rish, **xaridorga qaytarish / sotuvchiga o'tkazish**) · pul yechish so'rovlari (**To'landi / Rad**) · ushlab turilgan mablag'lar · foydalanuvchilar (blok) · to'lovlar · murojaatlar · jurnal.

## Xavfsizlik
Parollar scrypt bilan, sessiyalar HttpOnly cookie, CSP, so'rov limitlari, Payme (Basic auth) va Click (MD5 imzo) tekshiruvi, barcha pul amallari SQL tranzaksiyada, karta ma'lumotlari saytda **hech qachon** kiritilmaydi (faqat Payme/Click sahifasida). Karta raqami faqat pul yechish so'rovida admin ko'rishi uchun saqlanadi.

## Cheklovlar (ochiq aytamiz)
- Sotuvchilarga pul chiqarish **qo'lda** (admin kartaga o'tkazadi). Avtomatik payout uchun alohida bank/Payme "Subscribe/Payout" shartnomasi kerak.
- Kirish: login/parol yoki Google. Telegram orqali kirish yo'q.
- Sayt Supercell bilan bog'liq emas; Brawl Stars akkaunt savdosi o'yin qoidalariga zid bo'lishi mumkin: huquqiy tomonini o'zingiz hal qiling.
- Bitta server + SQLite (kichik/o'rta trafik uchun yetarli). Katta yuk uchun PostgreSQL va bir nechta instans kerak bo'ladi.

## Testlar
`npm test` — server oqimi (to'lov, escrow, nizo, Payme/Click/AutoPayCard, galochka, zaxira, Google, admin parol).
`npm run test:ui` — brauzerda (Playwright o'rnatilgan bo'lsa) butun UI.


## Galochka (tasdiqlangan profil)
Admin panel → Sozlamalar → **Galochka olish tartibi**:
- **Foydalanuvchi o'zi sotib oladi** (standart): Profil → Galochka → balansdan to'laydi, admin tasdig'i shart emas.
- **Avval admin tasdiqlaydi**: foydalanuvchi so'rov yuboradi, admin tasdiqlagach to'laydi.
Narx va muddat sozlamalarda. Foydalanuvchi **avto-yangilash** ni yoqsa, muddat tugaganda narx balansdan o'zi yechiladi (balans yetmasa galochka olinadi va xabar boradi). Admin istalgan foydalanuvchiga galochka berishi yoki olib tashlashi mumkin.

## AutoPayCard (avtomatik karta to‘lovi)

1. `@Autopaycardbot` da obuna oling, kartani va Gmail’ni ulang (botdagi ko‘rsatma bo‘yicha), API kalitni oling.
2. Admin panel → **Kartalar** bo‘limida qabul qiluvchi kartani qo‘shing.
3. Admin panel → **AutoPayCard**: API kalit, (ixtiyoriy) webhook imzo kaliti, Gmail va kartani tanlang → **Saqlash** → **Ulanishni tekshirish**.
4. AutoPayCard botida webhook manzilini kiriting: `https://SIZNING-DOMEN/api/apc/webhook` (domen HTTPS bo‘lishi shart).
   **Tovarni to‘g‘ridan-to‘g‘ri to‘lash**: xarid oynasida "Avtomatik to‘lov" tanlansa, noyob summa kartaga o‘tgach pul hamyonga tushadi va deal **avtomatik escrow ga o‘tadi** (ortiqcha tiyinlar hamyonda qoladi). Hamyonni to‘ldirish ham shu usulda.

Webhook ishlamasa ham server har ~4 soniyada (bir vaqtda 5 tagacha) `check-payment` orqali ochiq to‘lovlarni o‘zi tekshiradi (qayta ishga tushganda ham bazadan davom etadi).

Qoidalar: har to‘lovga noyob summa (+1…99 so‘m), 5 daqiqa, bir order_id uchun balans faqat bir marta to‘ldiriladi, boshqa summa yoki kech o‘tkazma avtomatik tasdiqlanmaydi (admin "Qo‘lda tekshirish" ro‘yxatida ko‘radi va tasdiqlaydi/rad etadi).
Kalitlarni `.env` (`APC_API_KEY`, `APC_WEBHOOK_SECRET`, `APC_GMAIL`) yoki admin paneldan berish mumkin; brauzerga hech qachon yuborilmaydi.
