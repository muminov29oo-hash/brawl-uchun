'use strict';
/* BrawlBozor server: zero dependencies, Node 22.13+ (node:sqlite). */
const http = require('node:http'), fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

// ---------- config ----------
try { for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) { const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m && !(m[1] in process.env)) { let v = m[2]; const q = v.match(/^(["'])(.*?)\1/); v = q ? q[2] : v.replace(/\s+#.*$/, '').trim(); process.env[m[1]] = v; } } } catch { }
const E = process.env;
const CFG = {
  port: +E.PORT || 3000,
  base: (E.BASE_URL || 'http://localhost:' + (+E.PORT || 3000)).replace(/\/$/, ''),
  fee: +(E.FEE_PERCENT ?? 7), holdDays: +(E.HOLD_DAYS ?? 3),
  approval: E.REQUIRE_APPROVAL !== '0',
  data: path.resolve(E.DATA_DIR || path.join(__dirname, 'data')),
  payme: !!(E.PAYME_MERCHANT_ID && E.PAYME_KEY),
  click: !!(E.CLICK_SERVICE_ID && E.CLICK_MERCHANT_ID && E.CLICK_SECRET_KEY),
  boostPrice: 5000, minWithdraw: 10000, minTopup: +(E.MIN_TOPUP || 5000), topupFee: +(E.TOPUP_FEE ?? 0),
};
fs.mkdirSync(path.join(CFG.data, 'uploads'), { recursive: true });
const PUB = path.join(__dirname, 'public');

// ---------- db ----------
const db = new DatabaseSync(path.join(CFG.data, 'bb.sqlite'));
db.exec('PRAGMA busy_timeout=5000;'); try { db.exec('PRAGMA journal_mode=WAL;'); } catch { try { db.exec('PRAGMA journal_mode=DELETE;'); } catch { } }
try { db.exec('PRAGMA synchronous=FULL;'); } catch { }  // pul bilan ishlaymiz: har bir COMMIT diskka yozilib bo'lgach qaytadi
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT UNIQUE COLLATE NOCASE, salt TEXT, hash TEXT, role TEXT DEFAULT 'user', since INTEGER, seen INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, bal INTEGER DEFAULT 0, gid TEXT, email TEXT);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, uid INTEGER, ts INTEGER);
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY, seller INTEGER, cat TEXT, title TEXT, desc TEXT, price INTEGER, attrs TEXT, imgs TEXT, auto TEXT, status TEXT, reason TEXT, boost INTEGER DEFAULT 0, ts INTEGER);
CREATE INDEX IF NOT EXISTS li_s ON listings(status,cat);
CREATE TABLE IF NOT EXISTS threads(id INTEGER PRIMARY KEY, lid INTEGER, buyer INTEGER, seller INTEGER, title TEXT, price INTEGER, status TEXT, delivered INTEGER DEFAULT 0, fee INTEGER DEFAULT 0, rb INTEGER DEFAULT 0, rs INTEGER DEFAULT 0, ts INTEGER, upd INTEGER);
CREATE TABLE IF NOT EXISTS msgs(id INTEGER PRIMARY KEY, tid INTEGER, frm INTEGER, text TEXT, img TEXT, sys TEXT, offer INTEGER, offer_st TEXT, ts INTEGER);
CREATE INDEX IF NOT EXISTS ms_t ON msgs(tid,id);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, tid INTEGER, uid INTEGER, amount INTEGER, provider TEXT, status TEXT, ext TEXT, ts INTEGER, paid INTEGER, credit INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS ptx(seq INTEGER PRIMARY KEY, pid TEXT UNIQUE, oid INTEGER, time INTEGER, amount INTEGER, ctime INTEGER, ptime INTEGER DEFAULT 0, xtime INTEGER DEFAULT 0, state INTEGER, reason INTEGER);
CREATE TABLE IF NOT EXISTS holds(id INTEGER PRIMARY KEY, tid INTEGER, uid INTEGER, amt INTEGER, rel INTEGER, frozen INTEGER DEFAULT 0, released INTEGER DEFAULT 0, note TEXT);
CREATE TABLE IF NOT EXISTS tx(id INTEGER PRIMARY KEY, uid INTEGER, type TEXT, amt INTEGER, note TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS withdrawals(id INTEGER PRIMARY KEY, uid INTEGER, amt INTEGER, card TEXT, status TEXT, note TEXT, ts INTEGER, done INTEGER);
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, tid INTEGER, to_id INTEGER, from_id INTEGER, stars INTEGER, text TEXT, ts INTEGER, UNIQUE(tid,from_id));
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, uid INTEGER, subject TEXT, ref TEXT, status TEXT, ts INTEGER, upd INTEGER);
CREATE TABLE IF NOT EXISTS tmsgs(id INTEGER PRIMARY KEY, tk INTEGER, frm INTEGER, text TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS favs(uid INTEGER, lid INTEGER, PRIMARY KEY(uid,lid));
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, uid INTEGER, act TEXT, ref TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS cards(id INTEGER PRIMARY KEY, num TEXT, holder TEXT, bank TEXT, kind TEXT, active INTEGER DEFAULT 1, pos INTEGER DEFAULT 0, ts INTEGER);
CREATE TABLE IF NOT EXISTS deposits(id INTEGER PRIMARY KEY, uid INTEGER, amt INTEGER, card_id INTEGER, card TEXT, receipt TEXT, rhash TEXT, status TEXT, reason TEXT, adm INTEGER, ts INTEGER, upd INTEGER);
CREATE INDEX IF NOT EXISTS dp_u ON deposits(uid,id);
CREATE TABLE IF NOT EXISTS notifs(id INTEGER PRIMARY KEY, uid INTEGER, k TEXT, a TEXT, ts INTEGER, rd INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS nt_u ON notifs(uid,id);
CREATE TABLE IF NOT EXISTS income(id INTEGER PRIMARY KEY, type TEXT, amt INTEGER, ref TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS expense(id INTEGER PRIMARY KEY, type TEXT, amt INTEGER, note TEXT, adm INTEGER, ts INTEGER);
CREATE TABLE IF NOT EXISTS verifs(id INTEGER PRIMARY KEY, uid INTEGER, status TEXT, note TEXT, ts INTEGER, upd INTEGER);
`);
for (const q of ['ALTER TABLE orders ADD COLUMN credit INTEGER DEFAULT 0', 'ALTER TABLE users ADD COLUMN gid TEXT', 'ALTER TABLE users ADD COLUMN email TEXT', 'ALTER TABLE users ADD COLUMN vf INTEGER DEFAULT 0', 'ALTER TABLE users ADD COLUMN vf_ok INTEGER DEFAULT 0', 'ALTER TABLE users ADD COLUMN vf_auto INTEGER DEFAULT 0', 'ALTER TABLE withdrawals ADD COLUMN fee INTEGER', 'ALTER TABLE withdrawals ADD COLUMN net INTEGER', 'ALTER TABLE withdrawals ADD COLUMN holder TEXT', 'ALTER TABLE withdrawals ADD COLUMN method TEXT']) { try { db.exec(q); } catch { } }
db.exec('CREATE UNIQUE INDEX IF NOT EXISTS u_gid ON users(gid) WHERE gid IS NOT NULL');
db.exec(`CREATE TABLE IF NOT EXISTS apay(id INTEGER PRIMARY KEY, uid INTEGER, amt INTEGER, last4 TEXT, ext TEXT, status TEXT, note TEXT, ts INTEGER, exp INTEGER, upd INTEGER, paid INTEGER, adm INTEGER, tid INTEGER DEFAULT 0);
CREATE UNIQUE INDEX IF NOT EXISTS ap_ext ON apay(ext) WHERE ext IS NOT NULL;
CREATE INDEX IF NOT EXISTS ap_s ON apay(status,ts);`);
try { db.exec('ALTER TABLE apay ADD COLUMN tid INTEGER DEFAULT 0'); } catch { }
const P = new Map(), st = s => { let x = P.get(s); if (!x) { x = db.prepare(s); P.set(s, x); } return x; };
const all = (s, ...a) => st(s).all(...a), get = (s, ...a) => st(s).get(...a), run = (s, ...a) => st(s).run(...a);
const now = () => Date.now();
const DEF = { fee: +(E.FEE_PERCENT ?? 7), hold_days: 0, wd_lock_days: 2, wd_fee_pct: 2, vf_price: 30000, vf_days: 30, vf_renew: 'auto', vf_mode: 'instant', pay_fee_pct: 0 };
for (const [k, v] of Object.entries(DEF)) run('INSERT OR IGNORE INTO settings(k,v) VALUES(?,?)', k, String(v));
const sv = k => { const r = get('SELECT v FROM settings WHERE k=?', k); return r ? r.v : String(DEF[k]); }, sn = k => +sv(k);
if (!get("SELECT 1 x FROM settings WHERE k='mig_vf2'")) { run("UPDATE settings SET v='auto' WHERE k='vf_renew'"); run("INSERT INTO settings(k,v) VALUES('mig_vf2','1')"); }
if (!get("SELECT 1 x FROM settings WHERE k='db_created'")) run("INSERT INTO settings(k,v) VALUES('db_created',?)", String(Date.now()));
const googleId = () => { const r = get("SELECT v FROM settings WHERE k='google_id'"); return (r && r.v.trim()) || E.GOOGLE_CLIENT_ID || ''; };
const notify = (uid, k, a = []) => { if (uid) run('INSERT INTO notifs(uid,k,a,ts) VALUES(?,?,?,?)', uid, k, JSON.stringify(a), now()); };
const notifyAdmins = (k, a = []) => { for (const x of all("SELECT id FROM users WHERE role='admin'")) notify(x.id, k, a); };
const earn = (type, amt, ref) => { if (amt > 0) run('INSERT INTO income(type,amt,ref,ts) VALUES(?,?,?,?)', type, amt, String(ref ?? ''), now()); };
const lockedOf = uid => get("SELECT COALESCE(SUM(amt),0) s FROM tx WHERE uid=? AND type='sale' AND ts>?", uid, now() - sn('wd_lock_days') * 864e5).s;
const freshBal = uid => get('SELECT bal FROM users WHERE id=?', uid).bal;
if (!get("SELECT 1 x FROM settings WHERE k='inc_bf'")) { db.exec("INSERT INTO income(type,amt,ref,ts) SELECT 'fee',fee,'thread:'||id,upd FROM threads WHERE status='done' AND fee>0"); run("INSERT INTO settings(k,v) VALUES('inc_bf','1')"); }
const audit = (u, act, ref) => run('INSERT INTO logs(uid,act,ref,ts) VALUES(?,?,?,?)', u ? u.id : null, act, String(ref ?? ''), now());

// ---------- categories (single source of truth, served to client) ----------
const DM = ['dm_gift', 'dm_id', 'dm_link'];
const CATS = {
  accounts: { img: 2, f: [{ k: 'nick', t: 'text', r: 1, max: 20 }, { k: 'year', t: 'num', r: 1, min: 2017, max: 'year' }, { k: 'tr', t: 'num', r: 1, min: 0, max: 200000 }, { k: 'br', t: 'num', r: 1, min: 0, max: 100 }, { k: 'pr', t: 'num', min: 0, max: 100000 }, { k: 'bind', t: 'sel', r: 1, o: ['b1', 'b2', 'b3'] }] },
  gems: { img: 0, f: [{ k: 'gems', t: 'num', r: 1, min: 1, max: 1000000 }, { k: 'dm', t: 'sel', r: 1, o: DM }] },
  pass: { img: 0, f: [{ k: 'season', t: 'text', r: 1, max: 40 }, { k: 'tier', t: 'sel', r: 1, o: ['pt_std', 'pt_plus'] }, { k: 'dm', t: 'sel', r: 1, o: DM }] },
  pro: { img: 0, f: [{ k: 'season', t: 'text', r: 1, max: 40 }, { k: 'dm', t: 'sel', r: 1, o: DM }] },
  topup: { img: 0, f: [{ k: 'pack', t: 'text', r: 1, max: 60 }, { k: 'dm', t: 'sel', r: 1, o: DM }] },
  trophy: { img: 0, f: [{ k: 'from', t: 'num', r: 1, min: 0, max: 200000 }, { k: 'to', t: 'num', r: 1, min: 1, max: 200000 }, { k: 'brawler', t: 'text', max: 40 }, { k: 'days', t: 'num', r: 1, min: 1, max: 60 }] },
  rank: { img: 0, f: [{ k: 'brawler', t: 'text', r: 1, max: 40 }, { k: 'rfrom', t: 'num', r: 1, min: 1, max: 35 }, { k: 'rto', t: 'num', r: 1, min: 1, max: 35 }, { k: 'days', t: 'num', r: 1, min: 1, max: 60 }] },
  boost: { img: 0, f: [{ k: 'svc', t: 'text', r: 1, max: 80 }, { k: 'days', t: 'num', r: 1, min: 1, max: 60 }] },
  quests: { img: 0, f: [{ k: 'quest', t: 'text', r: 1, max: 80 }, { k: 'cnt', t: 'num', r: 1, min: 1, max: 1000 }, { k: 'days', t: 'num', r: 1, min: 1, max: 60 }] },
  pins: { img: 0, f: [{ k: 'brawler', t: 'text', max: 40 }, { k: 'pin', t: 'text', r: 1, max: 60 }, { k: 'cnt', t: 'num', r: 1, min: 1, max: 1000 }] },
  other: { img: 0, f: [] },
};
function cleanAttrs(cat, raw) {
  const out = {}; raw = raw && typeof raw === 'object' ? raw : {};
  for (const f of CATS[cat].f) {
    let v = raw[f.k];
    if (v === undefined || v === null || v === '') { if (f.r) throw err('f_' + f.k); continue; }
    if (f.t === 'num') { v = Number(v); const mx = f.max === 'year' ? new Date().getFullYear() : f.max; if (!Number.isInteger(v) || v < f.min || v > mx) throw err('f_' + f.k); }
    else if (f.t === 'sel') { if (!f.o.includes(v)) throw err('f_' + f.k); }
    else { v = String(v).trim().slice(0, f.max); if (!v && f.r) throw err('f_' + f.k); }
    out[f.k] = v;
  }
  if (cat === 'trophy' && out.to <= out.from) throw err('f_to');
  if (cat === 'rank' && out.rto <= out.rfrom) throw err('f_rto');
  return out;
}

// ---------- helpers ----------
class HttpErr extends Error { constructor(code, key) { super(key); this.code = code; this.key = key; } }
const err = (key, code = 400) => new HttpErr(code, key);
const EXT = /(https?:\/\/|www\.|t\.me|wa\.me|telegram|whatsapp|instagram|discord|(^|\s)@\w{3,}|\+\d[\d\s\-]{9,}\d|\b\d{2}[\s\-]\d{3}[\s\-]\d{2}[\s\-]\d{2}\b)/i;
const luhn = n => { let s = 0, d = false; for (let i = n.length - 1; i >= 0; i--) { let x = +n[i]; if (d) { x *= 2; if (x > 9) x -= 9; } s += x; d = !d; } return s % 10 === 0; };
const CARD_PREF = ['8600', '9860', '5614', '4', '5'];
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const int = (v, lo, hi) => { v = Number(v); if (!Number.isInteger(v) || v < lo || v > hi) throw err('bad_number'); return v; };
const J = s => { try { return JSON.parse(s); } catch { return null; } };
const rl = new Map();
function limit(key, max, ms) { const t = now(), a = (rl.get(key) || []).filter(x => t - x < ms); if (a.length >= max) throw err('rate', 429); a.push(t); rl.set(key, a); }
setInterval(() => { const t = now(); for (const [k, a] of rl) if (!a.some(x => t - x < 3600e3)) rl.delete(k); }, 600e3).unref();

const sysMsg = (tid, k, a = []) => run('INSERT INTO msgs(tid,frm,sys,ts) VALUES(?,?,?,?)', tid, null, JSON.stringify({ k, a }), now());
const touchThread = tid => run('UPDATE threads SET upd=? WHERE id=?', now(), tid);
const credit = (uid, amt, type, note) => { run('UPDATE users SET bal=bal+? WHERE id=?', amt, uid); run('INSERT INTO tx(uid,type,amt,note,ts) VALUES(?,?,?,?,?)', uid, type, amt, note || '', now()); };
const uPub = (id) => { const u = get('SELECT id,name,since,seen,vf FROM users WHERE id=?', id); if (!u) return null; const r = get('SELECT COUNT(*) n, AVG(stars) a FROM reviews WHERE to_id=?', id); return { id: u.id, name: u.name, since: u.since, online: now() - u.seen < 70000, vf: u.vf > now(), rn: r.n, ravg: r.a || 0 }; };

function fmtListing(l, viewer) {
  return { id: l.id, cat: l.cat, title: l.title, desc: l.desc, price: l.price, attrs: J(l.attrs) || {}, imgs: J(l.imgs) || [], isAuto: !!l.auto, status: l.status, reason: l.reason, boost: l.boost > now(), ts: l.ts, seller: uPub(l.seller), fav: viewer ? !!get('SELECT 1 x FROM favs WHERE uid=? AND lid=?', viewer.id, l.id) : false };
}

// ---------- payments core ----------
function markPaid(oid) {
  const o = get('SELECT * FROM orders WHERE id=?', oid); if (!o || o.status === 'paid') return;
  const pf = ['payme', 'click'].includes(o.provider) ? Math.round(o.amount * sn('pay_fee_pct') / 100) : 0; if (pf > 0) run("INSERT INTO expense(type,amt,note,ts) VALUES('pay_fee',?,?,?)", pf, o.provider + ' #' + oid, now());
  if (!o.tid) { run("UPDATE orders SET status='paid', paid=? WHERE id=?", now(), oid); credit(o.uid, o.credit || o.amount, 'topup', o.provider); notify(o.uid, 'n_credit', [o.credit || o.amount]); return; }
  const t = get('SELECT * FROM threads WHERE id=?', o.tid), l = t && get('SELECT * FROM listings WHERE id=?', t.lid);
  run("UPDATE orders SET status='paid', paid=? WHERE id=?", now(), oid);
  if (!t || t.status !== 'chat' || !l || l.status !== 'active') {  // lost the race: money goes to buyer wallet
    credit(o.uid, o.amount, 'refund', t ? t.title : ''); if (t) sysMsg(t.id, 'm_lost', [o.amount]); notify(o.uid, 'n_refund', [o.amount]); return;
  }
  run("UPDATE threads SET status='paid', price=?, upd=? WHERE id=?", o.amount, now(), t.id);
  run("UPDATE listings SET status='sold' WHERE id=?", l.id);
  run("UPDATE orders SET status='cancelled' WHERE tid=? AND status='new' AND id<>?", t.id, oid);
  sysMsg(t.id, 'm_paid2', [o.provider, o.amount]); notify(t.buyer, 'n_paid', [t.title]); notify(t.seller, 'n_neworder', [t.title, o.amount]);
  if (l.auto) run('INSERT INTO msgs(tid,frm,text,ts) VALUES(?,?,?,?)', t.id, t.seller, '⚡ ' + l.auto, now() + 1);
}
const feeOf = p => Math.round(p * sn('fee') / 100);
function releaseHold(h) { if (h.released) return; run('UPDATE holds SET released=1,frozen=0 WHERE id=?', h.id); credit(h.uid, h.amt, 'sale', h.note); }
function sweep() { try { db.exec('BEGIN IMMEDIATE'); for (const h of all('SELECT * FROM holds WHERE released=0 AND frozen=0 AND rel<=?', now())) releaseHold(h); db.exec('COMMIT'); } catch (e) { try { db.exec('ROLLBACK'); } catch { } console.error('sweep', e.message); } }
setInterval(sweep, 60e3).unref();

function checkoutUrl(o) {
  if (o.provider === 'payme') {
    const s = `m=${E.PAYME_MERCHANT_ID};ac.order_id=${o.id};a=${o.amount * 100};c=${CFG.base}/#${o.tid ? 'chat-' + o.tid : 'wallet'};l=uz`;
    return 'https://checkout.paycom.uz/' + Buffer.from(s).toString('base64');
  }
  const q = new URLSearchParams({ service_id: E.CLICK_SERVICE_ID, merchant_id: E.CLICK_MERCHANT_ID, amount: o.amount + '.00', transaction_param: String(o.id), return_url: `${CFG.base}/#${o.tid ? 'chat-' + o.tid : 'wallet'}` });
  if (E.CLICK_MERCHANT_USER_ID) q.set('merchant_user_id', E.CLICK_MERCHANT_USER_ID);
  return 'https://my.click.uz/services/pay?' + q;
}

// ---------- Payme Merchant API (JSON-RPC) ----------
const PE = (code, ru, uz, en, data) => ({ code, message: { ru, uz, en }, data });
const ERR = { auth: PE(-32504, 'Недостаточно привилегий', 'Ruxsat yoʻq', 'Insufficient privilege'), order: PE(-31050, 'Заказ не найден', 'Buyurtma topilmadi', 'Order not found', 'order_id'), amount: PE(-31001, 'Неверная сумма', 'Summa notoʻgʻri', 'Wrong amount'), state: PE(-31008, 'Невозможно выполнить операцию', 'Amalni bajarib boʻlmaydi', 'Cannot perform operation'), tnf: PE(-31003, 'Транзакция не найдена', 'Tranzaksiya topilmadi', 'Transaction not found'), cancel: PE(-31007, 'Заказ выполнен. Невозможно отменить', 'Buyurtma bajarilgan, bekor qilib boʻlmaydi', 'Order completed, cannot cancel'), method: PE(-32601, 'Метод не найден', 'Metod topilmadi', 'Method not found') };
const PAYME_TIMEOUT = 12 * 3600e3;
function paymeCall(method, p) {
  const chk = () => {
    const o = get('SELECT * FROM orders WHERE id=?', Number(p.account && p.account.order_id));
    if (!o || o.provider !== 'payme') throw { e: ERR.order };
    if (o.status !== 'new') throw { e: ERR.order };
    if (Number(p.amount) !== o.amount * 100) throw { e: ERR.amount };
    if (o.tid) { const t = get('SELECT * FROM threads WHERE id=?', o.tid), l = t && get('SELECT status FROM listings WHERE id=?', t.lid); if (!t || t.status !== 'chat' || !l || l.status !== 'active') throw { e: ERR.order }; }
    return o;
  };
  const out = x => ({ create_time: x.ctime, perform_time: x.ptime, cancel_time: x.xtime, transaction: String(x.seq), state: x.state, reason: x.reason ?? null });
  switch (method) {
    case 'CheckPerformTransaction': chk(); return { allow: true };
    case 'CreateTransaction': {
      let x = get('SELECT * FROM ptx WHERE pid=?', String(p.id));
      if (x) {
        if (x.state !== 1) throw { e: ERR.state };
        if (now() - x.ctime > PAYME_TIMEOUT) { run('UPDATE ptx SET state=-1,reason=4,xtime=? WHERE seq=?', now(), x.seq); throw { e: ERR.state }; }
        return { create_time: x.ctime, transaction: String(x.seq), state: 1 };
      }
      const o = chk();
      const busy = get('SELECT * FROM ptx WHERE oid=? AND state=1', o.id);
      if (busy) { if (now() - busy.ctime <= PAYME_TIMEOUT) throw { e: ERR.state }; run('UPDATE ptx SET state=-1,reason=4,xtime=? WHERE seq=?', now(), busy.seq); }
      const r = run('INSERT INTO ptx(pid,oid,time,amount,ctime,state) VALUES(?,?,?,?,?,1)', String(p.id), o.id, Number(p.time) || now(), Number(p.amount), now());
      return { create_time: now(), transaction: String(r.lastInsertRowid), state: 1 };
    }
    case 'PerformTransaction': {
      const x = get('SELECT * FROM ptx WHERE pid=?', String(p.id)); if (!x) throw { e: ERR.tnf };
      if (x.state === 2) return { transaction: String(x.seq), perform_time: x.ptime, state: 2 };
      if (x.state !== 1) throw { e: ERR.state };
      if (now() - x.ctime > PAYME_TIMEOUT) { run('UPDATE ptx SET state=-1,reason=4,xtime=? WHERE seq=?', now(), x.seq); throw { e: ERR.state }; }
      run('UPDATE ptx SET state=2,ptime=? WHERE seq=?', now(), x.seq); markPaid(x.oid);
      return { transaction: String(x.seq), perform_time: now(), state: 2 };
    }
    case 'CancelTransaction': {
      const x = get('SELECT * FROM ptx WHERE pid=?', String(p.id)); if (!x) throw { e: ERR.tnf };
      if (x.state === 1) { run('UPDATE ptx SET state=-1,reason=?,xtime=? WHERE seq=?', Number(p.reason) || null, now(), x.seq); return { transaction: String(x.seq), cancel_time: now(), state: -1 }; }
      if (x.state === 2) {
        const o = get('SELECT * FROM orders WHERE id=?', x.oid);
        if (!o.tid) {  // wallet top-up: reverse only if the money is still there
          const c = o.credit || o.amount, w = get('SELECT bal FROM users WHERE id=?', o.uid);
          if (!w || w.bal < c) throw { e: ERR.cancel };
          credit(o.uid, -c, 'refund', 'payme cancel'); run('UPDATE ptx SET state=-2,reason=?,xtime=? WHERE seq=?', Number(p.reason) || null, now(), x.seq); run("UPDATE orders SET status='cancelled' WHERE id=?", o.id);
          return { transaction: String(x.seq), cancel_time: now(), state: -2 };
        }
        const t = get('SELECT * FROM threads WHERE id=?', o.tid);
        if (!t || t.status !== 'paid') throw { e: ERR.cancel };
        run('UPDATE ptx SET state=-2,reason=?,xtime=? WHERE seq=?', Number(p.reason) || null, now(), x.seq);
        run("UPDATE orders SET status='cancelled' WHERE id=?", o.id); run("UPDATE threads SET status='refunded', upd=? WHERE id=?", now(), t.id);
        run("UPDATE listings SET status='active' WHERE id=?", t.lid); sysMsg(t.id, 'm_refund', []);
        return { transaction: String(x.seq), cancel_time: now(), state: -2 };
      }
      return { transaction: String(x.seq), cancel_time: x.xtime, state: x.state };
    }
    case 'CheckTransaction': { const x = get('SELECT * FROM ptx WHERE pid=?', String(p.id)); if (!x) throw { e: ERR.tnf }; return out(x); }
    case 'GetStatement': return { transactions: all('SELECT * FROM ptx WHERE ctime>=? AND ctime<=? ORDER BY ctime', Number(p.from), Number(p.to)).map(x => ({ id: x.pid, time: x.time, amount: x.amount, account: { order_id: x.oid }, create_time: x.ctime, perform_time: x.ptime, cancel_time: x.xtime, transaction: String(x.seq), state: x.state, reason: x.reason ?? null, receivers: null })) };
    default: throw { e: ERR.method };
  }
}
function paymeHandler(c) {
  const b = c.b || {}, id = b.id ?? null;
  const auth = c.req.headers.authorization || '';
  const ok = CFG.payme && (() => { try { const [u, k] = Buffer.from(auth.replace(/^Basic /i, ''), 'base64').toString().split(':'); const a = Buffer.from(k || ''), z = Buffer.from(E.PAYME_KEY); return u === 'Paycom' && a.length === z.length && crypto.timingSafeEqual(a, z); } catch { return false; } })();
  if (!ok) return { jsonrpc: '2.0', id, error: ERR.auth };
  try { return { jsonrpc: '2.0', id, result: paymeCall(b.method, b.params || {}) }; }
  catch (e) { if (e && e.e) return { jsonrpc: '2.0', id, error: e.e }; throw e; }
}

// ---------- Click Shop API ----------
const md5 = s => crypto.createHash('md5').update(s).digest('hex');
function clickHandler(kind) {
  return c => {
    const b = c.b || {}, base = { click_trans_id: b.click_trans_id, merchant_trans_id: b.merchant_trans_id }, bad = (error, error_note) => ({ ...base, error, error_note });
    if (!CFG.click) return bad(-8, 'Click disabled');
    const prep = kind === 'complete' ? String(b.merchant_prepare_id) : '';
    const sign = md5(`${b.click_trans_id}${b.service_id}${E.CLICK_SECRET_KEY}${b.merchant_trans_id}${prep}${b.amount}${b.action}${b.sign_time}`);
    if (sign !== b.sign_string) return bad(-1, 'SIGN CHECK FAILED!');
    if (String(b.service_id) !== String(E.CLICK_SERVICE_ID)) return bad(-8, 'service');
    if (Number(b.action) !== (kind === 'complete' ? 1 : 0)) return bad(-3, 'Action not found');
    const o = get('SELECT * FROM orders WHERE id=?', Number(b.merchant_trans_id));
    if (!o || o.provider !== 'click') return bad(-5, 'Order not found');
    if (Number(b.amount) !== o.amount) return bad(-2, 'Incorrect amount');
    if (kind === 'prepare') {
      if (o.status === 'paid') return bad(-4, 'Already paid'); if (o.status !== 'new') return bad(-9, 'Cancelled');
      if (o.tid) { const t = get('SELECT * FROM threads WHERE id=?', o.tid), l = t && get('SELECT status FROM listings WHERE id=?', t.lid); if (!t || t.status !== 'chat' || !l || l.status !== 'active') return bad(-9, 'Item unavailable'); }
      run('UPDATE orders SET ext=? WHERE id=?', String(b.click_trans_id), o.id);
      return { ...base, merchant_prepare_id: o.id, error: 0, error_note: 'Success' };
    }
    if (String(o.ext) !== String(b.click_trans_id) || Number(b.merchant_prepare_id) !== o.id) return bad(-6, 'Transaction not found');
    if (o.status === 'paid') return bad(-4, 'Already paid');
    if (Number(b.error) < 0) { run("UPDATE orders SET status='cancelled' WHERE id=?", o.id); return bad(-9, 'Transaction cancelled'); }
    if (o.status !== 'new') return bad(-9, 'Cancelled');
    markPaid(o.id);
    return { ...base, merchant_prepare_id: o.id, merchant_confirm_id: o.id, error: 0, error_note: 'Success' };
  };
}

// ---------- router ----------
const routes = [];
const R = (m, p, fn, o = {}) => routes.push({ m, keys: [...p.matchAll(/:(\w+)/g)].map(x => x[1]), re: new RegExp('^' + p.replace(/:\w+/g, '([^/]+)') + '$'), fn, ...o });
const need = c => { if (!c.u) throw err('auth', 401); return c.u; };
const admin = c => { const u = need(c); if (u.role !== 'admin') throw err('forbidden', 403); return u; };
const getThread = (c, id, opt = {}) => {
  const u = need(c), t = get('SELECT * FROM threads WHERE id=?', Number(id));
  if (!t || !(t.buyer === u.id || t.seller === u.id || (u.role === 'admin'))) throw err('not_found', 404);
  return t;
};

R('GET', '/api/config', () => ({ cats: CATS, fee: sn('fee'), holdDays: sn('hold_days'), lockDays: sn('wd_lock_days'), wdFee: sn('wd_fee_pct'), vf: { price: sn('vf_price'), days: sn('vf_days'), renew: sv('vf_renew'), mode: sv('vf_mode') }, manual: !!get('SELECT 1 x FROM cards WHERE active=1'), boostPrice: CFG.boostPrice, minWithdraw: CFG.minWithdraw, pay: { payme: CFG.payme, click: CFG.click, balance: true, apc: apcCfg().on }, google: googleId(), needApproval: CFG.approval, minTopup: CFG.minTopup, topupFee: CFG.topupFee }));
R('GET', '/api/stats', () => ({ offers: get("SELECT COUNT(*) n FROM listings WHERE status='active'").n, deals: get("SELECT COUNT(*) n FROM threads WHERE status='done'").n, online: get('SELECT COUNT(*) n FROM users WHERE seen>?', now() - 70000).n }));

// auth
function startSession(c, u) {
  const token = crypto.randomBytes(32).toString('hex'); run('INSERT INTO sessions(token,uid,ts) VALUES(?,?,?)', token, u.id, now());
  c.cookie = `bb_s=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${CFG.base.startsWith('https') ? '; Secure' : ''}`;
}
const meOut = u => u && ({ id: u.id, name: u.name, role: u.role, bal: u.bal, vf: u.vf > now() });
R('POST', '/api/register', c => {
  limit('reg' + c.ip, 10, 3600e3);
  const name = String(c.b.name || '').trim(), pw = String(c.b.pass || '');
  if (!c.b.adult) throw err('adult');
  if (!/^[\p{L}\p{N}_.-]{3,20}$/u.test(name) || /^(admin|support|moderator)$/i.test(name)) throw err('bad_name');
  if (pw.length < 6 || pw.length > 100) throw err('bad_pass');
  if (get('SELECT 1 x FROM users WHERE name=?', name)) throw err('name_taken', 409);
  const salt = crypto.randomBytes(16).toString('hex'), r = run('INSERT INTO users(name,salt,hash,since,seen) VALUES(?,?,?,?,?)', name, salt, hashPw(pw, salt), now(), now());
  const u = get('SELECT * FROM users WHERE id=?', r.lastInsertRowid); startSession(c, u); return meOut(u);
});
R('POST', '/api/login', c => {
  const nm = String(c.b.name || '').trim().toLowerCase().slice(0, 40); limit('login' + c.ip, 100, 600e3); limit('login' + c.ip + '|' + nm, 10, 600e3);
  const u = get('SELECT * FROM users WHERE name=?', String(c.b.name || '').trim());
  const ok = u && (() => { const a = Buffer.from(hashPw(String(c.b.pass || ''), u.salt)), z = Buffer.from(u.hash); return a.length === z.length && crypto.timingSafeEqual(a, z); })();
  if (!ok) throw err('bad_login', 401);
  if (u.banned) throw err('banned', 403);
  rl.delete('login' + c.ip + '|' + nm); startSession(c, u); return meOut(u);
});
async function verifyGoogle(c) {
  const gid = googleId(); if (!gid) throw err('provider'); limit('g' + c.ip, 20, 600e3);
  const tok = String(c.b.credential || ''); if (tok.length < 100 || tok.length > 4000) throw err('bad_login', 401);
  let j; try { const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(tok), { signal: AbortSignal.timeout(8000) }); if (!r.ok) throw 0; j = await r.json(); } catch { throw err('bad_login', 401); }
  if (j.aud !== gid || !['accounts.google.com', 'https://accounts.google.com'].includes(j.iss) || String(j.email_verified) !== 'true' || +j.exp * 1000 < now() || !j.sub || !j.email) throw err('bad_login', 401);
  c.g = { sub: String(j.sub), email: String(j.email).toLowerCase() };
}
R('POST', '/api/google', c => {
  const g = c.g; let u = get('SELECT * FROM users WHERE gid=?', g.sub);
  if (!u && g.email) { u = get("SELECT * FROM users WHERE email=? AND gid IS NULL AND role<>'admin'", g.email); if (u) run('UPDATE users SET gid=? WHERE id=?', g.sub, u.id); }
  if (!u) {
    if (!c.b.adult) throw err('adult');
    let base = g.email.split('@')[0].replace(/[^\p{L}\p{N}_.-]/gu, '').slice(0, 16); if (base.length < 3) base = 'user' + base; let name = base, i = 0;
    while (get('SELECT 1 x FROM users WHERE name=?', name) || /^(admin|support|moderator)$/i.test(name)) name = base.slice(0, 15) + (++i);
    const salt = crypto.randomBytes(16).toString('hex'), r = run('INSERT INTO users(name,salt,hash,since,seen,gid,email) VALUES(?,?,?,?,?,?,?)', name, salt, hashPw(crypto.randomBytes(24).toString('hex'), salt), now(), now(), g.sub, g.email);
    u = get('SELECT * FROM users WHERE id=?', r.lastInsertRowid);
  }
  if (u.banned) throw err('banned', 403); startSession(c, u); return meOut(u);
}, { pre: verifyGoogle });
R('POST', '/api/logout', c => { const m = (c.req.headers.cookie || '').match(/bb_s=(\w+)/); if (m) run('DELETE FROM sessions WHERE token=?', m[1]); c.cookie = 'bb_s=; Max-Age=0; Path=/'; return { ok: 1 }; });
R('GET', '/api/me', c => ({ me: meOut(c.u) }));

// uploads
R('POST', '/api/upload', c => {
  const u = need(c); limit('up' + u.id, 60, 600e3);
  const m = String(c.b.data || '').match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/); if (!m) throw err('bad_image');
  const buf = Buffer.from(m[2], 'base64'); if (buf.length > 2e6 || buf.length < 100) throw err('bad_image');
  const mg = { jpeg: [0xff, 0xd8, 0xff], png: [0x89, 0x50, 0x4e, 0x47], webp: [0x52, 0x49, 0x46, 0x46] }[m[1]]; if (!mg.every((x, i) => buf[i] === x)) throw err('bad_image');
  const f = crypto.randomBytes(12).toString('hex') + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]);
  fs.writeFileSync(path.join(CFG.data, 'uploads', f), buf); return { url: '/uploads/' + f };
}, { max: 3e6 });

// listings
R('GET', '/api/listings', c => {
  const q = c.q, cat = q.cat || 'accounts', s = String(q.q || '').toLowerCase(), n = k => q[k] === undefined || q[k] === '' ? null : Number(q[k]);
  let rows = all("SELECT l.* FROM listings l JOIN users u ON u.id=l.seller WHERE l.status='active' AND (?='all' OR l.cat=?) AND u.banned=0 ORDER BY l.id DESC LIMIT 800", cat, cat).map(l => fmtListing(l, c.u));
  const inr = (x, lo, hi) => (lo === null || x >= lo) && (hi === null || x <= hi);
  rows = rows.filter(a => (!s || (a.title + ' ' + a.desc + ' ' + Object.values(a.attrs).join(' ')).toLowerCase().includes(s)) && (cat !== 'accounts' || (inr(a.attrs.tr, n('t1'), n('t2')) && inr(a.attrs.br, n('b1'), n('b2')) && inr(a.attrs.pr || 0, n('p1'), n('p2')))) && inr(a.price, n('pmin'), n('pmax')) && (q.online !== '1' || a.seller.online) && (q.auto !== '1' || a.isAuto));
  rows.sort((a, b) => (b.boost - a.boost) || (q.sort === 'asc' ? a.price - b.price : q.sort === 'desc' ? b.price - a.price : b.id - a.id));
  const counts = {}; for (const r of all("SELECT cat, COUNT(*) n FROM listings WHERE status='active' GROUP BY cat")) counts[r.cat] = r.n;
  return { items: rows.slice(0, 100), counts };
});
R('GET', '/api/listings/:id', c => {
  const l = get('SELECT * FROM listings WHERE id=?', Number(c.p.id)); if (!l) throw err('not_found', 404);
  const own = c.u && (c.u.id === l.seller || c.u.role === 'admin'); if (!own && l.status !== 'active' && l.status !== 'sold') throw err('not_found', 404);
  return { item: fmtListing(l, c.u), reviews: all('SELECT r.stars,r.text,r.ts,u.name `from` FROM reviews r JOIN users u ON u.id=r.from_id WHERE r.to_id=? ORDER BY r.id DESC LIMIT 5', l.seller) };
});
R('POST', '/api/listings', c => {
  const u = need(c); limit('nl' + u.id, 20, 3600e3);
  const cat = String(c.b.cat); if (!CATS[cat]) throw err('bad_cat');
  const title = String(c.b.title || '').trim().slice(0, 80); if (title.length < 3) throw err('f_title');
  const price = int(c.b.price, 1000, 500000000), desc = String(c.b.desc || '').trim().slice(0, 600), auto = String(c.b.auto || '').trim().slice(0, 300);
  const attrs = cleanAttrs(cat, c.b.attrs);
  const imgs = (Array.isArray(c.b.imgs) ? c.b.imgs : []).filter(x => /^\/uploads\/[a-f0-9]{24}\.(jpg|png|webp)$/.test(x)).slice(0, 6);
  if (imgs.length < CATS[cat].img) throw err('e_img');
  if (EXT.test(title + ' ' + desc)) throw err('ext_listing');
  const status = (!CFG.approval || u.role === 'admin') ? 'active' : 'pending';
  const r = run('INSERT INTO listings(seller,cat,title,desc,price,attrs,imgs,auto,status,ts) VALUES(?,?,?,?,?,?,?,?,?,?)', u.id, cat, title, desc, price, JSON.stringify(attrs), JSON.stringify(imgs), auto, status, now());
  if (status === 'pending') notifyAdmins('n_listing', [title]);
  return { id: r.lastInsertRowid, status };
});
R('DELETE', '/api/listings/:id', c => {
  const u = need(c), l = get('SELECT * FROM listings WHERE id=?', Number(c.p.id)); if (!l || (l.seller !== u.id && u.role !== 'admin')) throw err('not_found', 404);
  if (l.status === 'sold') throw err('sold'); run("UPDATE listings SET status='deleted' WHERE id=?", l.id); if (u.role === 'admin') audit(u, 'listing_delete', l.id); return { ok: 1 };
});
R('POST', '/api/listings/:id/boost', c => {
  const u = need(c), l = get('SELECT * FROM listings WHERE id=?', Number(c.p.id)); if (!l || l.seller !== u.id || l.status !== 'active') throw err('not_found', 404);
  if (u.bal < CFG.boostPrice) throw err('no_funds'); credit(u.id, -CFG.boostPrice, 'fee', l.title); earn('boost', CFG.boostPrice, 'listing:' + l.id); run('UPDATE listings SET boost=? WHERE id=?', now() + 864e5, l.id); return { ok: 1 };
});
R('GET', '/api/my/listings', c => { const u = need(c); return { items: all("SELECT * FROM listings WHERE seller=? AND status<>'deleted' ORDER BY id DESC", u.id).map(l => ({ ...fmtListing(l, u), thread: (get("SELECT id,status FROM threads WHERE lid=? AND status<>'chat' ORDER BY id DESC", l.id) || null) })) }; });
R('POST', '/api/favs/:id', c => { const u = need(c), id = Number(c.p.id); if (get('SELECT 1 x FROM favs WHERE uid=? AND lid=?', u.id, id)) { run('DELETE FROM favs WHERE uid=? AND lid=?', u.id, id); return { fav: false }; } if (!get('SELECT 1 x FROM listings WHERE id=?', id)) throw err('not_found', 404); run('INSERT INTO favs VALUES(?,?)', u.id, id); return { fav: true }; });
R('DELETE', '/api/favs', c => { run('DELETE FROM favs WHERE uid=?', need(c).id); return { ok: 1 }; });
R('GET', '/api/favs', c => { const u = need(c); return { items: all("SELECT l.* FROM listings l JOIN favs f ON f.lid=l.id WHERE f.uid=? AND l.status='active' ORDER BY l.id DESC", u.id).map(l => fmtListing(l, u)) }; });
R('GET', '/api/users/:id', c => {
  const p = uPub(Number(c.p.id)); if (!p) throw err('not_found', 404);
  return { user: p, deals: get("SELECT COUNT(*) n FROM threads WHERE seller=? AND status='done'", p.id).n, items: all("SELECT * FROM listings WHERE seller=? AND status='active' ORDER BY id DESC LIMIT 50", p.id).map(l => fmtListing(l, c.u)), reviews: all('SELECT r.stars,r.text,r.ts,u.name `from` FROM reviews r JOIN users u ON u.id=r.from_id WHERE r.to_id=? ORDER BY r.id DESC LIMIT 10', p.id) };
});

// threads / chat
const unreadOf = (t, uid) => get('SELECT COUNT(*) n FROM msgs WHERE tid=? AND sys IS NULL AND frm<>? AND ts>?', t.id, uid, t.buyer === uid ? t.rb : t.rs).n;
const typing = new Map();
R('GET', '/api/threads', c => {
  const u = need(c);
  const rows = all('SELECT * FROM threads WHERE buyer=? OR seller=? ORDER BY upd DESC LIMIT 200', u.id, u.id).map(t => {
    const lm = get('SELECT text,img FROM msgs WHERE tid=? AND sys IS NULL ORDER BY id DESC LIMIT 1', t.id), l = get('SELECT imgs FROM listings WHERE id=?', t.lid);
    return { id: t.id, lid: t.lid, title: t.title, price: t.price, status: t.status, role: t.buyer === u.id ? 'buyer' : 'seller', other: uPub(t.buyer === u.id ? t.seller : t.buyer), unread: unreadOf(t, u.id), last: lm ? (lm.img ? '📷 ' : '') + (lm.text || '') : '', img: (J(l && l.imgs) || [])[0] || null, upd: t.upd };
  });
  return { items: rows, unread: rows.reduce((n, x) => n + x.unread, 0), nu: get('SELECT COUNT(*) n FROM notifs WHERE uid=? AND rd=0', u.id).n, bal: u.bal, uid: u.id, vf: u.vf > now() };
});
R('POST', '/api/threads', c => {
  const u = need(c), l = get('SELECT * FROM listings WHERE id=?', Number(c.b.lid)); if (!l || l.status !== 'active') throw err('unavailable');
  if (l.seller === u.id) throw err('own_item');
  let t = get('SELECT * FROM threads WHERE lid=? AND buyer=?', l.id, u.id);
  if (!t) { const r = run("INSERT INTO threads(lid,buyer,seller,title,price,status,ts,upd) VALUES(?,?,?,?,?,'chat',?,?)", l.id, u.id, l.seller, l.title, l.price, now(), now()); t = { id: r.lastInsertRowid }; sysMsg(t.id, 'm_start', [u.name, l.title]); }
  return { id: t.id };
});
R('GET', '/api/threads/:id', c => {
  const u = need(c), t = getThread(c, c.p.id), after = Number(c.q.after) || 0, isAdm = u.role === 'admin' && t.buyer !== u.id && t.seller !== u.id;
  if (!isAdm) run(`UPDATE threads SET ${t.buyer === u.id ? 'rb' : 'rs'}=? WHERE id=?`, now(), t.id);
  const msgs = all('SELECT m.*, u.name fname FROM msgs m LEFT JOIN users u ON u.id=m.frm WHERE m.tid=? AND m.id>? ORDER BY m.id', t.id, after).map(m => ({ id: m.id, from: m.fname || null, fromId: m.frm, text: m.text, img: m.img, sys: m.sys ? J(m.sys) : null, offer: m.offer ? { amt: m.offer, st: m.offer_st } : null, ts: m.ts }));
  const other = t.buyer === u.id ? t.seller : t.buyer, ty = typing.get(t.id), l = get('SELECT imgs,cat,status FROM listings WHERE id=?', t.lid), h = get('SELECT rel,frozen,released,amt FROM holds WHERE tid=? ORDER BY id DESC', t.id);
  return {
    thread: { id: t.id, lid: t.lid, title: t.title, price: t.price, status: t.status, delivered: !!t.delivered, role: isAdm ? 'admin' : t.buyer === u.id ? 'buyer' : 'seller', buyer: uPub(t.buyer), seller: uPub(t.seller), img: (J(l && l.imgs) || [])[0] || null, hold: h ? { rel: h.rel, frozen: !!h.frozen, released: !!h.released, amt: h.amt } : null, reviewed: !!get('SELECT 1 x FROM reviews WHERE tid=? AND from_id=?', t.id, u.id), otherRead: t.buyer === u.id ? t.rs : t.rb, typing: !!(ty && ty.u !== u.id && now() - ty.ts < 3500), bal: u.bal }, msgs,
  };
});
R('POST', '/api/threads/:id/msg', c => {
  const u = need(c), t = getThread(c, c.p.id); limit('msg' + u.id, 40, 60e3);
  const text = String(c.b.text || '').trim().slice(0, 1000); let img = null;
  if (c.b.img) { if (!/^\/uploads\/[a-f0-9]{24}\.(jpg|png|webp)$/.test(c.b.img)) throw err('bad_image'); img = c.b.img; }
  if (!text && !img) throw err('empty');
  if (u.role !== 'admin' && EXT.test(text)) throw err('ext_chat');
  run('INSERT INTO msgs(tid,frm,text,img,ts) VALUES(?,?,?,?,?)', t.id, u.id, text, img, now()); touchThread(t.id); typing.delete(t.id); return { ok: 1 };
});
R('POST', '/api/threads/:id/typing', c => { const u = need(c), t = getThread(c, c.p.id); typing.set(t.id, { u: u.id, ts: now() }); return { ok: 1 }; });
R('POST', '/api/threads/:id/offer', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.buyer !== u.id || t.status !== 'chat') throw err('forbidden', 403);
  const am = int(c.b.amt, 1000, t.price - 1); if (get("SELECT 1 x FROM msgs WHERE tid=? AND offer_st='p'", t.id)) throw err('offer_pending');
  run("INSERT INTO msgs(tid,frm,offer,offer_st,ts) VALUES(?,?,?,'p',?)", t.id, u.id, am, now()); touchThread(t.id); return { ok: 1 };
});
R('POST', '/api/threads/:id/offer/:mid', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.seller !== u.id || t.status !== 'chat') throw err('forbidden', 403);
  const m = get("SELECT * FROM msgs WHERE id=? AND tid=? AND offer_st='p'", Number(c.p.mid), t.id); if (!m) throw err('not_found', 404);
  if (c.b.accept) { run("UPDATE msgs SET offer_st='y' WHERE id=?", m.id); run('UPDATE threads SET price=? WHERE id=?', m.offer, t.id); run("UPDATE orders SET status='cancelled' WHERE tid=? AND status='new'", t.id); sysMsg(t.id, 'off_ok', [m.offer]); }
  else { run("UPDATE msgs SET offer_st='n' WHERE id=?", m.id); sysMsg(t.id, 'off_no', []); }
  touchThread(t.id); return { ok: 1 };
});
R('POST', '/api/threads/:id/pay', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.buyer !== u.id) throw err('forbidden', 403);
  const l = get('SELECT * FROM listings WHERE id=?', t.lid); if (t.status !== 'chat' || !l || l.status !== 'active') throw err('unavailable');
  limit('pay' + u.id, 20, 600e3);
  const pv = String(c.b.provider), mk = (provider, status = 'new') => run('INSERT INTO orders(tid,uid,amount,provider,status,ts) VALUES(?,?,?,?,?,?)', t.id, u.id, t.price, provider, status, now()).lastInsertRowid;
  if (pv === 'balance') { if (u.bal < t.price) throw err('no_funds'); credit(u.id, -t.price, 'buy', t.title); const id = mk('balance'); markPaid(id); return { paid: true }; }
  if (pv === 'payme' && CFG.payme) { const id = mk('payme'); return { url: checkoutUrl({ id, tid: t.id, amount: t.price, provider: 'payme' }) }; }
  if (pv === 'click' && CFG.click) { const id = mk('click'); return { url: checkoutUrl({ id, tid: t.id, amount: t.price, provider: 'click' }) }; }
  throw err('provider');
});
R('POST', '/api/topup', c => {
  const u = need(c); limit('top' + u.id, 15, 600e3);
  const amt = int(c.b.amt, CFG.minTopup, 50000000), pv = String(c.b.provider), fee = Math.round(amt * CFG.topupFee / 100), total = amt + fee;
  const mk = p => run("INSERT INTO orders(tid,uid,amount,credit,provider,status,ts) VALUES(0,?,?,?,?,'new',?)", u.id, total, amt, p, now()).lastInsertRowid;
  if (pv === 'payme' && CFG.payme) { const id = mk('payme'); return { url: checkoutUrl({ id, tid: 0, amount: total, provider: 'payme' }) }; }
  if (pv === 'click' && CFG.click) { const id = mk('click'); return { url: checkoutUrl({ id, tid: 0, amount: total, provider: 'click' }) }; }
  throw err('provider');
});
R('GET', '/api/seller/stats', c => {
  const u = need(c), since = now() - 30 * 864e5, s = get("SELECT COUNT(*) n, COALESCE(SUM(price),0) s FROM threads WHERE seller=? AND status='done' AND upd>?", u.id, since), r = get('SELECT AVG(stars) a, COUNT(*) n FROM reviews WHERE to_id=?', u.id);
  return {
    bal: u.bal, sales: s.n, turnover: s.s, rating: r.a || 0, rn: r.n, pending: get('SELECT COALESCE(SUM(amt),0) s FROM holds WHERE uid=? AND released=0', u.id).s,
    active: get("SELECT COUNT(*) n FROM listings WHERE seller=? AND status='active'", u.id).n, buys: get("SELECT COUNT(*) n FROM threads WHERE buyer=? AND status IN ('paid','done')", u.id).n,
    recent: all("SELECT id,title,price,upd FROM threads WHERE seller=? AND status='done' ORDER BY upd DESC LIMIT 8", u.id),
  };
});
R('POST', '/api/threads/:id/deliver', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.seller !== u.id || t.status !== 'paid' || t.delivered) throw err('forbidden', 403);
  run('UPDATE threads SET delivered=1 WHERE id=?', t.id); sysMsg(t.id, 'm_deliv', [u.name]); touchThread(t.id); return { ok: 1 };
});
R('POST', '/api/threads/:id/confirm', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.buyer !== u.id || t.status !== 'paid') throw err('forbidden', 403);
  const fee = feeOf(t.price), net = t.price - fee;
  run("UPDATE threads SET status='done', fee=?, upd=? WHERE id=?", fee, now(), t.id); earn('fee', fee, 'thread:' + t.id);
  const hd = sn('hold_days');
  if (hd > 0) run('INSERT INTO holds(tid,uid,amt,rel,note) VALUES(?,?,?,?,?)', t.id, t.seller, net, now() + hd * 864e5, t.title); else credit(t.seller, net, 'sale', t.title);
  sysMsg(t.id, hd > 0 ? 'm_done' : 'm_done0', [net, hd]); notify(t.seller, 'n_sale', [t.title, net]); notify(t.buyer, 'n_done', [t.title]); return { ok: 1 };
});
R('POST', '/api/threads/:id/dispute', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.buyer !== u.id) throw err('forbidden', 403);
  const h = get('SELECT * FROM holds WHERE tid=? AND released=0', t.id);
  if (!(t.status === 'paid' || (t.status === 'done' && h))) throw err('forbidden', 403);
  run("UPDATE threads SET status='dispute', upd=? WHERE id=?", now(), t.id); if (h) run('UPDATE holds SET frozen=1 WHERE id=?', h.id);
  const tk = run("INSERT INTO tickets(uid,subject,ref,status,ts,upd) VALUES(?,?,?,'open',?,?)", u.id, 'sp_b', 'thread:' + t.id, now(), now()).lastInsertRowid;
  run('INSERT INTO tmsgs(tk,frm,text,ts) VALUES(?,?,?,?)', tk, u.id, String(c.b.text || '').slice(0, 500) || t.title, now()); sysMsg(t.id, 'm_disp', []); notifyAdmins('n_dispute', [t.title]); notify(t.seller, 'n_disp_s', [t.title]); return { ok: 1 };
});
R('POST', '/api/threads/:id/review', c => {
  const u = need(c), t = getThread(c, c.p.id); if (t.buyer !== u.id || !['done', 'refunded', 'dispute'].includes(t.status) && t.status !== 'done') throw err('forbidden', 403);
  if (t.status !== 'done') throw err('forbidden', 403);
  if (get('SELECT 1 x FROM reviews WHERE tid=? AND from_id=?', t.id, u.id)) throw err('reviewed');
  run('INSERT INTO reviews(tid,to_id,from_id,stars,text,ts) VALUES(?,?,?,?,?,?)', t.id, t.seller, u.id, int(c.b.stars, 1, 5), String(c.b.text || '').trim().slice(0, 200), now()); return { ok: 1 };
});

// wallet
R('GET', '/api/wallet', c => {
  const u = need(c), lk = lockedOf(u.id), b = freshBal(u.id);
  return { bal: b, locked: Math.min(lk, b), avail: Math.max(0, b - lk), wdFee: sn('wd_fee_pct'), lockDays: sn('wd_lock_days'), tx: all('SELECT type,amt,note,ts FROM tx WHERE uid=? ORDER BY id DESC LIMIT 100', u.id), holds: all('SELECT id,amt,rel,frozen,note FROM holds WHERE uid=? AND released=0', u.id), wds: all('SELECT id,amt,COALESCE(fee,0) fee,COALESCE(net,amt) net,status,note,ts,method,substr(card,-4) l4 FROM withdrawals WHERE uid=? ORDER BY id DESC LIMIT 30', u.id), deps: all('SELECT id,amt,status,reason,receipt,card,ts FROM deposits WHERE uid=? ORDER BY id DESC LIMIT 30', u.id).map(d => ({ ...d, card: J(d.card) })), apc: (x => x ? apayOut(x) : null)(get("SELECT * FROM apay WHERE uid=? AND status='waiting' ORDER BY id DESC LIMIT 1", u.id)), apays: all("SELECT id,amt,status,ts FROM apay WHERE uid=? AND status NOT IN ('new','failed') ORDER BY id DESC LIMIT 6", u.id) };
});
R('POST', '/api/withdraw', c => {
  const u = need(c), amt = int(c.b.amt, CFG.minWithdraw, 500000000), card = String(c.b.card || '').replace(/\s/g, ''), holder = String(c.b.holder || '').trim().replace(/\s+/g, ' ').slice(0, 60);
  if (!/^\d{16}$/.test(card) || !luhn(card) || !CARD_PREF.some(p => card.startsWith(p))) throw err('bad_card');
  if (holder.length < 3) throw err('f_holder');
  const method = card.startsWith('9860') ? 'humo' : card.startsWith('8600') ? 'uzcard' : card[0] === '4' ? 'visa' : card[0] === '5' ? 'mastercard' : 'other';
  const b = freshBal(u.id); if (b < amt) throw err('no_funds'); if (b - lockedOf(u.id) < amt) throw err('locked'); limit('wd' + u.id, 5, 3600e3);
  const fee = Math.round(amt * sn('wd_fee_pct') / 100), net = amt - fee;
  credit(u.id, -amt, 'wd', '•••• ' + card.slice(-4)); const r = run("INSERT INTO withdrawals(uid,amt,card,status,ts,fee,net,holder,method) VALUES(?,?,?,'pending',?,?,?,?,?)", u.id, amt, card, now(), fee, net, holder, method);
  notify(u.id, 'n_wd_new', [net]); notifyAdmins('n_wd_admin', [u.name, net]); return { ok: 1, id: r.lastInsertRowid, fee, net };
});

// support
const tkOut = (t, u) => ({ id: t.id, subject: t.subject, ref: t.ref, status: t.status, ts: t.ts, user: t.uname, msgs: all('SELECT m.text,m.ts,u.name `from`, u.role FROM tmsgs m JOIN users u ON u.id=m.frm WHERE m.tk=? ORDER BY m.id', t.id) });
R('GET', '/api/tickets', c => { const u = need(c); const rows = u.role === 'admin' ? all('SELECT t.*,u.name uname FROM tickets t JOIN users u ON u.id=t.uid ORDER BY (t.status=\'open\') DESC, t.upd DESC LIMIT 200') : all('SELECT t.*,u.name uname FROM tickets t JOIN users u ON u.id=t.uid WHERE t.uid=? ORDER BY t.upd DESC LIMIT 100', u.id); return { items: rows.map(t => tkOut(t, u)) }; });
R('POST', '/api/tickets', c => {
  const u = need(c); limit('tk' + u.id, 10, 3600e3); const text = String(c.b.text || '').trim().slice(0, 600); if (text.length < 5) throw err('e_msg');
  const subj = ['sp_a', 'sp_b', 'sp_c', 'sp_d', 'sp_r'].includes(c.b.subject) ? c.b.subject : 'sp_d';
  const id = run("INSERT INTO tickets(uid,subject,ref,status,ts,upd) VALUES(?,?,?,'open',?,?)", u.id, subj, String(c.b.ref || '').slice(0, 80), now(), now()).lastInsertRowid;
  run('INSERT INTO tmsgs(tk,frm,text,ts) VALUES(?,?,?,?)', id, u.id, text, now()); notifyAdmins('n_ticket', [u.name]); return { id };
});
R('POST', '/api/tickets/:id/msg', c => {
  const u = need(c), t = get('SELECT * FROM tickets WHERE id=?', Number(c.p.id)); if (!t || (t.uid !== u.id && u.role !== 'admin')) throw err('not_found', 404);
  const text = String(c.b.text || '').trim().slice(0, 600); if (text.length < 2) throw err('e_msg');
  run('INSERT INTO tmsgs(tk,frm,text,ts) VALUES(?,?,?,?)', t.id, u.id, text, now()); run('UPDATE tickets SET upd=? WHERE id=?', now(), t.id); return { ok: 1 };
});
R('POST', '/api/tickets/:id/close', c => {
  const u = need(c), t = get('SELECT * FROM tickets WHERE id=?', Number(c.p.id)); if (!t || (t.uid !== u.id && u.role !== 'admin')) throw err('not_found', 404);
  run("UPDATE tickets SET status='closed', upd=? WHERE id=?", now(), t.id); if (u.role === 'admin') audit(u, 'ticket_close', t.id); return { ok: 1 };
});

// ---------- admin ----------
const dayStart = () => { const off = (+E.TZ_OFFSET_MIN || 300) * 60e3, t = now() + off; return t - (t % 864e5) - off; };
const incSum = (since, type) => get('SELECT COALESCE(SUM(amt),0) s FROM income WHERE ts>=?' + (type ? ' AND type=?' : ''), ...(type ? [since, type] : [since])).s, expSum = since => get('SELECT COALESCE(SUM(amt),0) s FROM expense WHERE ts>=?', since).s;
const profit = since => { const i = incSum(since), x = expSum(since); return { inc: i, exp: x, net: i - x }; };
R('GET', '/api/admin/overview', c => {
  admin(c); const d0 = dayStart();
  return {
    users: get('SELECT COUNT(*) n FROM users').n, usersToday: get('SELECT COUNT(*) n FROM users WHERE since>=?', d0).n, online: get('SELECT COUNT(*) n FROM users WHERE seen>?', now() - 70000).n,
    listings: get("SELECT COUNT(*) n FROM listings WHERE status<>'deleted'").n, active: get("SELECT COUNT(*) n FROM listings WHERE status='active'").n, pending: get("SELECT COUNT(*) n FROM listings WHERE status='pending'").n,
    disputes: get("SELECT COUNT(*) n FROM threads WHERE status='dispute'").n, deals: get("SELECT COUNT(*) n FROM threads WHERE status='done'").n,
    orders: get("SELECT COUNT(*) n FROM threads WHERE status NOT IN ('chat')").n, ordersToday: get("SELECT COUNT(*) n FROM threads WHERE status NOT IN ('chat') AND ts>=?", d0).n,
    depPending: get("SELECT COUNT(*) n, COALESCE(SUM(amt),0) s FROM deposits WHERE status IN ('pending','review')"), depReview: get("SELECT COUNT(*) n FROM deposits WHERE status='review'").n,
    apcManual: get("SELECT COUNT(*) n FROM apay WHERE status='manual'").n, depTotal: get("SELECT COALESCE(SUM(amt),0) s FROM deposits WHERE status='approved'").s + get("SELECT COALESCE(SUM(amt),0) s FROM apay WHERE status='paid'").s + get("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE tid=0 AND status='paid'").s,
    wdTotal: get("SELECT COALESCE(SUM(amt),0) s FROM withdrawals WHERE status='paid'").s,
    wdPending: get("SELECT COUNT(*) n, COALESCE(SUM(amt),0) s FROM withdrawals WHERE status='pending'"), openTickets: get("SELECT COUNT(*) n FROM tickets WHERE status='open'").n, vfPending: get("SELECT COUNT(*) n FROM verifs WHERE status='pending'").n,
    escrow: get("SELECT COALESCE(SUM(price),0) s FROM threads WHERE status IN ('paid','dispute')").s, onHold: get('SELECT COALESCE(SUM(amt),0) s FROM holds WHERE released=0').s,
    revenue: incSum(0), net: profit(0).net, netToday: profit(d0).net, wallets: get('SELECT COALESCE(SUM(bal),0) s FROM users').s,
    turnover: get("SELECT COALESCE(SUM(price),0) s FROM threads WHERE status='done'").s,
    payme: CFG.payme, click: CFG.click, apc: apcCfg().on, google: !!googleId(),
  };
});
R('GET', '/api/admin/finance', c => {
  admin(c); const d0 = dayStart(), types = ['fee', 'wd_fee', 'boost', 'verify', 'other'];
  return {
    today: profit(d0), week: profit(d0 - 6 * 864e5), month: profit(d0 - 29 * 864e5), total: profit(0),
    byType: Object.fromEntries(types.map(k => [k, incSum(0, k)])), expBy: all('SELECT type, COALESCE(SUM(amt),0) s FROM expense GROUP BY type'),
    orders: all("SELECT t.id,t.title,t.price,t.fee,t.upd,b.name buyer,s.name seller FROM threads t JOIN users b ON b.id=t.buyer JOIN users s ON s.id=t.seller WHERE t.status='done' ORDER BY t.upd DESC LIMIT 60"),
    income: all('SELECT * FROM income ORDER BY id DESC LIMIT 100'), expense: all('SELECT e.*,u.name aname FROM expense e LEFT JOIN users u ON u.id=e.adm ORDER BY e.id DESC LIMIT 50'),
    dep: all('SELECT status, COUNT(*) n, COALESCE(SUM(amt),0) s FROM deposits GROUP BY status'), wd: all('SELECT status, COUNT(*) n, COALESCE(SUM(amt),0) s, COALESCE(SUM(fee),0) f FROM withdrawals GROUP BY status'),
    wallets: get('SELECT COALESCE(SUM(bal),0) s FROM users').s, escrow: get("SELECT COALESCE(SUM(price),0) s FROM threads WHERE status IN ('paid','dispute')").s,
  };
});
R('POST', '/api/admin/ledger', c => {
  const u = admin(c), amt = int(c.b.amt, 1, 5e9), note = String(c.b.note || '').trim().slice(0, 150); if (note.length < 3) throw err('f_reason');
  if (c.b.kind === 'income') earn('other', amt, note);
  else if (['other', 'refund', 'pay_fee'].includes(c.b.kind)) run('INSERT INTO expense(type,amt,note,adm,ts) VALUES(?,?,?,?,?)', c.b.kind, amt, note, u.id, now()); else throw err('bad_number');
  audit(u, 'ledger_' + c.b.kind, amt + ':' + note); return { ok: 1 };
});
R('GET', '/api/admin/settings', c => { admin(c); return { v: Object.fromEntries(Object.keys(DEF).map(k => [k, sv(k)])) }; });
R('POST', '/api/admin/settings', c => {
  const u = admin(c), b = c.b || {}, lim = { fee: [0, 50], hold_days: [0, 30], wd_lock_days: [0, 30], wd_fee_pct: [0, 30], vf_price: [0, 5e7], vf_days: [1, 365], pay_fee_pct: [0, 20] };
  for (const [k, [lo, hi]] of Object.entries(lim)) if (b[k] !== undefined) { const v = Number(b[k]); if (!Number.isFinite(v) || v < lo || v > hi) throw err('bad_number'); run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', k, String(v)); }
  if (b.vf_mode !== undefined) { if (!['instant', 'approval'].includes(b.vf_mode)) throw err('bad_number'); run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', 'vf_mode', b.vf_mode); }
  if (b.vf_renew !== undefined) { if (!['auto', 'manual'].includes(b.vf_renew)) throw err('bad_number'); run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', 'vf_renew', b.vf_renew); }
  audit(u, 'settings', JSON.stringify(b).slice(0, 200)); return { ok: 1 };
});
R('GET', '/api/admin/listings', c => { admin(c); const s = ['pending', 'active', 'rejected', 'sold', 'deleted'].includes(c.q.status) ? c.q.status : 'pending'; return { items: all('SELECT * FROM listings WHERE status=? ORDER BY id DESC LIMIT 200', s).map(l => ({ ...fmtListing(l, c.u), auto: l.auto })) }; });
R('POST', '/api/admin/listings/:id/approve', c => { const u = admin(c), l = get('SELECT * FROM listings WHERE id=?', Number(c.p.id)); if (!l || !['pending', 'rejected'].includes(l.status)) throw err('not_found', 404); run("UPDATE listings SET status='active', reason=NULL WHERE id=?", l.id); notify(l.seller, 'n_lst_ok', [l.title]); audit(u, 'listing_approve', l.id); return { ok: 1 }; });
R('POST', '/api/admin/listings/:id/reject', c => { const u = admin(c), l = get('SELECT * FROM listings WHERE id=?', Number(c.p.id)); if (!l || l.status === 'sold') throw err('not_found', 404); run("UPDATE listings SET status='rejected', reason=? WHERE id=?", String(c.b.reason || '').slice(0, 200), l.id); notify(l.seller, 'n_lst_no', [l.title, String(c.b.reason || '').slice(0, 200)]); audit(u, 'listing_reject', l.id); return { ok: 1 }; });
R('GET', '/api/admin/threads', c => {
  admin(c); const s = c.q.status; const rows = all(s && s !== 'all' ? 'SELECT * FROM threads WHERE status=? ORDER BY upd DESC LIMIT 200' : 'SELECT * FROM threads WHERE ?=? ORDER BY upd DESC LIMIT 200', ...(s && s !== 'all' ? [s] : ['1', '1']));
  return { items: rows.map(t => ({ id: t.id, title: t.title, price: t.price, status: t.status, buyer: uPub(t.buyer), seller: uPub(t.seller), upd: t.upd, hold: get('SELECT amt,rel,frozen FROM holds WHERE tid=? AND released=0', t.id) || null })) };
});
R('POST', '/api/admin/threads/:id/resolve', c => {
  const u = admin(c), t = get('SELECT * FROM threads WHERE id=?', Number(c.p.id)); if (!t || t.status !== 'dispute') throw err('not_found', 404);
  const h = get('SELECT * FROM holds WHERE tid=? AND released=0', t.id);
  if (c.b.to === 'seller') {
    const fee = feeOf(t.price), net = t.price - fee; if (h) run('UPDATE holds SET frozen=0, rel=? WHERE id=?', now(), h.id); else credit(t.seller, net, 'sale', t.title);
    run("UPDATE threads SET status='done', fee=?, upd=? WHERE id=?", fee, now(), t.id); earn('fee', fee, 'thread:' + t.id); sysMsg(t.id, 'm_res_s', []); notify(t.seller, 'n_res_win', [t.title]); notify(t.buyer, 'n_res_lose', [t.title]);
    if (h) releaseHold(get('SELECT * FROM holds WHERE id=?', h.id));
  } else if (c.b.to === 'buyer') {
    if (h) run('UPDATE holds SET released=1, frozen=0 WHERE id=?', h.id); credit(t.buyer, t.price, 'refund', t.title);
    run("UPDATE threads SET status='refunded', upd=? WHERE id=?", now(), t.id); sysMsg(t.id, 'm_res_b', [t.price]); notify(t.buyer, 'n_res_refund', [t.title, t.price]); notify(t.seller, 'n_res_lose', [t.title]);
  } else throw err('bad_number');
  run("UPDATE tickets SET status='closed', upd=? WHERE ref=?", now(), 'thread:' + t.id); audit(u, 'resolve_' + c.b.to, t.id); return { ok: 1 };
});
R('GET', '/api/admin/withdrawals', c => { admin(c); const s = ['pending', 'paid', 'rejected'].includes(c.q.status) ? c.q.status : 'pending'; return { items: all('SELECT w.*,u.name uname FROM withdrawals w JOIN users u ON u.id=w.uid WHERE w.status=? ORDER BY w.id DESC LIMIT 200', s) }; });
R('POST', '/api/admin/withdrawals/:id/pay', c => { const u = admin(c), w = get("SELECT * FROM withdrawals WHERE id=? AND status='pending'", Number(c.p.id)); if (!w) throw err('not_found', 404); const r = run("UPDATE withdrawals SET status='paid', done=?, note=? WHERE id=? AND status='pending'", now(), String(c.b.note || '').slice(0, 100), w.id); if (!r.changes) throw err('not_found', 404); earn('wd_fee', w.fee || 0, 'wd:' + w.id); notify(w.uid, 'n_wd_paid', [w.net ?? w.amt]); audit(u, 'wd_paid', w.id); return { ok: 1 }; });
R('POST', '/api/admin/withdrawals/:id/reject', c => { const u = admin(c), w = get("SELECT * FROM withdrawals WHERE id=? AND status='pending'", Number(c.p.id)); if (!w) throw err('not_found', 404); const note = String(c.b.note || '').slice(0, 100), r = run("UPDATE withdrawals SET status='rejected', done=?, note=? WHERE id=? AND status='pending'", now(), note, w.id); if (!r.changes) throw err('not_found', 404); credit(w.uid, w.amt, 'refund', '#' + w.id); notify(w.uid, 'n_wd_rej', [note]); audit(u, 'wd_reject', w.id); return { ok: 1 }; });
R('GET', '/api/admin/holds', c => { admin(c); return { items: all('SELECT h.*,u.name uname FROM holds h JOIN users u ON u.id=h.uid WHERE h.released=0 ORDER BY h.rel') }; });
R('POST', '/api/admin/holds/:id/release', c => { const u = admin(c), h = get('SELECT * FROM holds WHERE id=? AND released=0 AND frozen=0', Number(c.p.id)); if (!h) throw err('not_found', 404); releaseHold(h); audit(u, 'hold_release', h.id); return { ok: 1 }; });
R('GET', '/api/admin/users', c => { admin(c); const q = '%' + String(c.q.q || '') + '%'; return { items: all('SELECT id,name,role,since,seen,banned,bal,vf,vf_ok,(SELECT COUNT(*) FROM listings WHERE seller=users.id AND status=\'active\') ln FROM users WHERE name LIKE ? ORDER BY id DESC LIMIT 200', q) }; });
R('POST', '/api/admin/users/:id/ban', c => { const u = admin(c), v = get('SELECT * FROM users WHERE id=?', Number(c.p.id)); if (!v || v.role === 'admin') throw err('not_found', 404); const b = c.b.ban ? 1 : 0; run('UPDATE users SET banned=? WHERE id=?', b, v.id); if (b) run('DELETE FROM sessions WHERE uid=?', v.id); audit(u, b ? 'ban' : 'unban', v.id); return { ok: 1 }; });
R('GET', '/api/admin/users/:id', c => {
  admin(c); const id = Number(c.p.id), v = get('SELECT id,name,role,since,seen,banned,bal,vf,vf_ok,email FROM users WHERE id=?', id); if (!v) throw err('not_found', 404);
  return { user: v, tx: all('SELECT type,amt,note,ts FROM tx WHERE uid=? ORDER BY id DESC LIMIT 60', id),
    buys: all("SELECT t.id,t.title,t.price,t.status,t.upd,s.name other FROM threads t JOIN users s ON s.id=t.seller WHERE t.buyer=? AND t.status<>'chat' ORDER BY t.upd DESC LIMIT 40", id),
    sales: all("SELECT t.id,t.title,t.price,t.status,t.upd,b.name other FROM threads t JOIN users b ON b.id=t.buyer WHERE t.seller=? AND t.status<>'chat' ORDER BY t.upd DESC LIMIT 40", id),
    deps: all('SELECT id,amt,status,ts FROM deposits WHERE uid=? ORDER BY id DESC LIMIT 20', id), wds: all('SELECT id,amt,status,ts FROM withdrawals WHERE uid=? ORDER BY id DESC LIMIT 20', id) };
});
R('POST', '/api/admin/users/:id/balance', c => {
  const u = admin(c), v = get('SELECT * FROM users WHERE id=?', Number(c.p.id)); if (!v) throw err('not_found', 404);
  const amt = int(c.b.amt, 1, 5e9), reason = String(c.b.reason || '').trim().slice(0, 80), note = String(c.b.note || '').trim().slice(0, 150), sub = c.b.op === 'sub';
  if (reason.length < 3) throw err('f_reason'); if (sub && freshBal(v.id) < amt) throw err('no_funds');
  credit(v.id, sub ? -amt : amt, 'adm', reason + (note ? ' · ' + note : '')); notify(v.id, sub ? 'n_adm_sub' : 'n_adm_add', [amt, reason]);
  audit(u, sub ? 'bal_sub' : 'bal_add', v.id + ':' + amt + ':' + reason + (note ? ':' + note : '')); return { ok: 1, nbal: freshBal(v.id) };
});
R('POST', '/api/admin/users/:id/verify', c => {
  const u = admin(c), v = get('SELECT * FROM users WHERE id=?', Number(c.p.id)); if (!v) throw err('not_found', 404);
  const days = int(c.b.days, 1, 3650), until = Math.max(now(), v.vf) + days * 864e5; run('UPDATE users SET vf=?, vf_ok=1 WHERE id=?', until, v.id);
  notify(v.id, 'n_vf_paid', [until]); audit(u, 'vf_grant', v.id + ':' + days); return { ok: 1 };
});
R('POST', '/api/admin/users/:id/unverify', c => {
  const u = admin(c), v = get('SELECT * FROM users WHERE id=?', Number(c.p.id)); if (!v) throw err('not_found', 404);
  run('UPDATE users SET vf=0, vf_ok=0, vf_auto=0 WHERE id=?', v.id); notify(v.id, 'n_vf_off', [String(c.b.reason || '').slice(0, 100)]); audit(u, 'vf_revoke', v.id); return { ok: 1 };
});
R('GET', '/api/admin/payments', c => { admin(c); return { items: all('SELECT o.*,u.name uname,t.title FROM orders o JOIN users u ON u.id=o.uid LEFT JOIN threads t ON t.id=o.tid ORDER BY o.id DESC LIMIT 200') }; });
R('GET', '/api/admin/logs', c => { admin(c); return { items: all('SELECT g.*,u.name uname FROM logs g LEFT JOIN users u ON u.id=g.uid ORDER BY g.id DESC LIMIT 200') }; });


// ---------- notifications ----------
R('GET', '/api/notifs', c => { const u = need(c); return { items: all('SELECT id,k,a,ts,rd FROM notifs WHERE uid=? ORDER BY id DESC LIMIT 60', u.id).map(n => ({ ...n, a: J(n.a) || [] })), unread: get('SELECT COUNT(*) n FROM notifs WHERE uid=? AND rd=0', u.id).n }; });
R('POST', '/api/notifs/read', c => { run('UPDATE notifs SET rd=1 WHERE uid=? AND rd=0', need(c).id); return { ok: 1 }; });

// ---------- cards (admin-managed requisites) ----------
const KINDS = ['humo', 'uzcard', 'visa', 'mastercard', 'other'], cardOut = k => ({ id: k.id, num: k.num, holder: k.holder, bank: k.bank, kind: k.kind });
function cardIn(b) {
  const num = String(b.num || '').replace(/\D/g, ''), holder = String(b.holder || '').trim().replace(/\s+/g, ' ').slice(0, 60), bank = String(b.bank || '').trim().slice(0, 40), kind = KINDS.includes(b.kind) ? b.kind : 'other';
  if (!/^\d{16}$/.test(num) || !luhn(num)) throw err('bad_card'); if (holder.length < 3) throw err('f_holder'); if (bank.length < 2) throw err('f_bank');
  return { num, holder, bank, kind };
}
R('GET', '/api/cards', c => { need(c); return { items: all('SELECT * FROM cards WHERE active=1 ORDER BY pos,id').map(cardOut) }; });
R('GET', '/api/admin/cards', c => { admin(c); return { items: all('SELECT * FROM cards ORDER BY pos,id') }; });
R('POST', '/api/admin/cards', c => { const u = admin(c), k = cardIn(c.b), pos = get('SELECT COALESCE(MAX(pos),0)+1 n FROM cards').n; const r = run('INSERT INTO cards(num,holder,bank,kind,active,pos,ts) VALUES(?,?,?,?,1,?,?)', k.num, k.holder, k.bank, k.kind, pos, now()); audit(u, 'card_add', r.lastInsertRowid); return { id: r.lastInsertRowid }; });
R('POST', '/api/admin/cards/reorder', c => { const u = admin(c); (Array.isArray(c.b.ids) ? c.b.ids : []).slice(0, 100).forEach((id, i) => run('UPDATE cards SET pos=? WHERE id=?', i + 1, Number(id))); audit(u, 'card_order', ''); return { ok: 1 }; });
R('POST', '/api/admin/cards/:id', c => {
  const u = admin(c), k = get('SELECT * FROM cards WHERE id=?', Number(c.p.id)); if (!k) throw err('not_found', 404);
  if (c.b.active !== undefined && c.b.num === undefined) { run('UPDATE cards SET active=? WHERE id=?', c.b.active ? 1 : 0, k.id); audit(u, c.b.active ? 'card_on' : 'card_off', k.id); return { ok: 1 }; }
  const n = cardIn({ ...k, ...c.b }); run('UPDATE cards SET num=?,holder=?,bank=?,kind=? WHERE id=?', n.num, n.holder, n.bank, n.kind, k.id); audit(u, 'card_edit', k.id); return { ok: 1 };
});
R('DELETE', '/api/admin/cards/:id', c => { const u = admin(c); run('DELETE FROM cards WHERE id=?', Number(c.p.id)); audit(u, 'card_del', c.p.id); return { ok: 1 }; });

// ---------- manual card deposits with receipt ----------
const RCPT = /^\/uploads\/[a-f0-9]{24}\.(jpg|png|webp)$/;
R('POST', '/api/deposits', c => {
  const u = need(c); limit('dp' + u.id, 10, 3600e3);
  const amt = int(c.b.amt, CFG.minTopup, 50000000), k = get('SELECT * FROM cards WHERE id=? AND active=1', Number(c.b.card)); if (!k) throw err('no_card');
  if (get("SELECT COUNT(*) n FROM deposits WHERE uid=? AND status IN ('pending','review')", u.id).n >= 3) throw err('too_many');
  const r = run("INSERT INTO deposits(uid,amt,card_id,card,status,ts,upd) VALUES(?,?,?,?,'pending',?,?)", u.id, amt, k.id, JSON.stringify(cardOut(k)), now(), now()); return { id: r.lastInsertRowid };
});
R('POST', '/api/deposits/:id/receipt', c => {
  const u = need(c), d = get("SELECT * FROM deposits WHERE id=? AND uid=? AND status='pending'", Number(c.p.id), u.id); if (!d) throw err('not_found', 404);
  const img = String(c.b.img || ''); if (!RCPT.test(img)) throw err('bad_image');
  let h; try { h = crypto.createHash('sha256').update(fs.readFileSync(path.join(CFG.data, 'uploads', img.slice(9)))).digest('hex'); } catch { throw err('bad_image'); }
  if (get("SELECT 1 x FROM deposits WHERE rhash=? AND status IN ('review','approved')", h)) throw err('dup_receipt');
  run("UPDATE deposits SET receipt=?, rhash=?, status='review', upd=? WHERE id=?", img, h, now(), d.id);
  notify(u.id, 'n_dep_recv', [d.amt]); notifyAdmins('n_dep_new', [u.name, d.amt]); return { ok: 1 };
});
R('POST', '/api/deposits/:id/cancel', c => { const u = need(c), r = run("UPDATE deposits SET status='cancelled', upd=? WHERE id=? AND uid=? AND status IN ('pending','review')", now(), Number(c.p.id), u.id); if (!r.changes) throw err('not_found', 404); return { ok: 1 }; });
R('GET', '/api/admin/deposits', c => {
  admin(c); const s = ['pending', 'review', 'approved', 'rejected', 'cancelled'].includes(c.q.status) ? c.q.status : 'review';
  return { items: all('SELECT d.*,u.name uname,u.bal ubal FROM deposits d JOIN users u ON u.id=d.uid WHERE d.status=? ORDER BY d.id DESC LIMIT 200', s).map(d => ({ ...d, card: J(d.card) })) };
});
R('POST', '/api/admin/deposits/:id/approve', c => {
  const u = admin(c), d = get("SELECT * FROM deposits WHERE id=? AND status='review'", Number(c.p.id)); if (!d) throw err('not_found', 404);
  const amt = c.b.amt === undefined || c.b.amt === '' ? d.amt : int(c.b.amt, 1000, 50000000);
  const r = run("UPDATE deposits SET status='approved', amt=?, adm=?, upd=? WHERE id=? AND status='review'", amt, u.id, now(), d.id); if (!r.changes) throw err('not_found', 404);
  credit(d.uid, amt, 'topup', '#' + d.id); notify(d.uid, 'n_dep_ok', [amt]); audit(u, 'dep_ok', d.id + ':' + amt); return { ok: 1 };
});
R('POST', '/api/admin/deposits/:id/reject', c => {
  const u = admin(c), d = get("SELECT * FROM deposits WHERE id=? AND status IN ('review','pending')", Number(c.p.id)); if (!d) throw err('not_found', 404);
  const reason = String(c.b.reason || '').trim().slice(0, 150); if (reason.length < 3) throw err('f_reason');
  const r = run("UPDATE deposits SET status='rejected', reason=?, adm=?, upd=? WHERE id=? AND status IN ('review','pending')", reason, u.id, now(), d.id); if (!r.changes) throw err('not_found', 404);
  notify(d.uid, 'n_dep_no', [reason]); audit(u, 'dep_no', d.id); return { ok: 1 };
});

// ---------- verified badge (monthly) ----------
function vfState(u) {
  const q = get('SELECT status,note,ts FROM verifs WHERE uid=? ORDER BY id DESC LIMIT 1', u.id), active = u.vf > now();
  const st = active ? 'active' : u.vf_ok ? (u.vf ? 'expired' : 'approved') : q && ['pending', 'rejected'].includes(q.status) ? q.status : 'none';
  return { st, mode: sv('vf_mode'), until: u.vf, ok: !!u.vf_ok, auto: !!u.vf_auto, note: q && q.status === 'rejected' ? q.note : '', price: sn('vf_price'), days: sn('vf_days'), renew: sv('vf_renew') };
}
function vfCharge(uid) {
  const price = sn('vf_price'), v = get('SELECT vf FROM users WHERE id=?', uid), until = Math.max(now(), v.vf) + sn('vf_days') * 864e5;
  if (price > 0) { credit(uid, -price, 'vf', 'verify'); earn('verify', price, 'user:' + uid); } run('UPDATE users SET vf=? WHERE id=?', until, uid); return until;
}
R('GET', '/api/verify', c => ({ ...vfState(need(c)), bal: freshBal(c.u.id) }));
R('POST', '/api/verify/request', c => {
  const u = need(c); limit('vq' + u.id, 3, 864e5); if (u.vf_ok) throw err('vf_have'); if (get("SELECT 1 x FROM verifs WHERE uid=? AND status='pending'", u.id)) throw err('vf_wait');
  run("INSERT INTO verifs(uid,status,note,ts,upd) VALUES(?,'pending',?,?,?)", u.id, String(c.b.note || '').trim().slice(0, 300), now(), now()); notifyAdmins('n_vf_req', [u.name]); return { ok: 1 };
});
R('POST', '/api/verify/pay', c => {
  const u = need(c); if (!u.vf_ok && sv('vf_mode') !== 'instant') throw err('forbidden', 403); if (freshBal(u.id) < sn('vf_price')) throw err('no_funds');
  limit('vfp' + u.id, 1, 4000);  // ikki marta bosib ortiqcha pul yechilmasin
  const until = vfCharge(u.id); if (!u.vf_ok) { run('UPDATE users SET vf_ok=1 WHERE id=?', u.id); run("UPDATE verifs SET status='approved', upd=? WHERE uid=? AND status='pending'", now(), u.id); } notify(u.id, 'n_vf_paid', [until]); return { ok: 1, until };
});
R('POST', '/api/verify/auto', c => { const u = need(c); run('UPDATE users SET vf_auto=? WHERE id=?', c.b.on ? 1 : 0, u.id); return { ok: 1 }; });
R('GET', '/api/admin/verifs', c => {
  admin(c); const s = ['pending', 'approved', 'rejected'].includes(c.q.status) ? c.q.status : 'pending';
  return { items: all('SELECT v.*,u.name uname,u.vf,u.since,(SELECT COUNT(*) FROM threads WHERE seller=u.id AND status=\'done\') deals FROM verifs v JOIN users u ON u.id=v.uid WHERE v.status=? ORDER BY v.id DESC LIMIT 200', s) };
});
R('POST', '/api/admin/verifs/:id/approve', c => {
  const u = admin(c), v = get("SELECT * FROM verifs WHERE id=? AND status='pending'", Number(c.p.id)); if (!v) throw err('not_found', 404);
  run("UPDATE verifs SET status='approved', upd=? WHERE id=?", now(), v.id); run('UPDATE users SET vf_ok=1 WHERE id=?', v.uid); notify(v.uid, 'n_vf_ok', [sn('vf_price')]); audit(u, 'vf_ok', v.uid); return { ok: 1 };
});
R('POST', '/api/admin/verifs/:id/reject', c => {
  const u = admin(c), v = get("SELECT * FROM verifs WHERE id=? AND status='pending'", Number(c.p.id)); if (!v) throw err('not_found', 404); const reason = String(c.b.reason || '').trim().slice(0, 150);
  run("UPDATE verifs SET status='rejected', note=?, upd=? WHERE id=?", reason, now(), v.id); notify(v.uid, 'n_vf_no', [reason]); audit(u, 'vf_no', v.uid); return { ok: 1 };
});
function sweepVf() {
  try {
    db.exec('BEGIN IMMEDIATE');
    for (const x of all('SELECT id,vf,vf_auto,bal FROM users WHERE vf>0 AND vf<=?', now())) {
      if (sv('vf_renew') === 'auto' && x.vf_auto && x.bal >= sn('vf_price')) { const until = vfCharge(x.id); notify(x.id, 'n_vf_renew', [until]); }
      else { run('UPDATE users SET vf=0 WHERE id=?', x.id); notify(x.id, 'n_vf_exp', []); }
    }
    db.exec('COMMIT');
  } catch (e) { try { db.exec('ROLLBACK'); } catch { } console.error('sweepVf', e.message); }
}
setInterval(sweepVf, 60e3).unref();

// ---------- AutoPayCard: automatic UzCard top-ups (Gmail match) ----------
const APC_BASE = (E.APC_BASE || 'https://api.autopaycard.uz').replace(/\/$/, '');
const apcS = (k, d = '') => { const r = get('SELECT v FROM settings WHERE k=?', k); return r ? r.v : d; }, setS = (k, v) => run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', k, String(v));
function apcCfg() {  // the API key lives on the server only (.env, or set from the admin panel); it is never sent to a browser
  const key = apcS('apc_key') || E.APC_API_KEY || '', whsec = apcS('apc_whsec') || E.APC_WEBHOOK_SECRET || '', gmail = (apcS('apc_gmail') || E.APC_GMAIL || '').toLowerCase();
  const k = get('SELECT * FROM cards WHERE id=?', Number(apcS('apc_card', '0')) || -1);
  return { key, whsec, gmail, card: k || null, last4: k ? k.num.slice(-4) : '', on: apcS('apc_on', '1') === '1' && !!(key && gmail && k) };
}
async function apcCall(p, body, method = 'POST') {
  const k = apcCfg(); if (!k.key) throw err('provider');
  let r; try { r = await fetch(APC_BASE + p, { method, headers: { 'x-api-key': k.key, 'content-type': 'application/json' }, body: method === 'POST' ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(10000) }); } catch { throw err('apc_down', 502); }
  let j = null; try { j = await r.json(); } catch { } return { s: r.status, j };
}
const apayOut = a => { const k = get('SELECT * FROM cards WHERE id=?', Number(apcS('apc_card', '0')) || -1); return { id: a.id, tid: a.tid || 0, amt: a.amt, status: a.status, ts: a.ts, exp: a.exp, now: now(), card: k ? cardOut(k) : null }; };
let apcErrAt = 0;
async function apcCreate(c) {
  const u = need(c); limit('apc' + u.id, 8, 600e3); const k = apcCfg(); if (!k.on) throw err('provider');
  let tid = 0, base;
  if (c.b.tid) { const t = get('SELECT * FROM threads WHERE id=?', Number(c.b.tid)), l = t && get('SELECT status FROM listings WHERE id=?', t.lid); if (!t || t.buyer !== u.id) throw err('not_found', 404); if (t.status !== 'chat' || !l || l.status !== 'active') throw err('unavailable'); tid = t.id; base = int(t.price, 1000, 50000000 - 99); }
  else base = int(c.b.amt, Math.max(CFG.minTopup, 1000), 50000000 - 99);
  const open = get("SELECT * FROM apay WHERE uid=? AND status='waiting' ORDER BY id DESC", u.id);
  if (open) { if (tid && open.tid === tid) { c.apc = open.id; c.apcOld = 1; return; } throw err('apc_open', 409); }
  const skip = new Set();
  for (let i = 0; i < 4; i++) {
    // pick + reserve in one synchronous block: two requests can never take the same amount on one card
    const busy = new Set(all("SELECT amt FROM apay WHERE last4=? AND (status IN ('new','waiting') OR ts>?)", k.last4, now() - 20 * 60e3).map(x => x.amt)), free = [];
    for (let d = 1; d < 100; d++) if (!busy.has(base + d) && !skip.has(base + d)) free.push(base + d);
    if (!free.length) throw err('apc_busy', 503);
    const amt = free[crypto.randomInt(free.length)], id = run("INSERT INTO apay(uid,amt,last4,status,ts,upd,tid) VALUES(?,?,?,'new',?,?,?)", u.id, amt, k.last4, now(), now(), tid).lastInsertRowid;
    let r; try { r = await apcCall('/api/create-payment', { amount: amt, card_last4: k.last4, gmail: k.gmail, client_user_id: String(u.id), client_user_data: { apay: id } }); } catch (e) { run("UPDATE apay SET status='failed', note='network', upd=? WHERE id=?", now(), id); throw e; }
    if (r.s === 200 && r.j && r.j.success && r.j.order_id) { run("UPDATE apay SET ext=?, status='waiting', exp=?, upd=? WHERE id=? AND status='new'", String(r.j.order_id), now() + 300e3, now(), id); c.apc = id; return; }
    const why = String((r.j && (typeof r.j.detail === 'string' ? r.j.detail : JSON.stringify(r.j.detail))) || r.s).slice(0, 150);
    run("UPDATE apay SET status='failed', note=?, upd=? WHERE id=?", r.s + ' ' + why, now(), id);
    if (r.s === 409) { skip.add(amt); continue; }
    if ([400, 401, 403].includes(r.s) && now() - apcErrAt > 600e3) { apcErrAt = now(); notifyAdmins('n_apc_err', [why]); }
    throw err(r.s === 429 ? 'apc_busy' : 'apc_down', 503);
  }
  throw err('apc_busy', 503);
}
R('POST', '/api/apay', c => { const a = get('SELECT * FROM apay WHERE id=?', c.apc); if (!c.apcOld) notify(a.uid, 'n_apc_new', [a.amt]); return apayOut(a); }, { pre: apcCreate });
R('GET', '/api/apay/:id', c => { const u = need(c), a = get('SELECT * FROM apay WHERE id=? AND uid=?', Number(c.p.id), u.id); if (!a) throw err('not_found', 404); return apayOut(a); });
R('POST', '/api/apay/:id/cancel', c => { const u = need(c); if (!run("UPDATE apay SET status='cancelled', upd=? WHERE id=? AND uid=? AND status='waiting'", now(), Number(c.p.id), u.id).changes) throw err('not_found', 404); return { ok: 1 }; });

// to'lov biror tovar uchun bo'lsa: pul hamyonga tushgach tovar avtomatik escrow ga o'tkaziladi (ortiqcha tiyinlar hamyonda qoladi)
function afterApc(a) {
  if (!a.tid) return;
  const t = get('SELECT * FROM threads WHERE id=?', a.tid), l = t && get('SELECT * FROM listings WHERE id=?', t.lid);
  if (!t || t.buyer !== a.uid || t.status !== 'chat' || !l || l.status !== 'active' || freshBal(a.uid) < t.price) return;
  credit(a.uid, -t.price, 'buy', t.title); markPaid(run("INSERT INTO orders(tid,uid,amount,provider,status,ts) VALUES(?,?,?,'apc','new',?)", t.id, a.uid, t.price, now()).lastInsertRowid);
}
// the ONLY place that credits an AutoPayCard payment; idempotent per order (waiting -> paid happens once)
function applyApc(id, status, amount, last4) {
  const a = get('SELECT * FROM apay WHERE id=?', id); if (!a || ['paid', 'rejected', 'failed'].includes(a.status)) return;
  if (status === 'paid') {
    if (a.status === 'waiting' && (amount === undefined || Number(amount) === a.amt) && (!last4 || String(last4) === a.last4)) {
      if (run("UPDATE apay SET status='paid', paid=?, upd=? WHERE id=? AND status='waiting'", now(), now(), a.id).changes) { credit(a.uid, a.amt, 'topup', 'autopay #' + a.ext); notify(a.uid, 'n_apc_ok', [a.amt]); afterApc(a); }
    } else if (a.status !== 'manual') {  // late / cancelled / different amount: never auto-credit, an admin decides
      run("UPDATE apay SET status='manual', note=?, upd=? WHERE id=?", a.status === 'waiting' ? 'amount mismatch ' + amount : 'paid after ' + a.status, now(), a.id);
      const u = get('SELECT name FROM users WHERE id=?', a.uid); notifyAdmins('n_apc_man', [u ? u.name : '?', a.amt]); notify(a.uid, 'n_apc_manu', [a.amt]);
    }
  } else if (status === 'expired' && a.status === 'waiting') {
    run("UPDATE apay SET status='expired', upd=? WHERE id=?", now(), a.id); notify(a.uid, 'n_apc_exp', [a.amt]);
  }
}
let apcBusy = false;
async function sweepApc() {  // also runs after a restart: open payments are read back from the database
  if (apcBusy) return; apcBusy = true;
  try {
    const rows = all("SELECT * FROM apay WHERE status='waiting' AND ext IS NOT NULL ORDER BY upd LIMIT 5");
    for (const a of rows) run('UPDATE apay SET upd=? WHERE id=?', now(), a.id);
    const res = await Promise.all(rows.map(a => apcCall('/api/check-payment', { order_id: a.ext }).catch(() => null)));
    if (rows.length) {
      db.exec('BEGIN IMMEDIATE');
      try {
        rows.forEach((a, i) => { const r = res[i]; if (r && r.s === 200 && r.j) applyApc(a.id, r.j.status, r.j.amount, r.j.card_last4); else if (now() > a.exp + 30 * 60e3) applyApc(a.id, 'expired'); });  // API unreachable for a long time: stop waiting, admin can still confirm by hand
        db.exec('COMMIT');
      } catch (e) { try { db.exec('ROLLBACK'); } catch { } console.error('sweepApc', e.message); }
    }
  } catch (e) { console.error('sweepApc', e.message); } finally { apcBusy = false; }
}
setInterval(sweepApc, 3500).unref();
function apcSigOk(raw, hdr, secret) {
  try {
    const p = Object.fromEntries(String(hdr || '').split(',').map(x => { const i = x.indexOf('='); return [x.slice(0, i).trim(), x.slice(i + 1).trim()]; }));
    if (!p.t || !p.v1 || Math.abs(Date.now() / 1000 - Number(p.t)) > 86400) return false;
    const a = Buffer.from(crypto.createHmac('sha256', secret).update(p.t + '.' + raw).digest('hex')), b = Buffer.from(p.v1); return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}
async function apcHookPre(c) {
  limit('apw' + c.ip, 300, 60e3); const k = apcCfg(), d = c.b && typeof c.b === 'object' ? c.b : {};
  if (k.whsec) { if (!apcSigOk(c.raw, c.req.headers['x-autopaycard-signature'], k.whsec)) throw err('bad_sig', 401); c.hook = d; return; }
  if (d.event === 'test') { c.hook = d; return; }
  // no signing secret configured: believe nothing in the body, ask AutoPayCard directly
  const oid = String(d.order_id || ''); if (!oid || oid.length > 64) throw err('bad_json');
  const r = await apcCall('/api/check-payment', { order_id: oid }); if (r.s !== 200 || !r.j) throw err('apc_down', 502); c.hook = r.j;
}
R('POST', '/api/apc/webhook', c => {
  const d = c.hook || {}; if (d.event === 'test') return { ok: 1 };
  const a = get('SELECT * FROM apay WHERE ext=?', String(d.order_id || '')); if (a) applyApc(a.id, d.status || (d.event === 'payment.paid' ? 'paid' : ''), d.amount, d.card_last4);
  return { ok: 1 };
}, { raw: 1, pre: apcHookPre });

// admin: history, manual check, settings
R('GET', '/api/admin/apay', c => {
  admin(c); const S = ['waiting', 'paid', 'expired', 'manual', 'cancelled', 'rejected', 'failed'], s = S.includes(c.q.status) ? c.q.status : 'all';
  return { items: all(`SELECT a.*,u.name uname FROM apay a JOIN users u ON u.id=a.uid WHERE ${s === 'all' ? "a.status NOT IN ('new','failed')" : 'a.status=?'} ORDER BY a.id DESC LIMIT 200`, ...(s === 'all' ? [] : [s])) };
});
R('POST', '/api/admin/apay/:id/confirm', c => {
  const u = admin(c), a = get('SELECT * FROM apay WHERE id=?', Number(c.p.id)); if (!a) throw err('not_found', 404);
  const amt = c.b.amt === undefined || c.b.amt === '' ? a.amt : int(c.b.amt, 1000, 50000000);
  if (!run("UPDATE apay SET status='paid', amt=?, paid=?, adm=?, note='manual', upd=? WHERE id=? AND status IN ('waiting','expired','manual','cancelled')", amt, now(), u.id, now(), a.id).changes) throw err('not_found', 404);
  credit(a.uid, amt, 'topup', 'autopay #' + (a.ext || a.id)); notify(a.uid, 'n_apc_ok', [amt]); afterApc(a); audit(u, 'apc_ok', a.id + ':' + amt); return { ok: 1 };
});
R('POST', '/api/admin/apay/:id/reject', c => {
  const u = admin(c), a = get('SELECT * FROM apay WHERE id=?', Number(c.p.id)); if (!a) throw err('not_found', 404); const reason = String(c.b.reason || '').trim().slice(0, 150);
  if (!run("UPDATE apay SET status='rejected', note=?, adm=?, upd=? WHERE id=? AND status IN ('waiting','expired','manual','cancelled')", reason, u.id, now(), a.id).changes) throw err('not_found', 404);
  notify(a.uid, 'n_apc_no', [reason || '—']); audit(u, 'apc_no', a.id); return { ok: 1 };
});
R('GET', '/api/admin/apc', c => {
  admin(c); const k = apcCfg();
  return { on: apcS('apc_on', '1') === '1', key: !!k.key, keyHint: k.key ? '••••' + k.key.slice(-4) : '', keyEnv: !apcS('apc_key') && !!E.APC_API_KEY, whsec: !!k.whsec, gmail: k.gmail, card: Number(apcS('apc_card', '0')), cards: all('SELECT id,num,bank,kind,active FROM cards ORDER BY pos,id'), ready: k.on, base: APC_BASE, hook: CFG.base + '/api/apc/webhook' };
});
R('POST', '/api/admin/apc', c => {
  const u = admin(c), b = c.b || {};
  if (b.on !== undefined) setS('apc_on', b.on ? '1' : '0');
  for (const f of ['key', 'whsec']) { if (typeof b[f] === 'string' && b[f].trim()) { const v = b[f].trim(); if (v.length < 8 || v.length > 200 || /\s/.test(v)) throw err('bad_number'); setS('apc_' + f, v); } if (b['clear_' + f]) setS('apc_' + f, ''); }
  if (b.gmail !== undefined) { const g = String(b.gmail).trim().toLowerCase(); if (g && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(g)) throw err('f_gmail'); setS('apc_gmail', g); }
  if (b.card !== undefined) { const id = Number(b.card) || 0; if (id && !get('SELECT 1 x FROM cards WHERE id=?', id)) throw err('no_card'); setS('apc_card', id); }
  audit(u, 'apc_set', Object.keys(b).join(',')); return { ok: 1 };
});
R('POST', '/api/admin/apc/test', c => ({ ok: 1, ...c.t }), {
  pre: async c => {
    admin(c); const k = apcCfg(); if (!k.key) throw err('provider');
    const [s, m] = await Promise.all([apcCall('/api/subscription', null, 'GET'), apcCall('/api/my-cards', null, 'GET')]), det = x => String(x.j && x.j.detail || x.s).slice(0, 150);
    c.t = { sub: s.s === 200 ? s.j : { error: det(s) }, cards: m.s === 200 ? m.j.cards || [] : [], error: m.s === 200 ? '' : det(m), match: m.s === 200 && (m.j.cards || []).some(x => String(x.card_last4) === k.last4 && String(x.gmail).toLowerCase() === k.gmail) };
  }
});

// ---------- backups & system (admin) ----------
const BKDIR = path.join(CFG.data, 'backups'); fs.mkdirSync(BKDIR, { recursive: true });
const BK_RE = /^bb-\d{8}-\d{6}-(auto|manual)\.sqlite$/;
const bkList = () => fs.readdirSync(BKDIR).filter(f => BK_RE.test(f)).map(f => { const x = fs.statSync(path.join(BKDIR, f)); return { name: f, size: x.size, ts: x.mtimeMs }; }).sort((a, b) => b.ts - a.ts);
function backupNow(tag = 'auto') {  // VACUUM INTO = bazaning izchil nusxasi (server ishlab turganda ham xavfsiz)
  const d = new Date(), z = n => String(n).padStart(2, '0'), name = `bb-${d.getUTCFullYear()}${z(d.getUTCMonth() + 1)}${z(d.getUTCDate())}-${z(d.getUTCHours())}${z(d.getUTCMinutes())}${z(d.getUTCSeconds())}-${tag}.sqlite`, f = path.join(BKDIR, name);
  if (fs.existsSync(f)) return name;
  db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`);
  for (const x of bkList().filter(x => x.name.endsWith('-auto.sqlite')).slice(+E.BACKUP_KEEP || 28)) try { fs.unlinkSync(path.join(BKDIR, x.name)); } catch { }
  return name;
}
function autoBackup() { try { const l = bkList().find(x => x.name.endsWith('-auto.sqlite')); if (!l || now() - l.ts > 6 * 3600e3) backupNow('auto'); } catch (e) { console.error('backup', e.message); } }
setInterval(autoBackup, 30 * 60e3).unref();
R('GET', '/api/admin/system', c => {
  admin(c); let dbSize = 0, up = 0; for (const x of ['bb.sqlite', 'bb.sqlite-wal']) try { dbSize += fs.statSync(path.join(CFG.data, x)).size; } catch { } try { up = fs.readdirSync(path.join(CFG.data, 'uploads')).length; } catch { }
  const r = get("SELECT v FROM settings WHERE k='db_created'"), g = get("SELECT v FROM settings WHERE k='google_id'");
  return { data: CFG.data, dbSize, uploads: up, created: r ? +r.v : 0, inApp: !path.relative(__dirname, CFG.data).startsWith('..'), backups: bkList(), google: googleId(), googleEnv: !(g && g.v) && !!E.GOOGLE_CLIENT_ID, base: CFG.base, https: CFG.base.startsWith('https') || /^http:\/\/localhost/.test(CFG.base), node: process.version, uptime: Math.round(process.uptime()) };
});
R('POST', '/api/admin/backup', c => { audit(c.u, 'backup', c.bk); return { ok: 1, name: c.bk }; }, { pre: c => { admin(c); limit('bk' + c.u.id, 6, 600e3); c.bk = backupNow('manual'); } });
R('GET', '/api/admin/backup/download', c => { admin(c); const n = String(c.q.name || ''); if (!BK_RE.test(n) || !fs.existsSync(path.join(BKDIR, n))) throw err('not_found', 404); return { __file: path.join(BKDIR, n), name: n }; });
R('POST', '/api/admin/google', c => {
  const u = admin(c), id = String(c.b.id || '').trim();
  if (id && !/^[\w.-]{10,200}\.apps\.googleusercontent\.com$/.test(id)) throw err('f_gid');
  run('INSERT INTO settings(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', 'google_id', id); audit(u, 'google_set', id ? 'on' : 'off'); return { ok: 1 };
});

// payment provider endpoints (no cookies, own auth)
R('POST', '/api/payme', paymeHandler, { raw: 1 });
R('POST', '/api/click/prepare', clickHandler('prepare'), { raw: 1 });
R('POST', '/api/click/complete', clickHandler('complete'), { raw: 1 });

// ---------- http ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.jpg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };
const hdr = () => { const GG = !!googleId(); return { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': GG ? 'strict-origin-when-cross-origin' : 'same-origin', 'X-Frame-Options': 'DENY', 'Content-Security-Policy': `default-src 'self'; img-src 'self' data: ${GG ? 'https://*.googleusercontent.com' : ''}; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com${GG ? ' https://accounts.google.com/gsi/style' : ''}; font-src https://fonts.gstatic.com; script-src 'self'${GG ? ' https://accounts.google.com/gsi/client' : ''}; connect-src 'self'${GG ? ' https://accounts.google.com/gsi/' : ''}; ${GG ? "frame-src https://accounts.google.com/gsi/; " : ''}frame-ancestors 'none'; base-uri 'none'; form-action 'self'` }; };
function body(req, max) {
  return new Promise((ok, no) => { let n = 0; const ch = []; req.on('data', d => { n += d.length; if (n > max) { no(err('too_big', 413)); req.destroy(); } else ch.push(d); }); req.on('end', () => ok(Buffer.concat(ch).toString())); req.on('error', no); });
}
function send(res, code, obj, extra = {}) { const s = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...hdr(), ...extra }); res.end(s); }
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname), root = PUB;
  if (p.startsWith('/uploads/')) { root = path.join(CFG.data, 'uploads'); p = p.slice(8); } else if (p === '/') p = '/index.html'; else if (p === '/admin') p = '/admin.html';
  const f = path.normalize(path.join(root, p));
  if (!f.startsWith(root + path.sep) && f !== root) { res.writeHead(403); return res.end(); }
  fs.stat(f, (e, s) => {
    if (e || !s.isFile()) { res.writeHead(404, hdr()); return res.end('Not found'); }
    const ext = path.extname(f).toLowerCase(), up = root !== PUB;
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': s.size, 'Cache-Control': up ? 'public, max-age=31536000, immutable' : 'no-cache', ...hdr() });
    if (req.method === 'HEAD') return res.end(); fs.createReadStream(f).pipe(res);
  });
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (!url.pathname.startsWith('/api/')) { if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); } return serveStatic(req, res, url); }
    const r = routes.find(x => x.m === req.method && x.re.test(url.pathname)); if (!r) return send(res, 404, { error: 'not_found' });
    const mt = url.pathname.match(r.re); const p = {}; r.keys.forEach((k, i) => p[k] = decodeURIComponent(mt[i + 1]));
    const c = { req, res, p, q: Object.fromEntries(url.searchParams), ip: E.TRUST_PROXY === '1' && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress, u: null, b: {}, cookie: null };
    if (req.method !== 'GET') {
      const raw = await body(req, r.max || 100e3); c.raw = raw;
      if ((req.headers['content-type'] || '').includes('x-www-form-urlencoded')) c.b = Object.fromEntries(new URLSearchParams(raw)); else if (raw) { try { c.b = JSON.parse(raw); } catch { throw err('bad_json'); } }
      if (!r.raw) { const o = req.headers.origin; if (o && o !== CFG.base && new URL(o).host !== req.headers.host) throw err('forbidden', 403); if (!(req.headers['content-type'] || '').includes('application/json') && raw) throw err('bad_json', 415); }
    }
    if (!r.raw) {
      const m = (req.headers.cookie || '').match(/(?:^|;\s*)bb_s=(\w+)/);
      if (m) { const u = get('SELECT u.* FROM sessions s JOIN users u ON u.id=s.uid WHERE s.token=?', m[1]); if (u && !u.banned) { c.u = u; if (now() - u.seen > 15000) run('UPDATE users SET seen=? WHERE id=?', now(), u.id); } }
    }
    if (r.pre) await r.pre(c);
    let out;
    if (req.method === 'GET') out = r.fn(c);
    else { db.exec('BEGIN IMMEDIATE'); try { out = r.fn(c); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; } }
    if (out && out.__file) { const x = fs.statSync(out.__file); res.writeHead(200, { 'Content-Type': 'application/octet-stream', 'Content-Length': x.size, 'Content-Disposition': `attachment; filename="${out.name}"`, 'Cache-Control': 'no-store', ...hdr() }); return fs.createReadStream(out.__file).pipe(res); }
    if (c.u && !r.raw && out && c.u.id) { const f = get('SELECT bal FROM users WHERE id=?', c.u.id); if (f && typeof out === 'object' && !Array.isArray(out) && 'ok' in out) out.bal = f.bal; }
    send(res, 200, out, c.cookie ? { 'Set-Cookie': c.cookie } : {});
  } catch (e) {
    if (e instanceof HttpErr) return send(res, e.code, { error: e.key });
    console.error('ERROR', req.method, req.url, e); send(res, 500, { error: 'server', detail: CFG.base.startsWith('http://localhost') ? String(e && e.message || e).slice(0, 160) + ' @ ' + req.method + ' ' + String(req.url).split('?')[0] : undefined });
  }
});

// ---------- admin account ----------
// ADMIN_PASS (.env) har safar ishga tushganda admin parolini o'zi bilan tenglashtiradi: parol "yo'qolib" qolmaydi.
const PWFILE = path.join(CFG.data, 'admin-password.txt');
function setAdminPass(pw) {
  const salt = crypto.randomBytes(16).toString('hex'), a = get("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1");
  if (a) { run('UPDATE users SET salt=?, hash=?, banned=0 WHERE id=?', salt, hashPw(pw, salt), a.id); run('DELETE FROM sessions WHERE uid=?', a.id); }
  else run("INSERT INTO users(name,salt,hash,role,since,seen) VALUES('admin',?,?,'admin',?,0)", salt, hashPw(pw, salt), now());
}
const adminPassOk = pw => { const a = get("SELECT salt,hash FROM users WHERE role='admin' ORDER BY id LIMIT 1"); return !!a && hashPw(pw, a.salt) === a.hash; };
const rpi = process.argv.indexOf('--reset-admin');
if (require.main === module && rpi > -1) {  // node server.js --reset-admin YangiParol
  const given = process.argv[rpi + 1] && !process.argv[rpi + 1].startsWith('--') ? process.argv[rpi + 1] : '', pw = given || crypto.randomBytes(6).toString('hex');
  setAdminPass(pw); if (given) { try { fs.unlinkSync(PWFILE); } catch { } } else fs.writeFileSync(PWFILE, pw + '\n', { mode: 0o600 });
  console.log(`\n  Admin paroli yangilandi → login: admin   parol: ${pw}\n`); db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); db.close(); process.exit(0);
}
if (E.ADMIN_PASS) { if (!adminPassOk(E.ADMIN_PASS)) { setAdminPass(E.ADMIN_PASS); console.log('\n  ADMIN paroli .env dagi ADMIN_PASS ga moslandi → login: admin\n'); } if (E.ADMIN_PASS.length < 8) console.log('  ⚠ ADMIN_PASS juda qisqa: kamida 8 belgi qo‘ying.'); }
else if (!get("SELECT 1 x FROM users WHERE role='admin'")) {
  const pw = crypto.randomBytes(6).toString('hex'); setAdminPass(pw); try { fs.writeFileSync(PWFILE, pw + '\n', { mode: 0o600 }); } catch { }
  console.log(`\n  ADMIN yaratildi → login: admin   parol: ${pw}\n  (parol ${PWFILE} faylida ham saqlandi; .env da ADMIN_PASS bering yoki: node server.js --reset-admin YangiParol)\n`);
}
sweep(); sweepVf();
autoBackup();
if (require.main === module) for (const sg of ['SIGINT', 'SIGTERM']) process.on(sg, () => { console.log('\n  to‘xtatilmoqda… baza saqlanyapti'); try { server.close(); db.exec('PRAGMA wal_checkpoint(TRUNCATE)'); db.close(); } catch { } process.exit(0); });
if (require.main === module) server.listen(CFG.port, () => console.log(`BrawlBozor → ${CFG.base}  (admin: ${CFG.base}/admin)  payme=${CFG.payme} click=${CFG.click} autopay=${apcCfg().on} google=${!!googleId()}\n  DATA: ${CFG.data}`));
module.exports = { server, CFG };
