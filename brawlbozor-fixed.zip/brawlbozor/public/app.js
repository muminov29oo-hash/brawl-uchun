'use strict';
const D = window.D, $ = s => document.querySelector(s);
let lang = (navigator.language || '').slice(0, 2) === 'ru' ? 'ru' : 'uz'; try { lang = localStorage.getItem('bb_lang') || lang; } catch (e) { } if (!D[lang]) lang = 'uz';
const t = (k, ...a) => { let s = D[lang][k] ?? D.en[k] ?? k; if (typeof s !== 'string') return s; a.forEach((v, i) => s = s.split('{' + i + '}').join(v)); return s; };
const num = n => Number(n).toLocaleString('ru-RU').replace(/ /g, ' ');
const fmt = n => num(n) + ' ' + t('cur');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const when = ts => new Date(ts).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const S = { me: null, cfg: null, cat: 'all', f: {}, threads: [], unread: 0, nu: 0, sel: null, th: null, view: 'home', arg: 0, stats: null, ordTab: 'all', histTab: 'all', pm: '', autoPay: 0 };

// ---------- art (original, not Supercell assets) ----------
const SPRITE = `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs><symbol id="gem" viewBox="0 0 100 120"><path d="M50 2 92 28v64L50 118 8 92V28z" fill="currentColor"/><path d="M50 2 92 28 50 52 8 28z" fill="#fff" fill-opacity=".4"/><path d="M50 52 92 28v64L50 118z" fill="#000" fill-opacity=".22"/><path d="M50 52 8 28v64l42 26z" fill="#fff" fill-opacity=".1"/><path d="M50 2 92 28v64L50 118 8 92V28z" fill="none" stroke="#fff" stroke-opacity=".65" stroke-width="3" stroke-linejoin="round"/></symbol></defs></svg>`;
const GEMS = `<svg class="hero" viewBox="0 0 300 230" aria-hidden="true"><ellipse cx="150" cy="205" rx="110" ry="14" fill="#000" opacity=".35"/><use href="#gem" x="20" y="95" width="82" height="98" style="color:#ffc928"/><use href="#gem" x="198" y="85" width="86" height="103" style="color:#c14bff"/><use href="#gem" x="88" y="20" width="124" height="148" style="color:#2ee66b"/><use href="#gem" x="62" y="128" width="60" height="72" style="color:#35c8ff"/><use href="#gem" x="170" y="132" width="56" height="67" style="color:#ff5a78"/></svg>`;
const MARK = `<svg class="mark" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="mg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd95a"/><stop offset="1" stop-color="#ff9d1c"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="#2b1370"/><path d="M32 8 52 22 44 52H20L12 22Z" fill="url(#mg)" stroke="#fff" stroke-width="3" stroke-linejoin="round"/><path d="M12 22h40M32 8l-6 14 6 30 6-30z" fill="none" stroke="#fff" stroke-opacity=".7" stroke-width="2.5" stroke-linejoin="round"/></svg>`;
const CI = { accounts: ['👤', '#2b6cff,#1b3aa8'], gems: ['💎', '#1fd35e,#0c7a33'], pass: ['🎫', '#a14bff,#5a1fb5'], pro: ['👑', '#ffc928,#c77a00'], topup: ['💳', '#35c8ff,#1572a8'], trophy: ['🏆', '#ffb300,#b86a00'], rank: ['🎖️', '#ff5a78,#a3173a'], boost: ['🚀', '#ff7a2b,#a8420d'], quests: ['📜', '#8e6bff,#3d2699'], pins: ['📌', '#ff4fa8,#a3176b'], other: ['📦', '#6f7bff,#2c3590'] };
const I = { home: '<path d="M3 11 12 3l9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>', search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>', plus: '<path d="M12 5v14M5 12h14"/>', chat: '<path d="M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.3A8 8 0 1 1 21 12z"/>', user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>' };
const svg = (k, w = 24) => `<svg width="${w}" height="${w}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[k]}</svg>`;

// ---------- api ----------
async function api(m, p, b) {
  let r, j = {};
  try { r = await fetch(p, { method: m, credentials: 'same-origin', headers: b ? { 'Content-Type': 'application/json' } : {}, body: b ? JSON.stringify(b) : undefined }); } catch (e) { const x = new Error('net'); x.key = 'net'; throw x; }
  try { j = await r.json(); } catch (e) { }
  if (!r.ok) { const x = new Error(j.error || 'server'); x.key = j.error || 'server'; x.status = r.status; x.detail = j.detail; throw x; }
  return j;
}
const errText = e => { const k = (e && e.key) || 'server'; if (k === 'server' && e.detail) return t('err_server') + ' [' + e.detail + ']'; if (k === 'own_item' && S.me) return t('err_own_item') + ' (' + S.me.name + ')'; if (k.startsWith('f_') && k !== 'f_title') return t('e_field', t('a_' + k.slice(2))); const m = D[lang]['err_' + k] ?? D.en['err_' + k]; return m !== undefined ? m : (D[lang][k] ?? k); };
let tt; function toast(m) { const e = $('#ts'); e.textContent = m; e.classList.remove('hide'); clearTimeout(tt); tt = setTimeout(() => e.classList.add('hide'), 3800); }
const safe = f => async (...a) => { try { return await f(...a); } catch (e) { if (e.key === 'auth') { if (S.me) { S.me = null; authDlg('login'); } } else if (e && e.key) toast(errText(e)); else { console.error(e); toast(t('err_server') + ' [JS: ' + (e && e.message || e) + ']'); } } };
const dlg = h => { $('#db').innerHTML = h; if (!$('#dlg').open) $('#dlg').showModal(); };
const closeDlg = () => { if ($('#dlg').open) $('#dlg').close(); };
const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const age = ts => { if (!ts) return t('newb'); const d = Math.max(1, Math.floor((Date.now() - ts) / 864e5)); return d < 30 ? d + ' ' + t('d') : d < 365 ? Math.floor(d / 30) + ' ' + t('mo') : Math.floor(d / 365) + ' ' + t('y'); };
const stars = n => '★'.repeat(Math.round(n));
const VB = '<svg class="vb" viewBox="0 0 24 24" role="img" aria-label="verified"><path d="M12 1.6l2.5 1.8 3.1-.1 1 2.9 2.5 1.9-.9 3 .9 3-2.5 1.9-1 2.9-3.1-.1L12 22.4l-2.5-1.8-3.1.1-1-2.9-2.5-1.9.9-3-.9-3 2.5-1.9 1-2.9 3.1.1z" fill="#3b9bff"/><path d="M7.9 12.2l2.7 2.7 5.5-5.6" fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const nm = u => esc(u.name) + (u.vf ? VB : '');
const card4 = n => String(n).replace(/(.{4})/g, '$1 ').trim();
const avatar = (s, cls = '') => `<div class="av ${cls}" style="background:linear-gradient(145deg,hsl(${hue(s.name)} 70% 55%),hsl(${(hue(s.name) + 40) % 360} 70% 35%))">${esc(s.name[0].toUpperCase())}${s.online ? '<i></i>' : ''}</div>`;
const cats = () => Object.keys(S.cfg.cats);
const AL = a => S.cfg.cats[a.cat].f.filter(x => a.attrs[x.k] !== undefined && a.attrs[x.k] !== '').slice(0, 3).map(x => (x.t === 'sel' ? t(a.attrs[x.k]) : x.t === 'num' ? num(a.attrs[x.k]) + ' ' + t('a_' + x.k).toLowerCase() : a.attrs[x.k])).join(' · ');
const needAuth = f => { if (S.me) return true; S.after = f || null; authDlg('login'); return false; };
const catIco = (c, size = 56) => `<span style="font-size:${size}px;line-height:1">${CI[c][0]}</span>`;

// ---------- lang/theme ----------
try { const th = localStorage.getItem('bb_theme'); if (th) document.documentElement.dataset.theme = th; } catch (e) { }
function setLang(l) { lang = l; try { localStorage.setItem('bb_lang', l); } catch (x) { } document.documentElement.lang = l; route(); }

// ---------- auth / splash ----------
function authDlg(mode = 'login') {
  const reg = mode === 'register';
  dlg(`<div style="text-align:center">${MARK.replace('class="mark"', 'class="mark" style="width:64px;height:64px"')}<h2 id="dt" style="margin:8px 0 4px">${t('welcome')}</h2><p class="mu" style="margin:0 0 10px">${t('welcome_d')}</p></div>
<form id="authf"><div class="chips" style="justify-content:center"><button type="button" class="chip" data-am="login" aria-pressed="${!reg}">${t('login')}</button><button type="button" class="chip" data-am="register" aria-pressed="${reg}">${t('create_acc')}</button></div>
<label for="an">${t('name_l')}</label><input id="an" autocomplete="username" maxlength="20" required>
<label for="ap">${t('pass')}</label><input id="ap" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" minlength="${reg ? 6 : 1}" required>
${reg ? `<label class="tg"><input type="checkbox" id="aa" required> <span>${t('adult_ok')} <a href="#" class="ln" data-terms>(${t('rules_link')})</a></span></label>` : ''}
<div class="err" id="ae"></div><button class="pb blk" id="ago">${t(reg ? 'create_acc' : 'login')}</button>${S.cfg.google ? `<div class="mu" style="text-align:center;margin:14px 0 8px">${t('or')}</div><div id="gbtn" style="display:flex;justify-content:center;min-height:44px"></div><p class="note" style="text-align:center">${t('g_note')}</p>` : ''}<p class="mu" style="text-align:center;margin:12px 0 0">${t('fine')}</p></form>`);
  if (S.cfg.google) initGoogle();
  $('#authf').onsubmit = async e => {
    e.preventDefault(); $('#ago').disabled = true;
    try { S.me = await api('POST', reg ? '/api/register' : '/api/login', { name: $('#an').value, pass: $('#ap').value, adult: reg ? $('#aa').checked : undefined }); closeDlg(); await poll(); const f = S.after; S.after = null; if (f) f(); else route(); }
    catch (er) { $('#ae').textContent = errText(er); $('#ago').disabled = false; }
  };
  setTimeout(() => $('#an') && $('#an').focus(), 30);
}
let gsiLoading = null;
function initGoogle() {
  const draw = () => {
    if (!window.google || !$('#gbtn')) return;
    google.accounts.id.initialize({ client_id: S.cfg.google, callback: async resp => {
      try {
        try { S.me = await api('POST', '/api/google', { credential: resp.credential }); }
        catch (er) { if (er && er.key === 'adult' && confirm(t('adult_ok'))) S.me = await api('POST', '/api/google', { credential: resp.credential, adult: true }); else throw er; }
        closeDlg(); await poll(); const f = S.after; S.after = null; if (f) f(); else route();
      }
      catch (er) { const e = $('#ae'); if (e) e.textContent = errText(er); }
    } });
    google.accounts.id.renderButton($('#gbtn'), { theme: 'filled_black', size: 'large', shape: 'pill', width: 280, text: 'continue_with', locale: lang });
  };
  if (window.google && window.google.accounts) return draw();
  if (!gsiLoading) gsiLoading = new Promise((ok, no) => { const s = document.createElement('script'); s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.onload = ok; s.onerror = no; document.head.appendChild(s); });
  gsiLoading.then(draw).catch(() => { const g = $('#gbtn'); if (g) g.textContent = t('err_net'); });
}
function splash() {
  const e = $('#splash'); e.classList.remove('hide');
  e.innerHTML = `<div class="chips" style="position:absolute;top:14px;right:10px">${['uz', 'ru', 'en'].map(l => `<button class="chip" data-sl="${l}" aria-pressed="${l === lang}">${l.toUpperCase()}</button>`).join('')}</div><div class="lgbig">BRAWL<b>BOZOR</b></div>${GEMS}<p>${t('tag')}</p><button class="pb yel blk" style="max-width:300px;margin-top:22px;font-size:18px;padding:15px" id="sgo">${t('start')} →</button><div class="mu" style="margin-top:22px">BrawlBozor © 2026</div>`;
  $('#sgo').onclick = () => { e.classList.add('hide'); try { localStorage.setItem('bb_seen', '1'); } catch (x) { } if (!S.me) authDlg('login'); };
}

// ---------- shell: top bar + bottom nav ----------
const AUTHV = ['sell', 'chats', 'chat', 'wallet', 'history', 'orders', 'favorites', 'mylistings', 'support', 'profile', 'panel', 'notifs', 'verify'];
const TITLES = { categories: 'cats_t', search: 'n_search', sell: 's_t', chats: 'chats_t', wallet: 'topup_t', history: 'hist_t', orders: 'ord_t', favorites: 'fav_t', mylistings: 'pf_my', support: 'help_t', profile: 'pf_t', panel: 'pn_t', settings: 'set_t', notifs: 'notif_t', verify: 'vf_t' };
const trail = [];
function bar() {
  const v = S.view, bell = `<button class="ic" data-go="notifs" aria-label="${t('notif_t')}">🔔${S.nu ? `<span class="cnt">${S.nu}</span>` : ''}</button>`;
  let l, ti = '', r = '';
  if (v === 'home') { l = `<div class="logo" data-go="home">${MARK}<span>Brawl<b>Bozor</b></span></div>`; ti = ''; r = bell; }
  else {
    l = `<button class="ic" data-back aria-label="${t('back')}">←</button>`;
    ti = v === 'market' ? (S.cat === 'all' ? t('shop_t') : t('c_' + S.cat)) : v === 'item' || v === 'seller' ? '' : v === 'chat' ? '' : t(TITLES[v] || 'shop_t');
    if (v === 'favorites') r = `<button class="pb out sm" data-favclear>${t('clear')}</button>`;
    if (v === 'profile') r = `<button class="ic" data-go="settings" aria-label="${t('pf_set')}">⚙</button><button class="ic" id="lo" aria-label="${t('logout')}" title="${t('logout')}">⎋</button>`;
  }
  $('#tb').innerHTML = `<div class="sl">${l}</div><div class="ti" id="tbt">${esc(S.title || ti)}</div><div class="sr" id="tbr">${r}</div>`;
  const cur = { home: 'home', categories: 'home', market: 'search', search: 'search', item: 'search', seller: 'search', sell: 'sell', chats: 'chats', chat: 'chats' }[v] || 'profile';
  const nb = (k, ico, lab, extra = '') => `<button data-go="${k}" ${cur === k ? 'aria-current="page"' : ''}>${svg(ico)}<span>${lab}</span>${extra}</button>`;
  $('#bn').innerHTML = nb('home', 'home', t('n_home')) + nb('search', 'search', t('n_search')) + `<button class="plus" data-go="sell" aria-label="${t('n_sell')}">${svg('plus', 28)}</button>` + nb('chats', 'chat', t('n_chat'), S.unread ? `<span class="cnt">${S.unread}</span>` : '') + nb('profile', 'user', t('n_prof'));
  document.title = (S.unread + S.nu ? '(' + (S.unread + S.nu) + ') ' : '') + 'BrawlBozor';
}

// ---------- router ----------
function route() {
  const h0 = location.hash || '#home';
  if (trail.length > 1 && trail[trail.length - 2] === h0) trail.pop(); else if (trail[trail.length - 1] !== h0) trail.push(h0);
  const h = h0.slice(1), m = h.match(/^(chat|item|seller)-(\d+)$/), mk = h.match(/^market(?:-(\w+))?$/);
  S.title = ''; S.sel = null; paneKey = ''; S.th = null; S.arg = 0;
  if (m) { S.view = m[1]; S.arg = +m[2]; if (S.view === 'chat') S.sel = S.arg; }
  else if (mk) { S.view = 'market'; S.cat = mk[1] && S.cfg.cats[mk[1]] ? mk[1] : 'all'; S.f = {}; }
  else if (h === 'search') { S.view = 'market'; S.cat = 'all'; S.f = {}; }
  else if (TITLES[h] || h === 'home') S.view = h; else S.view = 'home';
  closeDlg();
  if (AUTHV.includes(S.view) && !S.me) { bar(); $('#app').innerHTML = `<div class="empty">${t('need_login')}<br><br><button class="pb" id="lgi">${t('login')}</button></div>`; $('#lgi').onclick = () => { S.after = () => route(); authDlg('login'); }; return; }
  bar(); scrollTo(0, 0); safe(draw)();
}
const go = n => { if (location.hash === '#' + n) route(); else location.hash = n; };
addEventListener('hashchange', route);
async function draw() {
  const f = { home, categories, market, sell, chats, chat: chats, item, seller, wallet, history: historyView, orders, favorites, mylistings, support, profile, panel, settings, notifs, verify }[S.view];
  if (f) await f();
}

// ---------- home ----------
const pcard = a => {
  const s = a.seller;
  return `<article class="pc"><div class="im" data-open="${a.id}">${a.imgs[0] ? `<img src="${esc(a.imgs[0])}" alt="" loading="lazy">` : catIco(a.cat)}</div>
<button class="hv" data-fav="${a.id}" aria-pressed="${a.fav}" aria-label="${t('fav')}">${a.fav ? '♥' : '♡'}</button>${a.boost ? `<span class="tag y bd2">🔥 ${t('hot')}</span>` : ''}
<h3 data-open="${a.id}">${esc(a.title)}</h3><div class="mu">${esc(AL(a))}</div><div class="pp">${fmt(a.price)}</div>
<div class="sel">${avatar(s)}<a class="ln" href="#seller-${s.id}" style="font-size:12px">${nm(s)}</a>${a.isAuto ? '<span class="bolt" title="' + t('auto') + '">⚡</span>' : ''}${s.rn ? `<span class="st">★${s.ravg.toFixed(1)}</span>` : ''}</div></article>`;
};
async function home() {
  const me = S.me;
  $('#app').innerHTML = `<div class="card pcard">${me ? avatar({ name: me.name, online: true }) + `<div class="mid"><b>${esc(me.name)}</b><div class="mu">ID: #${me.id}</div></div><button class="balchip" data-go="wallet" id="balc">🪙 ${num(me.bal || 0)}</button>` : `<div class="av" style="background:#5b21d6">?</div><div class="mid"><b>${t('guest')}</b><div class="mu">${t('guest_d')}</div></div><button class="pb sm" id="hl">${t('login')}</button>`}</div>
<div class="banner"><h2>${t('hb_t')}</h2><button class="pb sm" data-go="market">${t('hb_b')} →</button>${GEMS}</div>
<div class="qa"><button data-go="categories"><span>🛍️</span>${t('qa_shop')}</button><button data-go="favorites"><span>⭐</span>${t('qa_fav')}</button><button data-go="chats"><span>💬</span>${t('qa_chat')}</button><button data-go="profile"><span>👤</span>${t('qa_prof')}</button></div>
<div class="sec"><h2>${t('pop')} 🔥</h2><button class="lk" data-go="market">${t('all')} →</button></div><div class="grid" id="grid"><div class="empty" style="grid-column:1/-1">${t('loading')}</div></div>`;
  const h = $('#hl'); if (h) h.onclick = () => authDlg('login');
  const r = await api('GET', '/api/listings?cat=all'); if (S.view !== 'home') return;
  $('#grid').innerHTML = r.items.length ? r.items.slice(0, 8).map(pcard).join('') : `<div class="empty" style="grid-column:1/-1">${t('empty')}</div>`;
}

// ---------- categories & market ----------
async function categories() {
  const r = await api('GET', '/api/listings?cat=all'), counts = r.counts;
  $('#app').innerHTML = `<div class="search"><input id="cs" type="search" placeholder="${t('search_ph')}" aria-label="${t('search_ph')}"></div><div class="cl" id="cl"></div>`;
  const paint = () => { const q = $('#cs').value.toLowerCase(); $('#cl').innerHTML = cats().filter(c => !q || (t('c_' + c) + ' ' + t('cd_' + c)).toLowerCase().includes(q)).map(c => `<button data-cat="${c}"><span class="ci" style="background:linear-gradient(145deg,${CI[c][1]})">${CI[c][0]}</span><div><b>${t('c_' + c)}</b><div class="mu">${t('cd_' + c)} · ${counts[c] || 0}</div></div><span class="ch">›</span></button>`).join(''); };
  paint(); $('#cs').oninput = paint;
}
let mdeb, mseq = 0;
function market() {
  const F = S.f, v = k => F[k] ?? '';
  $('#app').innerHTML = `<div class="search"><input id="q" type="search" placeholder="${t('search_ph')}" value="${esc(v('q'))}" aria-label="${t('search_ph')}"></div><div class="chips" id="chips"></div>
<details ${F.open ? 'open' : ''} id="fd0"><summary class="pb out sm" style="display:inline-flex;list-style:none;margin-bottom:10px">⚙ ${t('filt')}</summary><div class="fl">
${S.cat === 'accounts' ? `<label>${t('tr')}</label><span></span><input data-f="t1" type="number" min="0" placeholder="${t('min')}" value="${esc(v('t1'))}"><input data-f="t2" type="number" min="0" placeholder="${t('max')}" value="${esc(v('t2'))}"><label>${t('br')}</label><span></span><input data-f="b1" type="number" min="0" placeholder="${t('min')}" value="${esc(v('b1'))}"><input data-f="b2" type="number" min="0" placeholder="${t('max')}" value="${esc(v('b2'))}"><label>PRIMES</label><span></span><input data-f="p1" type="number" min="0" placeholder="${t('min')}" value="${esc(v('p1'))}"><input data-f="p2" type="number" min="0" placeholder="${t('max')}" value="${esc(v('p2'))}">` : ''}
<label>${t('col_p')}</label><span></span><input data-f="pmin" type="number" min="0" placeholder="${t('price_min')}" value="${esc(v('pmin'))}"><input data-f="pmax" type="number" min="0" placeholder="${t('price_max')}" value="${esc(v('pmax'))}">
<label class="tg full"><input type="checkbox" data-f="online" ${F.online ? 'checked' : ''}> ${t('online')}</label><label class="tg full"><input type="checkbox" data-f="auto" ${F.auto ? 'checked' : ''}> <span class="bolt">⚡</span> ${t('auto')}</label>
<button class="pb out sm full" id="fclr">${t('filt_clr')}</button></div></details>
<div class="grid" id="grid"></div>`;
  $('#q').oninput = e => { F.q = e.target.value; clearTimeout(mdeb); mdeb = setTimeout(() => safe(loadGrid)(), 250); };
  $('#app').querySelectorAll('[data-f]').forEach(i => i.addEventListener('input', () => { F[i.dataset.f] = i.type === 'checkbox' ? i.checked : i.value; F.open = 1; clearTimeout(mdeb); mdeb = setTimeout(() => safe(loadGrid)(), 250); }));
  $('#fclr').onclick = () => { S.f = {}; market(); };
  return loadGrid();
}
async function loadGrid() {
  const F = S.f, p = new URLSearchParams({ cat: S.cat }); ['t1', 't2', 'b1', 'b2', 'p1', 'p2', 'pmin', 'pmax', 'q'].forEach(k => { if (F[k] !== undefined && F[k] !== '') p.set(k, F[k]); }); if (F.online) p.set('online', '1'); if (F.auto) p.set('auto', '1');
  const seq = ++mseq, r = await api('GET', '/api/listings?' + p); if (seq !== mseq || S.view !== 'market') return;
  $('#chips').innerHTML = `<button class="chip" data-cat="all" aria-pressed="${S.cat === 'all'}">${t('all')}</button>` + cats().map(c => `<button class="chip" data-cat="${c}" aria-pressed="${c === S.cat}">${CI[c][0]} ${t('c_' + c)}<small>${r.counts[c] || 0}</small></button>`).join('');
  $('#grid').innerHTML = r.items.length ? r.items.map(pcard).join('') : `<div class="empty" style="grid-column:1/-1">${t('empty')}</div>`;
  bar();
}

// ---------- item / seller ----------
const rvHtml = z => `<div class="rv"><b class="st">${'★'.repeat(z.stars)}</b> ${esc(z.from)}<br>${esc(z.text || t('r_none'))}</div>`;
async function item() {
  const r = await api('GET', '/api/listings/' + S.arg).catch(e => { $('#app').innerHTML = `<div class="empty">${t('none')}</div>`; throw e; }); if (S.view !== 'item') return;
  const a = r.item, own = S.me && S.me.id === a.seller.id, s = a.seller, isAdm = S.me && S.me.role === 'admin';
  const spec = S.cfg.cats[a.cat].f.filter(x => a.attrs[x.k] !== undefined).map(x => `<tr><td class="mu">${t('a_' + x.k)}</td><td>${esc(x.t === 'sel' ? t(a.attrs[x.k]) : x.t === 'num' ? num(a.attrs[x.k]) : a.attrs[x.k])}</td></tr>`).join('');
  $('#tbr').innerHTML = `<button class="ic" data-fav="${a.id}" aria-label="${t('fav')}">${a.fav ? '♥' : '♡'}</button><button class="ic" data-share="1" aria-label="${t('share')}">⤴</button>`;
  $('#app').innerHTML = `<div class="gal" id="big">${a.imgs[0] ? `<img class="zi" src="${esc(a.imgs[0])}" alt="">` : catIco(a.cat, 110)}</div>${a.imgs.length > 1 ? `<div class="thumbs">${a.imgs.map(p => `<img data-sw="1" src="${esc(p)}" alt="">`).join('')}</div>` : ''}
<div class="rw l" style="margin-bottom:0"><span class="tag">${t('c_' + a.cat)}</span>${a.status !== 'active' ? `<span class="tag r">${t('ls_' + a.status)}</span>` : ''}${a.boost ? `<span class="tag y">🔥 ${t('hot')}</span>` : ''}</div>
<h1 style="margin:6px 0">${esc(a.title)}</h1><div class="big-p">${fmt(a.price)} ${a.isAuto ? '<span class="bolt">⚡</span>' : ''}</div>
<div class="trust"><span class="tag g">🛡 ${t('escrow_b')}</span>${a.isAuto ? `<span class="tag g">⚡ ${t('fast_b')}</span>` : ''}<span class="tag">✔ ${t('safe')}</span></div>
${spec ? `<table class="spec">${spec}</table>` : ''}
<div class="card sellerc">${avatar(s)}<div style="flex:1"><a class="ln" href="#seller-${s.id}">${nm(s)}</a><div class="st">${s.rn ? stars(s.ravg) + ' ' + s.ravg.toFixed(1) + ' (' + s.rn + ')' : ''}</div><div class="mu">${s.online ? '● ' + t('online_l') : t('offline_l')} · ${age(s.since)}</div></div></div>
${a.desc ? `<h2>${t('f_desc')}</h2><p style="white-space:pre-wrap;margin:0">${esc(a.desc)}</p>` : ''}
<div style="margin-top:16px">${a.status === 'sold' ? `<span class="tag">${t('sold')}</span>` : own ? `<div class="rw l"><span class="mu">${t('yours')}</span><button class="pb red sm" data-del="${a.id}">${t('del')}</button></div>` : a.status === 'active' ? `<button class="pb yel blk" style="font-size:17px;padding:14px" data-buy="${a.id}">${t('buy')} 🛒</button><div class="rw"><button class="pb out" style="flex:1" data-chat="${a.id}">💬 ${t('msg')}</button><button class="pb out" data-rep="item" aria-label="${t('rep')}">⚑</button></div>` : (isAdm ? `<button class="pb red sm" data-del="${a.id}">${t('del')}</button>` : '')}</div>
<h2>${t('rv')}</h2>${r.reviews.length ? r.reviews.map(rvHtml).join('') : `<div class="mu">${t('no_rev')}</div>`}`;
}
async function seller() {
  const r = await api('GET', '/api/users/' + S.arg).catch(e => { $('#app').innerHTML = `<div class="empty">${t('none')}</div>`; throw e; }); if (S.view !== 'seller') return; const u = r.user;
  $('#app').innerHTML = `<div class="pf">${avatar(u, 'big')}<h1>${nm(u)}</h1><div class="st">${u.rn ? stars(u.ravg) + ' ' + u.ravg.toFixed(1) + ' (' + u.rn + ')' : ''}</div><div class="mu">${age(u.since)} · ${r.deals} ${t('sp_deals')}</div></div>
<h2>${t('offers')}</h2><div class="grid">${r.items.length ? r.items.map(pcard).join('') : `<div class="mu">${t('none')}</div>`}</div><h2>${t('rv')}</h2>${r.reviews.length ? r.reviews.map(rvHtml).join('') : `<div class="mu">${t('no_rev')}</div>`}`;
}
async function favorites() {
  const r = await api('GET', '/api/favs'); if (S.view !== 'favorites') return;
  $('#app').innerHTML = r.items.length ? `<div class="grid">${r.items.map(pcard).join('')}</div>` : `<div class="empty">${t('none')}</div>`;
}

// ---------- orders / my listings ----------
const dealCard = x => `<div class="dl">${x.img ? `<img class="th1" src="${esc(x.img)}" alt="">` : `<div class="th1 cat-ico" style="display:grid;place-items:center;font-size:24px;background:#5b21d6">🎮</div>`}<div class="ri"><b>${esc(x.title)}</b><div class="mu">${x.role === 'buyer' ? t('c_s') : t('c_b')}: ${nm(x.other)} · ${fmt(x.price)}</div></div><span class="tag ${x.status === 'done' ? 'g' : x.status === 'dispute' ? 'r' : ''}">${t('st_' + x.status)}</span><button class="pb sm" data-go="chat-${x.id}">${t('view')}</button></div>`;
async function orders() {
  await poll(); if (S.view !== 'orders') return; const tab = S.ordTab, mine = S.threads.filter(x => x.role === 'buyer' && x.status !== 'chat');
  const list = mine.filter(x => tab === 'all' || (tab === 'prog' ? ['paid', 'dispute'].includes(x.status) : ['done', 'refunded'].includes(x.status)));
  $('#app').innerHTML = `<div class="chips">${[['all', t('all')], ['prog', t('tab_prog')], ['done', t('tab_done')]].map(([k, l]) => `<button class="chip" data-ot="${k}" aria-pressed="${tab === k}">${l}</button>`).join('')}</div>${list.length ? list.map(dealCard).join('') : `<div class="empty">${t('none')}</div>`}`;
}
async function mylistings() {
  const r = await api('GET', '/api/my/listings'); if (S.view !== 'mylistings') return;
  $('#app').innerHTML = r.items.length ? r.items.map(a => `<div class="dl">${a.imgs[0] ? `<img class="th1" src="${esc(a.imgs[0])}" alt="">` : `<div class="th1" style="display:grid;place-items:center;font-size:24px;background:#5b21d6">${CI[a.cat][0]}</div>`}<div class="ri"><a class="ln" href="#item-${a.id}">${esc(a.title)}</a><div class="mu">${fmt(a.price)}${a.reason ? ' · ' + t('ls_why') + ': ' + esc(a.reason) : ''}</div></div><span class="tag ${a.status === 'active' ? 'g' : a.status === 'rejected' ? 'r' : ''}">${t('ls_' + a.status)}</span>${a.status === 'sold' ? (a.thread ? `<button class="pb sm" data-go="chat-${a.thread.id}">${t('view')}</button>` : '') : `${a.status === 'active' ? `<button class="pb out sm" data-boost="${a.id}">🔥</button>` : ''}<button class="pb red sm" data-del="${a.id}">✕</button>`}</div>`).join('') : `<div class="empty">${t('none')}</div>`;
}

// ---------- sell ----------
let pics = [];
const pv = () => { const e = $('#pv'); if (e) e.innerHTML = pics.map((p, i) => `<span class="pi"><img src="${esc(p)}" alt=""><button type="button" data-rp="${i}" aria-label="x">×</button></span>`).join(''); };
function sell() {
  $('#app').innerHTML = `<div class="card"><label for="fc" style="margin-top:0">${t('f_cat')}</label><select id="fc">${cats().map(c => `<option value="${c}">${CI[c][0]} ${t('c_' + c)}</option>`).join('')}</select>
<label for="ft">${t('f_title')}</label><input id="ft" maxlength="80" required><div id="af"></div><label for="fi" id="fil"></label><input id="fi" type="file" accept="image/*" multiple><div class="pics" id="pv"></div>
<label for="fp">${t('f_price2')}</label><input id="fp" type="number" min="1000" step="1000" required><label for="fd">${t('f_desc')}</label><textarea id="fd" rows="3" maxlength="600"></textarea>
<label for="fa"><span class="bolt">⚡</span> ${t('f_auto')}</label><input id="fa" maxlength="300" autocomplete="off"><div class="err" id="fe"></div><p class="note">${t('s_note')}</p>${S.cfg.needApproval ? `<p class="note">${t('s_wait')}</p>` : ''}<button class="pb blk" id="fg">${t('s_go')}</button></div>`;
  $('#fc').value = S.sellCat || 'accounts'; $('#fc').onchange = () => { S.sellCat = $('#fc').value; buildSell(); }; buildSell(); pv();
  $('#fi').onchange = safe(async e => { for (const f of [...e.target.files]) { if (pics.length >= 6) break; pics.push(await upload(f, 900)); } e.target.value = ''; pv(); });
  $('#fg').onclick = safe(submitListing);
}
function buildSell() {
  const c = $('#fc').value, spec = S.cfg.cats[c], keep = {}; $('#af').querySelectorAll('[id^=sf_]').forEach(i => keep[i.id] = i.value);
  $('#af').innerHTML = spec.f.map(f => {
    const id = 'sf_' + f.k, lab = `<label for="${id}">${t('a_' + f.k)}${f.r ? ' *' : ''}</label>`;
    if (f.t === 'sel') return lab + `<select id="${id}"${f.r ? ' required' : ''}>${f.o.map(o => `<option value="${o}">${t(o)}</option>`).join('')}</select>`;
    if (f.t === 'num') return lab + `<input id="${id}" type="number" inputmode="numeric" min="${f.min}" max="${f.max === 'year' ? new Date().getFullYear() : f.max}"${f.r ? ' required' : ''}>`;
    return lab + `<input id="${id}" maxlength="${f.max}"${f.r ? ' required' : ''}>`;
  }).join('');
  Object.entries(keep).forEach(([k, v]) => { const e = $('#' + k); if (e) e.value = v; });
  $('#fil').textContent = spec.img ? t('f_img') : t('f_img2');
}
const shrink = (f, max) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => { const i = new Image(); i.onload = () => { const k = Math.min(1, max / Math.max(i.width, i.height)), c = document.createElement('canvas'); c.width = Math.round(i.width * k); c.height = Math.round(i.height * k); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height); ok(c.toDataURL('image/jpeg', .72)); }; i.onerror = no; i.src = r.result; }; r.onerror = no; r.readAsDataURL(f); });
const upload = async (f, max) => (await api('POST', '/api/upload', { data: await shrink(f, max) })).url;
async function submitListing() {
  const er = $('#fe'); er.textContent = ''; const c = $('#fc').value, spec = S.cfg.cats[c];
  for (const i of [$('#ft'), ...spec.f.map(f => $('#sf_' + f.k)), $('#fp')]) if (!i.reportValidity()) return;
  if (pics.length < spec.img) { er.textContent = t('e_img'); return; }
  const attrs = {}; spec.f.forEach(f => { const v = $('#sf_' + f.k).value; if (v !== '') attrs[f.k] = v; });
  try {
    const r = await api('POST', '/api/listings', { cat: c, title: $('#ft').value, price: +$('#fp').value, desc: $('#fd').value, auto: $('#fa').value, attrs, imgs: pics });
    pics = []; toast(t(r.status === 'pending' ? 's_ok2' : 's_ok')); go('mylistings');
  } catch (e) { er.textContent = errText(e); }
}

// ---------- chats ----------
let paneKey = '', lastTyp = 0, msSig = '';
async function poll() {
  if (!S.me) return; const r = await api('GET', '/api/threads'); if (!S.me) return; if (r.uid !== S.me.id) { location.reload(); return; } S.threads = r.items; S.unread = r.unread; S.me.bal = r.bal;
  const b = $('#balc'); if (b) b.textContent = '🪙 ' + num(r.bal); const bv = $('#balv'); if (bv) bv.textContent = fmt(r.bal);
  S.nu = r.nu || 0; if (S.me.vf !== !!r.vf) { S.me.vf = !!r.vf; if (S.view === 'profile') safe(profile)(); }
  const sig = S.unread + ':' + S.nu; if (S._sig !== sig) { S._sig = sig; bar(); }
}
function chatList() {
  const el = $('#tl'); if (!el) return;
  el.innerHTML = S.threads.length ? S.threads.map(x => `<button data-t="${x.id}" aria-pressed="${x.id === S.sel}">${avatar(x.other)}<div class="tx2"><b>${esc(x.title)}</b><div class="mu">${nm(x.other)} · ${t('st_' + x.status)}</div><div class="mu pv">${esc(x.last)}</div></div>${x.unread ? `<span class="bd">${x.unread}</span>` : ''}</button>`).join('') : `<div class="empty">${t('c_none')}</div>`;
}
async function chats() {
  $('#app').innerHTML = `<div class="chat ${S.sel ? 'sel' : ''}" id="chat"><div class="tl" id="tl"></div><div class="pane" id="pane"></div></div>`;
  await poll(); if (!['chats', 'chat'].includes(S.view)) return; chatList(); await loadTh();
}
async function loadTh() {
  if (!S.sel || !S.me) { paintPane(); return; }
  try { const r = await api('GET', '/api/threads/' + S.sel); if (S.view !== 'chat' || r.thread.id !== S.sel) return; S.th = r; paintPane(); }
  catch (e) { if (e.key === 'not_found') { S.th = null; S.sel = null; } paintPane(); }
}
const sysText = s => { const a = s.a || [], PV = { balance: t('pay_balance'), payme: 'Payme', click: 'Click', apc: 'AutoPay' }; switch (s.k) { case 'm_paid2': return t(s.k, PV[a[0]] || a[0], fmt(a[1])); case 'm_done': return t(s.k, fmt(a[0]), a[1]); case 'm_done0': return t(s.k, fmt(a[0])); case 'off_ok': case 'm_lost': case 'm_res_b': return t(s.k, fmt(a[0])); default: return t(s.k, ...a); } };
function msgHtml(m, x) {
  const mine = S.me && m.fromId === S.me.id; if (m.sys) return `<div class="m sys">${esc(sysText(m.sys))}</div>`;
  let body; if (m.offer) {
    const o = m.offer; body = `💬 ${esc(t('offer_m', m.from, fmt(o.amt)))}<br>` + (o.st === 'p' ? (x.role === 'seller' && x.status === 'chat' ? `<button class="pb sm" data-oa="${m.id}:y">${t('accept')}</button> <button class="pb out sm" data-oa="${m.id}:n">${t('decline')}</button>` : `<span class="mu">${t('offer_pend')}</span>`) : `<b>${t(o.st === 'y' ? 'accept' : 'decline')}</b>`);
  } else body = esc(m.text || '') + (m.img ? `<img class="zi mi" src="${esc(m.img)}" alt="">` : '');
  const nm = m.from === 'admin' ? t('chat_admin') : m.from, tick = mine ? (m.ts <= x.otherRead ? ' ✓✓' : ' ✓') : '';
  return `<div class="m ${mine ? 'me' : ''}"><small>${esc(nm)} · ${new Date(m.ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}${tick}</small>${body}</div>`;
}
function msgsHtml(r) { let dl = ''; const n = new Date(); return r.msgs.map(m => { const d = new Date(m.ts).toDateString(); let h = ''; if (d !== dl) { dl = d; h = `<div class="ds">${d === n.toDateString() ? t('today') : d === new Date(n - 864e5).toDateString() ? t('yday') : new Date(m.ts).toLocaleDateString('ru-RU')}</div>`; } return h + msgHtml(m, r.thread); }).join(''); }
function paintPane() {
  const r = S.th, pane = $('#pane'); if (!pane) return;
  if (!r || r.thread.id !== S.sel) { if (paneKey !== 'none') { pane.innerHTML = `<div class="empty" style="margin:auto">${t('c_pick')}</div>`; paneKey = 'none'; } chatList(); return; }
  const x = r.thread, key = [x.id, x.status, x.delivered, x.price, x.reviewed, x.role, x.hold && x.hold.frozen, x.hold && x.hold.released, lang].join('|');
  chatList(); const o = x.role === 'buyer' ? x.seller : x.buyer; const tbt = $('#tbt'); if (tbt) tbt.textContent = x.role === 'admin' ? x.buyer.name + ' ⇄ ' + x.seller.name : o.name;
  if (key !== paneKey) {
    const old = $('#ci'), ov = old ? old.value : '', foc = old && document.activeElement === old; paneKey = key; msSig = ''; let act = '';
    if (x.role === 'buyer') {
      if (x.status === 'chat') act = `<button class="pb out sm" data-offer="1">${t('offer')}</button><button class="pb sm" data-pay="1">${t('pay')}</button>`;
      if (x.status === 'paid') act = `<button class="pb sm" data-done="1">${t('done')}</button><button class="pb out sm" data-disp="1">${t('disp')}</button>`;
      if (x.status === 'done') { if (x.hold && !x.hold.released) act += `<button class="pb out sm" data-disp="1">${t('disp')}</button>`; act += x.reviewed ? `<span class="tag">${t('reviewed')}</span>` : `<button class="pb out sm" data-review="1">${t('rate_seller')}</button>`; }
    } else if (x.role === 'seller') {
      if (x.status === 'chat') act = `<span class="mu">${t('w_pay')}</span>`;
      if (x.status === 'paid') act = x.delivered ? `<span class="tag g">${t('delivered')}</span>` : `<button class="pb sm" data-deliver="1">${t('deliver_btn')}</button>`;
    } else act = `<a class="pb out sm" href="/admin">${t('adm')}</a>`;
    pane.innerHTML = `<div class="ph">${x.img ? `<img class="th1" data-gal="${x.lid}" src="${esc(x.img)}" alt="">` : ''}<div style="margin-right:auto;min-width:0"><b>${esc(x.title)}</b> · ${fmt(x.price)} <span class="tag ${x.status === 'done' ? 'g' : x.status === 'dispute' ? 'r' : ''}">${t('st_' + x.status)}</span><div class="mu">${x.role === 'admin' ? esc(x.buyer.name) + ' ⇄ ' + esc(x.seller.name) : (o.online ? '● ' : '') + esc(o.name)} <span id="tp"></span></div></div>${act}<button class="pb out sm" data-rep="chat" aria-label="${t('rep')}">⚑</button></div>
<div class="note" style="margin:6px 12px 0">${t('warn')}${x.hold && !x.hold.released ? ' · ' + t('rel', when(x.hold.rel)) : ''}</div><div class="ms" id="ms"></div>
<form class="cf" id="cf"><label class="pb out" style="cursor:pointer;padding:9px 12px;margin:0" title="${t('attach')}">📎<input type="file" id="cfi" accept="image/*" hidden></label><input id="ci" placeholder="${t('ph')}" autocomplete="off" aria-label="${t('ph')}" maxlength="1000"><button class="pb">${t('send')}</button></form>`;
    const ci = $('#ci'); ci.value = ov; if (foc) ci.focus();
    ci.oninput = () => { if (Date.now() - lastTyp > 2000) { lastTyp = Date.now(); api('POST', '/api/threads/' + x.id + '/typing', {}).catch(() => { }); } };
    $('#cf').onsubmit = safe(async e => { e.preventDefault(); const v = ci.value.trim(); if (!v) return; await api('POST', '/api/threads/' + x.id + '/msg', { text: v }); ci.value = ''; await loadTh(); });
    $('#cfi').onchange = safe(async e => { const f = e.target.files[0]; if (!f) return; const url = await upload(f, 900); e.target.value = ''; await api('POST', '/api/threads/' + x.id + '/msg', { img: url }); await loadTh(); });
  }
  const sig = r.msgs.map(m => m.id + (m.offer ? m.offer.st : '')).join(',') + '|' + x.otherRead + '|' + lang;
  if (sig !== msSig) { msSig = sig; const ms = $('#ms'), bottom = ms.scrollHeight - ms.scrollTop - ms.clientHeight < 80 || !ms.dataset.init; ms.innerHTML = msgsHtml(r); ms.dataset.init = 1; if (bottom) ms.scrollTop = ms.scrollHeight; }
  const tp = $('#tp'); if (tp) tp.textContent = x.typing ? t('typing') : '';
  if (S.autoPay === x.id && x.role === 'buyer' && x.status === 'chat') { S.autoPay = 0; payDlg(); }
}

// ---------- payment / deal dialogs ----------
const PMS = (bal, price) => { const c = S.cfg.pay, ms = [['balance', t('pay_balance'), fmt(bal), bal < price]]; if (c.apc) ms.push(['apc', t('pm_apc'), t('fee_0'), 0]); if (c.payme) ms.push(['payme', 'Payme', '', 0]); if (c.click) ms.push(['click', 'Click', '', 0]); return ms; };
const pmRow = ([k, l, sub, dis], sel) => `<button type="button" class="pm" data-m="${k}" ${dis ? 'disabled' : ''} aria-pressed="${k === sel}"><span class="lg ${k === 'balance' ? 'bal' : k}">${k === 'balance' ? '🪙' : k === 'apc' ? 'AUTO' : k.toUpperCase().slice(0, 5)}</span><div><b>${esc(l)}</b><div class="mu">${esc(sub)}</div></div><span class="rd"></span></button>`;
function payDlg() {
  const x = S.th.thread, c = S.cfg.pay, ms = PMS(x.bal || 0, x.price);
  S.pm = (ms.find(m => !m[3]) || ms[0])[0];
  dlg(`<h2 id="dt" style="margin:0">${t('pay')}</h2><div class="big-p">${fmt(x.price)}</div><p class="mu" style="margin:6px 0">${t('pay_via')}</p>
<div id="pml">${ms.map(m => pmRow(m, S.pm)).join('')}</div>${c.payme || c.click ? `<p class="note">${t('pay_card_note')}</p>` : ''}
<div class="err" id="pe"></div><div class="rw"><button class="pb" id="go" style="flex:1">${t('p_go')}</button><button class="pb out" id="close">${t('cancel')}</button></div>`);
  bindPm(ms);
  $('#go').onclick = async () => {
    $('#go').disabled = true;
    try {
      if (S.pm === 'apc') { apcDlg(await api('POST', '/api/apay', { tid: x.id }), () => { poll(); loadTh(); }); return; }
      const r = await api('POST', '/api/threads/' + x.id + '/pay', { provider: S.pm });
      if (r.paid) { closeDlg(); await poll(); await loadTh(); } else if (r.url) { toast(t('pay_wait')); location.href = r.url; }
    } catch (e) { $('#pe').textContent = errText(e); $('#go').disabled = false; }
  };
}
function bindPm(ms) { $('#pml').onclick = e => { const b = e.target.closest('[data-m]'); if (b && !b.disabled) { S.pm = b.dataset.m; $('#pml').innerHTML = ms.map(m => pmRow(m, S.pm)).join(''); } }; }
const confirmDlg = (msg, yes, fn) => { dlg(`<h2 id="dt" style="margin:0 0 8px">${esc(yes)}</h2><p>${esc(msg)}</p><div class="rw"><button class="pb" id="cy">${esc(yes)}</button><button class="pb out" id="close">${t('cancel')}</button></div>`); $('#cy').onclick = safe(async () => { await fn(); closeDlg(); }); };
function reviewDlg(tid) {
  dlg(`<h2 id="dt" style="margin:0 0 8px">${t('r_t')}</h2><label for="rs">${t('r_s')}</label><select id="rs">${[5, 4, 3, 2, 1].map(n => `<option value="${n}">${'★'.repeat(n)}</option>`).join('')}</select><label for="rt">${t('r_c')}</label><textarea id="rt" rows="3" maxlength="200"></textarea><div class="err" id="re"></div><div class="rw"><button class="pb" id="rsv">${t('r_go')}</button><button class="pb out" id="close">${t('later')}</button></div>`);
  $('#rsv').onclick = async () => { try { await api('POST', '/api/threads/' + tid + '/review', { stars: +$('#rs').value, text: $('#rt').value }); closeDlg(); toast(t('rev_ok')); await loadTh(); } catch (e) { $('#re').textContent = errText(e); } };
}
function offerDlg() {
  const x = S.th.thread; dlg(`<h2 id="dt" style="margin:0 0 8px">${t('offer')}</h2><p class="mu">${fmt(x.price)}</p><label for="oa">${t('offer_amt')}</label><input id="oa" type="number" min="1000" step="1000"><div class="err" id="oe"></div><div class="rw"><button class="pb" id="ogo">${t('offer_send')}</button><button class="pb out" id="close">${t('cancel')}</button></div>`);
  $('#ogo').onclick = async () => { const am = +$('#oa').value; if (!(am >= 1000 && am < x.price)) { $('#oe').textContent = t('e_off'); return; } try { await api('POST', '/api/threads/' + x.id + '/offer', { amt: am }); closeDlg(); await loadTh(); } catch (e) { $('#oe').textContent = errText(e); } };
}
function disputeDlg() {
  const x = S.th.thread; dlg(`<h2 id="dt" style="margin:0 0 8px">${t('disp')}</h2><label for="dr">${t('sp_msg')}</label><textarea id="dr" rows="3" maxlength="500"></textarea><div class="rw"><button class="pb red" id="dgo">${t('disp')}</button><button class="pb out" id="close">${t('cancel')}</button></div>`);
  $('#dgo').onclick = safe(async () => { await api('POST', '/api/threads/' + x.id + '/dispute', { text: $('#dr').value }); closeDlg(); await poll(); await loadTh(); });
}
function reportDlg(kind) {
  const x = S.th && S.th.thread, ref = kind === 'chat' && x ? 'thread:' + x.id : 'item:' + S.arg;
  dlg(`<h2 id="dt" style="margin:0 0 8px">${t('rep')}</h2><label for="rr">${t('rep_why')}</label><select id="rr">${['rep_a', 'rep_b', 'rep_c', 'rep_d'].map(k => `<option value="${k}">${t(k)}</option>`).join('')}</select><label for="rc">${t('r_c')}</label><textarea id="rc" rows="3" maxlength="400"></textarea><div class="err" id="re"></div><div class="rw"><button class="pb" id="rgo">${t('rep_go')}</button><button class="pb out" id="close">${t('cancel')}</button></div>`);
  $('#rgo').onclick = async () => { try { await api('POST', '/api/tickets', { subject: 'sp_r', ref, text: t($('#rr').value) + ': ' + ($('#rc').value.trim() || '—') }); closeDlg(); toast(t('rep_sent')); } catch (e) { $('#re').textContent = errText(e); } };
}
const terms = () => dlg(`<h2 id="dt" style="margin:0 0 8px">${t('tm_t')}</h2><p>${t('tm_b')}</p><div class="rw"><button class="pb" id="close">${t('close')}</button></div>`);

// ---------- wallet (real top-up) / history ----------
const DST = { pending: 'dp_pending', review: 'dp_review', approved: 'dp_approved', rejected: 'dp_rejected', cancelled: 'dp_cancelled' }, KINDN = { humo: 'Humo', uzcard: 'Uzcard', visa: 'Visa', mastercard: 'Mastercard', other: '' };
async function copyTxt(v) { try { await navigator.clipboard.writeText(v); toast(t('copied')); } catch (e) { toast(v); } }
function depDlg(d) {
  const k = d.card || {};
  dlg(`<h2 id="dt" style="margin:0 0 6px">${t('dp_t')}</h2><p class="note" style="margin:0 0 8px">${t('dp_step', fmt(d.amt))}</p>
<div class="ccard"><div class="mu">${esc(KINDN[k.kind] || '')} ${esc(k.bank || '')}</div><div class="cnum">${esc(card4(k.num || ''))}</div><div>${esc(k.holder || '')}</div><button type="button" class="pb out sm" id="ccp" style="margin-top:8px">📋 ${t('copy')}</button></div>
<div class="kv"><span>${t('dp_send')}</span><b>${fmt(d.amt)}</b></div>
<label for="rf">${t('dp_rc')}</label><input id="rf" type="file" accept="image/*"><div class="pics" id="rpv"></div><div class="err" id="re"></div>
<div class="rw"><button class="pb" id="rgo">${t('dp_send_rc')}</button><button class="pb out" id="close">${t('later')}</button></div>`);
  $('#ccp').onclick = () => copyTxt(String(k.num || ''));
  let img = null; $('#rf').onchange = safe(async e => { const f = e.target.files[0]; if (!f) return; img = await upload(f, 1300); $('#rpv').innerHTML = `<span class="pi"><img src="${esc(img)}" alt=""></span>`; });
  $('#rgo').onclick = async () => { $('#re').textContent = ''; if (!img) { $('#re').textContent = t('dp_need_rc'); return; } $('#rgo').disabled = true; try { await api('POST', '/api/deposits/' + d.id + '/receipt', { img }); closeDlg(); toast(t('dp_ok')); poll(); if (S.view === 'wallet') wallet(); } catch (e) { $('#re').textContent = errText(e); $('#rgo').disabled = false; } };
}
function apcDlg(p, after) {
  if (!after && p.tid) after = () => { poll(); S.view === 'chat' && S.sel === p.tid ? loadTh() : (location.hash = '#chat-' + p.tid); };
  const k = p.card || {}, off = Date.now() - (p.now || Date.now()); let n = 0, done = false, exp = p.exp;
  dlg(`<h2 id="dt" style="margin:0 0 6px">${t('apc_t')}</h2><p class="note" style="margin:0 0 8px">${t('apc_step')}</p>
<div class="ccard"><div class="mu">${esc(KINDN[k.kind] || '')} ${esc(k.bank || '')}</div><div class="cnum">${esc(card4(k.num || ''))}</div><div>${esc(k.holder || '')}</div><button type="button" class="pb out sm" id="ccp" style="margin-top:8px">📋 ${t('copy')}</button></div>
<div class="kv"><span>${t('apc_exact')}</span><b>${fmt(p.amt)}</b></div><button type="button" class="pb out sm" id="cap" style="margin:8px 0">📋 ${t('copy')}: ${num(p.amt)}</button>
<div class="apst" id="aps" role="status" style="font-weight:800;margin:6px 0"></div><div class="note">${t('apc_warn')}</div>
<div class="rw"><button class="pb out" id="acn">${t('dp_cancel')}</button><button class="pb out" id="close">${t('later')}</button></div>`);
  $('#ccp').onclick = () => copyTxt(String(k.num || '')); $('#cap').onclick = () => copyTxt(String(p.amt));
  $('#acn').onclick = async () => { done = true; clearInterval(iv); try { await api('POST', '/api/apay/' + p.id + '/cancel'); } catch (e) { } closeDlg(); if (S.view === 'wallet') wallet(); };
  const tick = async () => {
    if (!$('#aps') || done) { clearInterval(iv); return; }
    if (n++ % 3 === 0) {
      let x; try { x = await api('GET', '/api/apay/' + p.id); } catch (e) { x = null; }
      if (!$('#aps')) { clearInterval(iv); return; }
      if (x && x.status !== 'waiting') {
        done = true; clearInterval(iv);
        if (x.status === 'paid') { $('#aps').textContent = '✅ ' + t('apc_ok', fmt(x.amt)); toast(t('topup_ok')); poll(); setTimeout(() => { if ($('#aps')) closeDlg(); if (S.view === 'wallet') wallet(); if (after) after(); }, 1800); }
        else $('#aps').textContent = x.status === 'expired' ? '⌛ ' + t('apc_exp') : x.status === 'manual' ? '🔎 ' + t('apc_manual') : '✕ ' + t('apc_s_' + x.status);
        return;
      }
      if (x) exp = x.exp;
    }
    const left = Math.max(0, Math.round((exp - (Date.now() - off)) / 1000));
    $('#aps').textContent = left > 0 ? '⏳ ' + t('apc_wait') + ' ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0') : '🔎 ' + t('apc_check');
  };
  const iv = setInterval(tick, 1000); tick();
}
async function pickCardDlg(amt) {
  const r = await api('GET', '/api/cards'); if (!r.items.length) { toast(t('dp_no_cards')); return; } let sel = r.items[0].id;
  const paint = () => { $('#cl').innerHTML = r.items.map(k => `<button type="button" class="pm" data-k="${k.id}" aria-pressed="${k.id === sel}"><span class="lg">${esc((KINDN[k.kind] || 'CARD').slice(0, 5).toUpperCase())}</span><div><b>${esc(k.bank)}</b><div class="mu">${esc(card4(k.num))}</div></div><span class="rd"></span></button>`).join(''); };
  dlg(`<h2 id="dt" style="margin:0 0 8px">${t('pick_card')}</h2><div id="cl"></div><div class="kv"><span>${t('dp_send')}</span><b>${fmt(amt)}</b></div><div class="err" id="ke"></div><div class="rw"><button class="pb" id="kgo">${t('cont')}</button><button class="pb out" id="close">${t('later')}</button></div>`); paint();
  $('#cl').onclick = e => { const b = e.target.closest('[data-k]'); if (b) { sel = +b.dataset.k; paint(); } };
  $('#kgo').onclick = async () => { $('#kgo').disabled = true; try { const x = await api('POST', '/api/deposits', { amt, card: sel }); depDlg({ id: x.id, amt, card: r.items.find(k => k.id === sel) }); if (S.view === 'wallet') wallet(); } catch (e) { $('#ke').textContent = errText(e); $('#kgo').disabled = false; } };
}
async function wallet() {
  const r = await api('GET', '/api/wallet'); if (S.view !== 'wallet') return; S.me.bal = r.bal; const c = S.cfg.pay, fee = S.cfg.topupFee, min = S.cfg.minTopup;
  const ms = []; if (c.apc) ms.push(['apc', t('pm_apc'), t('fee_0'), 0]); if (S.cfg.manual) ms.push(['card', t('pm_card'), t('fee_0'), 0]); if (c.payme) ms.push(['payme', 'Payme', fee ? t('fee_n', fee) : t('fee_0'), 0]); if (c.click) ms.push(['click', 'Click', fee ? t('fee_n', fee) : t('fee_0'), 0]); 
  S.pm = ms.length ? ms[0][0] : '';
  $('#app').innerHTML = `<div class="balcard"><div class="mu">${t('cur_bal')}</div><b id="balv">${fmt(r.bal)}</b></div>
${r.apc ? `<div class="card" style="margin:0 0 10px"><b>⏳ ${t('apc_open')}: ${fmt(r.apc.amt)}</b><div class="rw" style="margin-top:8px"><button class="pb sm" data-apo="1">${t('apc_cont')}</button></div></div>` : ''}<h2 style="margin-top:6px">${t('pick_pm')}</h2><div id="pml">${ms.length ? ms.map(m => pmRow(m, S.pm)).join('') : `<div class="note">${t('pm_none')}</div>`}</div>
<label for="ta">${t('amt_l', num(min))}</label><input id="ta" type="number" inputmode="numeric" min="${min}" step="1000"><div class="quick">${t('amt_q').map(v => `<button type="button" data-q="${v.replace(/\s/g, '')}">${v}</button>`).join('')}</div>
<div class="mu" id="tot"></div><div class="err" id="te"></div><button class="pb blk" id="tgo" ${ms.length ? '' : 'disabled'}>${t('topup_go')} 💳</button><div class="secure"><span style="font-size:26px">🛡</span><span>${t('secure')}</span></div>
${r.deps.length ? `<h2>${t('dp_list')}</h2>` + r.deps.slice(0, 8).map(d => `<div class="tx ${d.status === 'approved' ? 'in' : ''}"><span class="ti2">${d.status === 'approved' ? '✓' : d.status === 'rejected' ? '✕' : '⏳'}</span><div class="mid"><b>${fmt(d.amt)}</b><div class="mu">${when(d.ts)}${d.reason ? ' · ' + esc(t('dp_reason', d.reason)) : ''}</div>${d.status === 'pending' ? `<div style="margin-top:6px"><button class="pb sm" data-dpr="${d.id}">${t('dp_sendnow')}</button> <button class="pb out sm" data-dpc="${d.id}">${t('dp_cancel')}</button></div>` : d.status === 'review' ? `<div style="margin-top:6px"><button class="pb out sm" data-dpc="${d.id}">${t('dp_cancel')}</button></div>` : ''}</div><span class="tag ${d.status === 'approved' ? 'g' : d.status === 'rejected' ? 'r' : 'y'}">${t(DST[d.status])}</span></div>`).join('') : ''}
${r.apays && r.apays.length ? `<h2>${t('apc_list')}</h2>` + r.apays.map(d => `<div class="tx ${d.status === 'paid' ? 'in' : ''}"><span class="ti2">${d.status === 'paid' ? '✓' : d.status === 'waiting' || d.status === 'manual' ? '⏳' : '✕'}</span><div class="mid"><b>${fmt(d.amt)}</b><div class="mu">${when(d.ts)}</div></div><span class="tag ${d.status === 'paid' ? 'g' : d.status === 'waiting' || d.status === 'manual' ? 'y' : 'r'}">${t('apc_s_' + d.status)}</span></div>`).join('') : ''}
<div class="rw" style="margin-top:22px"><h2 style="margin:0">${t('hist_t')}</h2><button class="pb out sm" data-go="history">${t('all')} →</button></div>${r.tx.slice(0, 3).map(txRow).join('') || `<div class="mu">${t('no_tx')}</div>`}
${r.holds.length ? `<h2>${t('wd_pend')}</h2>` + r.holds.map(h => `<div class="tx"><div class="mid"><b>${esc(h.note)}</b><div class="mu">${h.frozen ? t('st_dispute') : t('rel', when(h.rel))}</div></div><span class="amt">${fmt(h.amt)}</span></div>`).join('') : ''}
<h2>${t('wd')}</h2><div class="card" style="margin-top:0"><div class="kv" style="padding-top:0"><span>${t('wd_avail', '')}</span><b>${fmt(r.avail)}</b></div>${r.locked ? `<div class="mu">${t('wd_locked', r.lockDays, fmt(r.locked))}</div>` : ''}<label for="wa">${t('wd_amt')}</label><input id="wa" type="number" min="${S.cfg.minWithdraw}" max="${r.avail}"><label for="wc">${t('card')}</label><input id="wc" inputmode="numeric" maxlength="19" placeholder="8600 0000 0000 0000" autocomplete="off"><label for="wh">${t('wd_holder')}</label><input id="wh" maxlength="60" autocomplete="off"><div class="mu" id="wcalc"></div><div class="err" id="we"></div><button class="pb blk" id="wgo"${r.avail >= S.cfg.minWithdraw ? '' : ' disabled'}>${t('wd')}</button><p class="note">${t('bal_n')}</p></div>
${r.wds.length ? `<h2>${t('wd_list')}</h2>` + r.wds.map(w => `<div class="tx out"><span class="ti2">↗</span><div class="mid"><b>•••• ${esc(w.l4)}</b><div class="mu">${when(w.ts)}${w.note ? ' · ' + esc(w.note) : ''}</div>${w.fee ? `<div class="mu">${t('wd_fee_l', r.wdFee, fmt(w.fee))} · ${t('wd_net', fmt(w.net))}</div>` : ''}</div><div><div class="amt">${fmt(w.amt)}</div><span class="tag ${w.status === 'paid' ? 'g' : w.status === 'rejected' ? 'r' : ''}">${t('wd_' + w.status)}</span></div></div>`).join('') : ''}`;
  const upd = () => { const a = +$('#ta').value || 0, f = ['card', 'apc'].includes(S.pm) ? 0 : Math.round(a * fee / 100); $('#tot').textContent = a ? t('pay_total', fmt(a + f)) : ''; };
  $('#ta').oninput = upd; if (ms.length) { bindPm(ms); $('#pml').addEventListener('click', upd); }
  $('#app').onclick = safe(async e => {
    const q = e.target.closest('[data-q]'); if (q) { $('#ta').value = q.dataset.q; upd(); return; }
    if (e.target.closest('[data-apo]')) { apcDlg(r.apc); return; }
    const dr = e.target.closest('[data-dpr]'); if (dr) { const d = r.deps.find(x => x.id === +dr.dataset.dpr); if (d) depDlg(d); return; }
    const dc = e.target.closest('[data-dpc]'); if (dc) { await api('POST', '/api/deposits/' + dc.dataset.dpc + '/cancel'); wallet(); return; }
  });
  $('#tgo').onclick = async () => {
    const a = +$('#ta').value; $('#te').textContent = ''; if (!(a >= min)) { $('#te').textContent = t('amt_l', num(min)); return; }
    if (S.pm === 'apc') { $('#tgo').disabled = true; try { apcDlg(await api('POST', '/api/apay', { amt: a })); wallet(); } catch (er) { $('#te').textContent = errText(er); } $('#tgo').disabled = false; return; }
    if (S.pm === 'card') { try { await pickCardDlg(a); } catch (er) { $('#te').textContent = errText(er); } return; }
    $('#tgo').disabled = true;
    try { const x = await api('POST', '/api/topup', { provider: S.pm, amt: a }); if (x.url) { toast(t('pay_wait')); location.href = x.url; } }
    catch (er) { $('#te').textContent = errText(er); } $('#tgo').disabled = false;
  };
  $('#wc').oninput = e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
  $('#wa').oninput = () => { const a = +$('#wa').value || 0, f = Math.round(a * r.wdFee / 100); $('#wcalc').textContent = a ? t('wd_fee_l', r.wdFee, fmt(f)) + ' · ' + t('wd_net', fmt(a - f)) : ''; };
  $('#wgo').onclick = async () => { $('#we').textContent = ''; try { await api('POST', '/api/withdraw', { amt: +$('#wa').value, card: $('#wc').value, holder: $('#wh').value }); toast(t('wd_ok')); poll(); wallet(); } catch (e) { $('#we').textContent = errText(e); } };
}
const txRow = x => `<div class="tx ${x.amt > 0 ? 'in' : 'out'}"><span class="ti2">${x.amt > 0 ? '✓' : '↗'}</span><div class="mid"><b>${t('tx_' + x.type)}</b><div class="mu">${esc(x.note || '')}${x.note ? ' · ' : ''}${when(x.ts)}</div></div><span class="amt">${x.amt > 0 ? '+' : '−'}${fmt(Math.abs(x.amt))}</span></div>`;
async function historyView() {
  const r = await api('GET', '/api/wallet'); if (S.view !== 'history') return; const tab = S.histTab, list = r.tx.filter(x => tab === 'all' || (tab === 'in' ? x.amt > 0 : x.amt < 0));
  $('#app').innerHTML = `<div class="chips">${[['all', t('all')], ['in', t('f_in')], ['out', t('f_out')]].map(([k, l]) => `<button class="chip" data-ht="${k}" aria-pressed="${tab === k}">${l}</button>`).join('')}</div>${list.length ? list.map(txRow).join('') : `<div class="empty">${t('no_tx')}</div>`}`;
}

// ---------- notifications / verified badge ----------
const nIco = k => /^n_(credit|dep_ok|apc_ok|adm_add|sale|res_win)/.test(k) ? '💰' : /^n_(dep_no|apc_no|apc_exp|apc_manu|apc_err|wd_rej|lst_no|vf_no|res_lose|disp|dispute|adm_sub|vf_exp|vf_off)/.test(k) ? '⚠️' : /^n_vf/.test(k) ? '✔' : /^n_wd/.test(k) ? '💸' : /^n_dep/.test(k) ? '🧾' : '🔔';
const nText = n => t(n.k, ...n.a.map(v => typeof v === 'number' ? (v > 1e11 ? when(v) : fmt(v)) : v));
const nGo = k => /^n_(credit|dep|apc|wd|adm|refund)/.test(k) ? 'wallet' : /^n_vf/.test(k) ? 'verify' : /^n_(neworder|paid|done|sale|res|disp)/.test(k) ? 'orders' : /^n_lst/.test(k) ? 'mylistings' : '';
async function notifs() {
  const r = await api('GET', '/api/notifs'); if (S.view !== 'notifs') return;
  $('#app').innerHTML = (r.unread ? `<div class="rw"><span class="mu">${r.unread}</span><button class="pb out sm" id="nrd">${t('mark_read')}</button></div>` : '') + (r.items.length ? r.items.map(n => `<div class="nt ${n.rd ? '' : 'new'}" ${nGo(n.k) ? `data-go="${nGo(n.k)}"` : ''}><span class="ni">${nIco(n.k)}</span><div class="mid">${esc(nText(n))}<div class="mu">${when(n.ts)}</div></div></div>`).join('') : `<div class="empty">${t('no_notif')}</div>`);
  if (r.unread) { await api('POST', '/api/notifs/read'); S.nu = 0; bar(); const b = $('#nrd'); if (b) b.remove(); }
}
async function verify() {
  const v = await api('GET', '/api/verify'); if (S.view !== 'verify') return; const st = v.st, enough = v.bal >= v.price, inst = v.mode === 'instant', canPay = st === 'approved' || (inst && ['none', 'rejected', 'pending'].includes(st));
  const lab = { none: 'vf_none', pending: 'vf_pending', rejected: 'vf_rejected', approved: 'vf_approved', active: 'vf_active', expired: 'vf_expired' }[st];
  const pay = (txt) => `<div class="mu">${t('vf_bal', fmt(v.bal))}</div>${enough ? `<button class="pb blk" id="vpay">${txt}</button>` : `<div class="err">${t('vf_need')}</div><button class="pb blk" data-go="wallet">${t('vf_topup')}</button>`}`;
  $('#app').innerHTML = `<div class="pf"><h1>${esc(S.me.name)}${st === 'active' ? VB : ''}</h1><span class="tag ${st === 'active' ? 'g' : st === 'rejected' || st === 'expired' ? 'r' : 'y'}">${t(lab)}</span></div><p class="note">${t('vf_d')}</p>
<div class="card"><div class="kv"><span>${t('vf_price', fmt(v.price), v.days)}</span></div>${st === 'active' || st === 'expired' ? `<div class="kv"><span>${t('vf_until', when(v.until))}</span></div>` : ''}
${!inst && (st === 'none' || st === 'rejected') ? (st === 'rejected' && v.note ? `<div class="err">${esc(t('vf_rej', v.note))}</div>` : '') + `<textarea id="vn" rows="2" maxlength="300" placeholder="${t('vf_note_ph')}"></textarea><button class="pb blk" id="vreq">${t('vf_req')}</button>` : ''}
${canPay ? pay(t('vf_pay') + ' · ' + fmt(v.price)) : ''}${st === 'active' || st === 'expired' ? pay(t('vf_renew') + ' · ' + fmt(v.price)) : ''}
${st === 'active' || st === 'expired' ? `<div class="kv"><span>${t('vf_auto')}</span><button class="chip" id="vauto" aria-pressed="${v.auto}">${v.auto ? 'ON' : 'OFF'}</button></div>${v.renew === 'auto' ? '' : `<p class="note">${t('vf_auto_off')}</p>`}` : ''}</div>`;
  const rq = $('#vreq'); if (rq) rq.onclick = safe(async () => { await api('POST', '/api/verify/request', { note: $('#vn').value }); toast(t('vf_sent')); verify(); });
  const pb = $('#vpay'); if (pb) pb.onclick = safe(async () => { await api('POST', '/api/verify/pay'); S.me.vf = true; toast(t('vf_done')); poll(); verify(); });
  const au = $('#vauto'); if (au) au.onclick = safe(async () => { await api('POST', '/api/verify/auto', { on: !v.auto }); verify(); });
}

// ---------- profile / panel / settings / support ----------
async function profile() {
  const r = await api('GET', '/api/seller/stats'); if (S.view !== 'profile' || !S.me) return; const me = S.me; me.bal = r.bal;
  const row = (go, ico, lab, extra = '') => `<button data-go="${go}"><span class="mi">${ico}</span><span>${lab}</span>${extra}<span class="ch">›</span></button>`;
  $('#app').innerHTML = `<div class="pf">${avatar({ name: me.name, online: true }, 'big')}<h1>${esc(me.name)}${me.vf || me.role === 'admin' ? VB : ''}</h1><div class="mu">@${esc(me.name.toLowerCase())} · ID #${me.id}</div></div>
<div class="card s3"><div><b>${r.active}</b><span class="mu">${t('pf_ads')}</span></div><div><b>${r.buys}</b><span class="mu">${t('pf_ord')}</span></div><div><b>${num(r.bal)}</b><span class="mu">${t('pf_bal')}</span></div></div>
<div class="menu">${row('wallet', '🪙', t('pf_wallet'))}${row('orders', '🛍️', t('ord_t'))}${row('favorites', '♥', t('fav_t'))}${row('mylistings', '📣', t('pf_my'))}${row('verify', '✔', t('vf_t'), `<span class="tag ${me.vf ? 'g' : ''}">${me.vf ? t('vf_active') : t('vf_none')}</span>`)}${row('notifs', '🔔', t('notif_t'), S.nu ? `<span class="cnt" style="position:static">${S.nu}</span>` : '')}${row('panel', '👑', t('pf_panel'))}${row('history', '🧾', t('hist_t'))}${row('settings', '⚙️', t('pf_set'))}${row('support', '❓', t('pf_help'))}${me.role === 'admin' ? `<a href="/admin"><span class="mi">🛠</span><span>${t('adm')}</span><span class="ch">›</span></a>` : ''}<button id="lo"><span class="mi">⎋</span><span>${t('logout')}</span></button></div>`;
}
async function panel() {
  const r = await api('GET', '/api/seller/stats'); if (S.view !== 'panel') return;
  $('#app').innerHTML = `<div class="balcard"><div class="crown">👑</div><div class="mu">${t('pn_bal')}</div><b>${fmt(r.bal)}</b><button class="pb yel sm" style="margin-top:10px" data-go="wallet">${t('pn_wd')}</button></div>
<h2>${t('pn_30')}</h2><div class="stats"><div><b>${r.sales}</b><span class="mu">${t('pn_sales')}</span></div><div><b>${num(r.turnover)}</b><span class="mu">${t('pn_turn')}</span></div><div><b>${r.rating ? r.rating.toFixed(1) : '—'}</b><span class="mu">${t('pn_rate')}</span></div></div>
<div class="rw"><span class="mu">${t('pn_hold')}</span><b>${fmt(r.pending)}</b></div><h2>${t('pn_recent')}</h2>${r.recent.length ? r.recent.map(x => `<div class="tx in"><span class="ti2">✓</span><div class="mid"><b>${esc(x.title)}</b><div class="mu">${when(x.upd)}</div></div><button class="pb sm out" data-go="chat-${x.id}">${t('view')}</button><span class="amt">${fmt(x.price)}</span></div>`).join('') : `<div class="mu">${t('pn_none')}</div>`}`;
}
function settings() {
  const th = document.documentElement.dataset.theme || 'dark';
  $('#app').innerHTML = `<div class="card"><div class="kv"><span>${t('set_lang')}</span><div class="chips" style="padding:0">${['uz', 'ru', 'en'].map(l => `<button class="chip" data-sl="${l}" aria-pressed="${l === lang}">${l.toUpperCase()}</button>`).join('')}</div></div>
<div class="kv"><span>${t('set_theme')}</span><div class="chips" style="padding:0"><button class="chip" data-th="dark" aria-pressed="${th !== 'light'}">${t('dark')}</button><button class="chip" data-th="light" aria-pressed="${th === 'light'}">${t('light')}</button></div></div>
<div class="kv"><span>${t('set_fee')}</span><b>${S.cfg.fee}%</b></div><div class="kv"><span>${t('set_hold')}</span><b>${t('set_days', S.cfg.holdDays)}</b></div><div class="kv" style="border:0"><button class="pb out sm" id="trm">${t('tm_t')}</button>${S.me ? `<button class="pb red sm" id="lo">⎋ ${t('logout')} (${esc(S.me.name)})</button>` : ''}</div></div>`;
}
async function support() {
  const r = await api('GET', '/api/tickets'); if (S.view !== 'support') return; const adm = S.me.role === 'admin';
  $('#app').innerHTML = `<div class="help"><div class="big">🎧</div><h1>${t('help_t')}</h1><p class="mu">${t('help_d')}</p></div><details class="faq"><summary><b>${t('faq_t')}</b></summary>${[1, 2, 3].map(i => `<p><b>${t('q' + i)}</b><br>${t('a' + i)}</p>`).join('')}</details>
<div class="card"><h2 style="margin:0">${t('sp_new')}</h2><label for="ss">${t('sp_subj')}</label><select id="ss">${['sp_a', 'sp_b', 'sp_c', 'sp_d'].map(k => `<option value="${k}">${t(k)}</option>`).join('')}</select><label for="sm">${t('sp_msg')}</label><textarea id="sm" rows="4" maxlength="600"></textarea><div class="err" id="se"></div><button class="pb blk" id="sgo">${t('help_go')}</button></div>
<h2>${adm ? t('sp_all') : t('sp_my')}</h2>${r.items.length ? r.items.map(x => `<details class="tkt"${opened === x.id ? ' open' : ''}><summary><b>#${x.id} ${t(x.subject)}</b> ${adm ? esc(x.user) : ''} <span class="tag ${x.status === 'open' ? 'y' : ''}">${t(x.status === 'open' ? 'sp_open' : 'sp_closed')}</span></summary>${x.msgs.map(m => `<div class="rv"><b>${esc(m.from)}${m.role === 'admin' ? ' ★' : ''}</b> <span class="mu">${when(m.ts)}</span><br>${esc(m.text)}</div>`).join('')}${x.status === 'open' ? `<textarea id="tr-${x.id}" rows="2" maxlength="600" placeholder="${t('sp_rep')}"></textarea><div class="rw"><button class="pb sm" data-ts="${x.id}">${t('sp_rep')}</button><button class="pb out sm" data-tc="${x.id}">${t('sp_cl')}</button></div>` : ''}</details>`).join('') : `<div class="mu">${t('sp_none')}</div>`}`;
  $('#sgo').onclick = async () => { const m = $('#sm').value.trim(); if (m.length < 5) { $('#se').textContent = t('e_msg'); return; } try { await api('POST', '/api/tickets', { subject: $('#ss').value, text: m }); support(); } catch (e) { $('#se').textContent = errText(e); } };
}
let opened = 0;

// ---------- events ----------
document.addEventListener('click', safe(async e => {
  const g = s => e.target.closest(s); let b;
  if (b = g('[data-sl]')) { setLang(b.dataset.sl); if (!$('#splash').classList.contains('hide')) splash(); return; }
  if (b = g('[data-th]')) { document.documentElement.dataset.theme = b.dataset.th; try { localStorage.setItem('bb_theme', b.dataset.th); } catch (x) { } settings(); return; }
  if (b = g('[data-cat]')) { go('market-' + b.dataset.cat); return; }
  if (b = g('[data-am]')) { authDlg(b.dataset.am); return; }
  if (g('[data-terms]')) { e.preventDefault(); terms(); return; }
  if (g('#lo')) { await api('POST', '/api/logout', {}); S.me = null; S.threads = []; S.unread = 0; go('home'); route(); return; }
  if (b = g('[data-gal]')) { const r = await api('GET', '/api/listings/' + b.dataset.gal); dlg(`<h2 id="dt" style="margin:0 0 8px">${esc(r.item.title)}</h2>${r.item.imgs.map(p => `<img class="zi" src="${esc(p)}" style="width:100%;border-radius:12px;margin-bottom:8px" alt="">`).join('') || `<div class="gal">${catIco(r.item.cat, 90)}</div>`}<div class="rw"><button class="pb" id="close">${t('close')}</button></div>`); return; }
  if (b = g('[data-rp]')) { pics.splice(+b.dataset.rp, 1); pv(); return; }
  if (g('.zi') && e.target.tagName === 'IMG' && !g('#dlg')) { dlg(`<img src="${esc(e.target.src)}" style="width:100%;border-radius:12px" alt=""><div class="rw"><button class="pb" id="close">${t('close')}</button></div>`); return; }
  if (b = g('[data-open]')) { go('item-' + b.dataset.open); return; }
  if (b = g('[data-buy]')) { if (!needAuth(() => b.click())) return; const r = await api('POST', '/api/threads', { lid: +b.dataset.buy }); S.autoPay = r.id; go('chat-' + r.id); return; }
  if (b = g('[data-chat]')) { if (!needAuth(() => b.click())) return; const r = await api('POST', '/api/threads', { lid: +b.dataset.chat }); go('chat-' + r.id); return; }
  if (b = g('[data-t]')) { go('chat-' + b.dataset.t); return; }
  if (g('[data-pay]')) { payDlg(); return; }
  if (g('[data-done]')) { confirmDlg(t('conf_done'), t('conf_yes'), async () => { await api('POST', '/api/threads/' + S.sel + '/confirm', {}); await poll(); await loadTh(); setTimeout(() => S.th && !S.th.thread.reviewed && reviewDlg(S.sel), 200); }); return; }
  if (g('[data-disp]')) { disputeDlg(); return; }
  if (g('[data-deliver]')) { await api('POST', '/api/threads/' + S.sel + '/deliver', {}); await loadTh(); return; }
  if (g('[data-review]')) { reviewDlg(S.sel); return; }
  if (b = g('[data-del]')) { if (!needAuth()) return; await api('DELETE', '/api/listings/' + b.dataset.del); S.view === 'item' ? go('market') : route(); return; }
  if (b = g('[data-go]')) { go(b.dataset.go); return; }
  if (b = g('[data-fav]')) { if (!needAuth()) return; await api('POST', '/api/favs/' + b.dataset.fav, {}); S.view === 'item' ? item() : S.view === 'favorites' ? favorites() : S.view === 'market' ? loadGrid() : S.view === 'home' ? home() : seller(); return; }
  if (g('[data-favclear]')) { await api('DELETE', '/api/favs'); favorites(); return; }
  if (g('[data-share]')) { try { await navigator.clipboard.writeText(location.href); toast(t('copied')); } catch (x) { dlg(`<h2 id="dt">${t('link_t')}</h2><input id="lkx" readonly value="${esc(location.href)}"><div class="rw"><button class="pb" id="close">${t('close')}</button></div>`); $('#lkx').select(); } return; }
  if (b = g('[data-rep]')) { if (needAuth()) reportDlg(b.dataset.rep); return; }
  if (g('[data-offer]')) { offerDlg(); return; }
  if (b = g('[data-oa]')) { const [i, v] = b.dataset.oa.split(':'); await api('POST', '/api/threads/' + S.sel + '/offer/' + i, { accept: v === 'y' }); await loadTh(); return; }
  if (b = g('[data-boost]')) { await api('POST', '/api/listings/' + b.dataset.boost + '/boost', {}); await poll(); toast('🔥'); return; }
  if (b = g('[data-ot]')) { S.ordTab = b.dataset.ot; orders(); return; }
  if (b = g('[data-ht]')) { S.histTab = b.dataset.ht; historyView(); return; }
  if (g('#trm')) { terms(); return; }
  if (g('[data-back]')) { trail.length > 1 ? history.back() : go('home'); return; }
  if (g('[data-sw]')) { $('#big').innerHTML = `<img class="zi" src="${esc(e.target.src)}" alt="">`; return; }
  if (b = g('[data-ts]')) { const id = +b.dataset.ts, v = $('#tr-' + id).value.trim(); if (v) { await api('POST', '/api/tickets/' + id + '/msg', { text: v }); opened = id; support(); } return; }
  if (b = g('[data-tc]')) { await api('POST', '/api/tickets/' + b.dataset.tc + '/close', {}); support(); return; }
  if (e.target.id === 'close') closeDlg();
}));
$('#dlg').addEventListener('click', e => { if (e.target === $('#dlg')) closeDlg(); });

// ---------- boot ----------
async function boot() {
  document.body.insertAdjacentHTML('afterbegin', SPRITE);
  try { const [cfg, me] = await Promise.all([api('GET', '/api/config'), api('GET', '/api/me')]); S.cfg = cfg; S.me = me.me; }
  catch (e) { document.body.innerHTML = '<p style="padding:30px">Server error / Server xatosi</p>'; return; }
  if (S.me) await poll().catch(() => { });
  route();
  let seen = false; try { seen = !!localStorage.getItem('bb_seen'); } catch (e) { }
  if (!seen && !S.me) splash();
  let n = 0;
  setInterval(safe(async () => {
    n++; if (document.hidden || !S.me) return;
    await poll();
    if (['chats', 'chat'].includes(S.view)) { chatList(); await loadTh(); }
    if (S.view === 'market' && n % 5 === 0 && document.activeElement.tagName !== 'INPUT') await loadGrid();
  }), 3000);
  setInterval(() => { if (S.view === 'chat' && S.th && S.th.thread.typing) loadTh(); }, 1500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && S.me) safe(poll)(); });
}
boot();
