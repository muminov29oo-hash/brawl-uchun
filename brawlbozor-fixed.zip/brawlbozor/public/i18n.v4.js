/* AutoPayCard (automatic card top-ups) */
(function () {
  const X = {
    uz: {
      pm_apc: 'Karta (avtomatik)', apc_t: 'Avtomatik toʻlov', apc_step: 'Quyidagi kartaga aynan koʻrsatilgan summani oʻtkazing. Pul tushishi avtomatik aniqlanadi.', apc_exact: 'Aynan shu summani oʻtkazing',
      apc_wait: 'Toʻlov kutilmoqda…', apc_check: 'Tekshirilmoqda…', apc_ok: 'Toʻlov qabul qilindi: {0}', apc_exp: 'Vaqt tugadi, balansga pul qoʻshilmadi. Pul yuborgan boʻlsangiz, admin tekshiradi (Yordam). Yangi toʻlov yarating.',
      apc_manual: 'Toʻlovingiz admin tekshiruvida.', apc_warn: 'Summa soʻmigacha aynan bir xil boʻlishi shart va 5 daqiqa ichida oʻtkazilishi kerak. Boshqa summa yoki kech oʻtkazma avtomatik tasdiqlanmaydi, admin qoʻlda tekshiradi. Balansga oʻtkazgan summangiz qoʻshiladi.',
      apc_open: 'Ochiq toʻlov', apc_cont: 'Davom etish', apc_list: 'Avtomatik toʻlovlar',
      apc_s_waiting: 'Kutilmoqda', apc_s_paid: 'Toʻlandi', apc_s_expired: 'Muddati tugadi', apc_s_manual: 'Tekshiruvda', apc_s_cancelled: 'Bekor qilindi', apc_s_rejected: 'Rad etildi',
      err_apc_down: 'Toʻlov xizmati hozir ishlamayapti. Birozdan keyin urinib koʻring. Balansingizga hech narsa yozilmadi.', err_apc_busy: 'Hozir band. Bir daqiqadan keyin qayta urinib koʻring.', err_apc_open: 'Sizda tugallanmagan avtomatik toʻlov bor. Uni yakunlang yoki bekor qiling.', err_f_gmail: 'Gmail manzili notoʻgʻri',
      n_apc_new: 'Toʻlov yaratildi. 5 daqiqa ichida aynan {0} oʻtkazing.', n_apc_ok: 'Toʻlov tasdiqlandi. Balansingizga {0} qoʻshildi.', n_apc_exp: 'Toʻlov muddati tugadi ({0}). Balansga pul qoʻshilmadi.', n_apc_manu: 'Toʻlovingiz ({0}) avtomatik tasdiqlanmadi. Admin qoʻlda tekshiradi.', n_apc_no: 'Toʻlovingiz rad etildi. Sabab: {0}',
      n_apc_man: 'Qoʻlda tekshirish kerak (AutoPayCard): {0}, {1}', n_apc_err: 'AutoPayCard xatosi: {0}',
    },
    ru: {
      pm_apc: 'Карта (автоматически)', apc_t: 'Автоматический платёж', apc_step: 'Переведите на карту ниже ровно указанную сумму. Поступление определится автоматически.', apc_exact: 'Переведите именно эту сумму',
      apc_wait: 'Ожидаем платёж…', apc_check: 'Проверяем…', apc_ok: 'Платёж принят: {0}', apc_exp: 'Время вышло, деньги на баланс не зачислены. Если вы перевели, администратор проверит (Помощь). Создайте новый платёж.',
      apc_manual: 'Платёж на проверке у администратора.', apc_warn: 'Сумма должна совпадать до сума и быть переведена в течение 5 минут. Другая сумма или опоздание не подтверждаются автоматически, администратор проверит вручную. На баланс зачислится переведённая сумма.',
      apc_open: 'Открытый платёж', apc_cont: 'Продолжить', apc_list: 'Автоматические платежи',
      apc_s_waiting: 'Ожидает', apc_s_paid: 'Оплачен', apc_s_expired: 'Истёк', apc_s_manual: 'На проверке', apc_s_cancelled: 'Отменён', apc_s_rejected: 'Отклонён',
      err_apc_down: 'Платёжный сервис сейчас недоступен. Попробуйте позже. Баланс не изменён.', err_apc_busy: 'Сейчас занято. Повторите через минуту.', err_apc_open: 'У вас есть незавершённый автоплатёж. Завершите или отмените его.', err_f_gmail: 'Неверный адрес Gmail',
      n_apc_new: 'Платёж создан. В течение 5 минут переведите ровно {0}.', n_apc_ok: 'Платёж подтверждён. На баланс зачислено {0}.', n_apc_exp: 'Срок платежа истёк ({0}). Деньги на баланс не зачислены.', n_apc_manu: 'Платёж ({0}) не подтверждён автоматически. Администратор проверит вручную.', n_apc_no: 'Ваш платёж отклонён. Причина: {0}',
      n_apc_man: 'Нужна ручная проверка (AutoPayCard): {0}, {1}', n_apc_err: 'Ошибка AutoPayCard: {0}',
    },
    en: {
      pm_apc: 'Card (automatic)', apc_t: 'Automatic payment', apc_step: 'Transfer exactly the amount shown to the card below. The payment is detected automatically.', apc_exact: 'Transfer exactly this amount',
      apc_wait: 'Waiting for payment…', apc_check: 'Checking…', apc_ok: 'Payment received: {0}', apc_exp: 'Time is up and nothing was added to your balance. If you did send money, an admin will check it (Help). Create a new payment.',
      apc_manual: 'Your payment is being reviewed by an admin.', apc_warn: 'The amount must match to the last som and be sent within 5 minutes. A different amount or a late transfer is not confirmed automatically; an admin will check it by hand. The amount you transferred is added to your balance.',
      apc_open: 'Open payment', apc_cont: 'Continue', apc_list: 'Automatic payments',
      apc_s_waiting: 'Waiting', apc_s_paid: 'Paid', apc_s_expired: 'Expired', apc_s_manual: 'In review', apc_s_cancelled: 'Cancelled', apc_s_rejected: 'Rejected',
      err_apc_down: 'The payment service is unavailable right now. Try again later. Your balance was not changed.', err_apc_busy: 'Busy right now. Try again in a minute.', err_apc_open: 'You already have an unfinished automatic payment. Finish or cancel it.', err_f_gmail: 'Invalid Gmail address',
      n_apc_new: 'Payment created. Transfer exactly {0} within 5 minutes.', n_apc_ok: 'Payment confirmed. {0} was added to your balance.', n_apc_exp: 'The payment expired ({0}). Nothing was added to your balance.', n_apc_manu: 'Your payment ({0}) was not confirmed automatically. An admin will check it by hand.', n_apc_no: 'Your payment was rejected. Reason: {0}',
      n_apc_man: 'Manual check needed (AutoPayCard): {0}, {1}', n_apc_err: 'AutoPayCard error: {0}',
    },
  };
  for (const l of ['uz', 'ru', 'en']) Object.assign(window.D[l], X[l]);
})();
